const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./Home-BKe_GmN0.js","./vendor-react-CrK_Zf-d.js","./ParticleBg-C0Jm69Hd.js","./RadarChart-B42mSsdW.js","./ResourceCard-XSsdO5zQ.js","./code-xml-B3BHuY-c.js","./clapperboard-Cpj8bgD6.js","./network-DW1s3LjD.js","./play-rJFNRP7K.js","./clock-ClIC8EVc.js","./heart-DAYZixoK.js","./vendor-router-BuKx8LrI.js","./layers-CzTuDdR7.js","./target-Bp2aim9u.js","./proxy-BL8UQvsF.js","./zap-BJEUp3D5.js","./arrow-right-C00_wjVU.js","./brain-circuit-iN41i7Eb.js","./shield-check-DqwnpgZt.js","./compass-CcW6AK6u.js","./Profile-B-b5ZaHi.js","./MarkdownRenderer-Z-uspyl4.js","./vendor-katex-BTcloi8h.js","./vendor-katex-BrXs8prR.css","./vendor-highlight-DJL5RKip.js","./vendor-markdown-Cg8Bqt8z.js","./streaming-2LCi1Hf-.js","./refresh-cw-HQuZp2qA.js","./history-DYDvBkiO.js","./trending-up-BZVJ9TRa.js","./index-fmDLu740.js","./send-B8ph5Rh7.js","./Workshop-vvs7BA0t.js","./loader-circle-wdMikVHx.js","./brain-BG364EYG.js","./AnimationPlayer-vR4BTjx6.js","./MindmapViewer-Cfhpzw7S.js","./vendor-graph-BWMXpc1C.js","./vendor-graph-Fd0xVSp_.css","./orchestrator-BMZbDbm8.js","./rocket-IcbxnMly.js","./external-link-C5LmpybX.js","./LearningPath-CBNhA7NT.js","./lightbulb-Ca_xwflQ.js","./chevron-down-D6iWyZJR.js","./Tutor-BFTtv0v6.js","./Assessment-CaY2XjL6.js","./award-BHQRbcOt.js","./Library-w6HW78s3.js","./Practice-BbyZw0c4.js","./plus-C9n6CzvY.js","./arrow-left-BUaqAzNx.js","./StudyPlan-GXf7h1TZ.js","./Showcase-CfgZYtfI.js","./Onboarding-6M5Z0snb.js","./NotFound-vhoahIfs.js"])))=>i.map(i=>d[i]);
var Ut=Object.defineProperty;var Gt=(e,o,t)=>o in e?Ut(e,o,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[o]=t;var Oe=(e,o,t)=>Gt(e,typeof o!="symbol"?o+"":o,t);import{r as $,j as s,R as le,b as Vt}from"./vendor-react-CrK_Zf-d.js";import{N as Ot,u as $e,a as lt,L as Wt,O as Kt,H as Ht,B as Qt,R as Xt,b as T}from"./vendor-router-BuKx8LrI.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&r(a)}).observe(document,{childList:!0,subtree:!0});function t(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(n){if(n.ep)return;n.ep=!0;const i=t(n);fetch(n.href,i)}})();const Yt="modulepreload",Zt=function(e,o){return new URL(e,o).href},We={},R=function(o,t,r){let n=Promise.resolve();if(t&&t.length>0){let a=function(u){return Promise.all(u.map(m=>Promise.resolve(m).then(w=>({status:"fulfilled",value:w}),w=>({status:"rejected",reason:w}))))};const c=document.getElementsByTagName("link"),l=document.querySelector("meta[property=csp-nonce]"),p=(l==null?void 0:l.nonce)||(l==null?void 0:l.getAttribute("nonce"));n=a(t.map(u=>{if(u=Zt(u,r),u in We)return;We[u]=!0;const m=u.endsWith(".css"),w=m?'[rel="stylesheet"]':"";if(!!r)for(let f=c.length-1;f>=0;f--){const D=c[f];if(D.href===u&&(!m||D.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${u}"]${w}`))return;const x=document.createElement("link");if(x.rel=m?"stylesheet":Yt,m||(x.as="script"),x.crossOrigin="",x.href=u,p&&x.setAttribute("nonce",p),document.head.appendChild(x),m)return new Promise((f,D)=>{x.addEventListener("load",f),x.addEventListener("error",()=>D(new Error(`Unable to preload CSS for ${u}`)))})}))}function i(a){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=a,window.dispatchEvent(c),!c.defaultPrevented)throw a}return n.then(a=>{for(const c of a||[])c.status==="rejected"&&i(c.reason);return o().catch(i)})};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),er=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(o,t,r)=>r?r.toUpperCase():t.toLowerCase()),Ke=e=>{const o=er(e);return o.charAt(0).toUpperCase()+o.slice(1)},ct=(...e)=>e.filter((o,t,r)=>!!o&&o.trim()!==""&&r.indexOf(o)===t).join(" ").trim(),tr=e=>{for(const o in e)if(o.startsWith("aria-")||o==="role"||o==="title")return!0};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var rr={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const or=$.forwardRef(({color:e="currentColor",size:o=24,strokeWidth:t=2,absoluteStrokeWidth:r,className:n="",children:i,iconNode:a,...c},l)=>$.createElement("svg",{ref:l,...rr,width:o,height:o,stroke:e,strokeWidth:r?Number(t)*24/Number(o):t,className:ct("lucide",n),...!i&&!tr(c)&&{"aria-hidden":"true"},...c},[...a.map(([p,u])=>$.createElement(p,u)),...Array.isArray(i)?i:[i]]));/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=(e,o)=>{const t=$.forwardRef(({className:r,...n},i)=>$.createElement(or,{ref:i,iconNode:o,className:ct(`lucide-${Jt(Ke(e))}`,`lucide-${e}`,r),...n}));return t.displayName=Ke(e),t};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nr=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],sr=z("bell",nr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ir=[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]],ar=z("book-open",ir);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lr=[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]],cr=z("bot",lr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dr=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],pr=z("calendar",dr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mr=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],me=z("chevron-right",mr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ur=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],fr=z("circle-check",ur);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xr=[["path",{d:"M18 20a6 6 0 0 0-12 0",key:"1qehca"}],["circle",{cx:"12",cy:"10",r:"4",key:"1h16sb"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],hr=z("circle-user-round",xr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yr=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16.5 12",key:"1aq6pp"}]],gr=z("clock-3",yr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ar=[["path",{d:"M12 16h.01",key:"1drbdi"}],["path",{d:"M16 16h.01",key:"1f9h7w"}],["path",{d:"M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",key:"1iv0i2"}],["path",{d:"M8 16h.01",key:"18s6g9"}]],wr=z("factory",Ar);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const br=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],Er=z("file-text",br);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Br=[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]],Dr=z("gauge",Br);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fr=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],kr=z("layout-dashboard",Fr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vr=[["path",{d:"m16 6 4 14",key:"ji33uf"}],["path",{d:"M12 6v14",key:"1n7gus"}],["path",{d:"M8 8v12",key:"1gg7y9"}],["path",{d:"M4 4v16",key:"6qkkli"}]],$r=z("library",vr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _r=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"m21 3-7 7",key:"1l2asr"}],["path",{d:"m3 21 7-7",key:"tjx5ai"}],["path",{d:"M9 21H3v-6",key:"wtvkvv"}]],zr=z("maximize-2",_r);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Cr=[["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 18h16",key:"19g7jn"}],["path",{d:"M4 6h16",key:"1o0s65"}]],Sr=z("menu",Cr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mr=[["path",{d:"M14 9a2 2 0 0 1-2 2H6l-4 4V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2z",key:"p1xzt8"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1",key:"1cx29u"}]],qr=z("messages-square",Mr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ir=[["path",{d:"m14 10 7-7",key:"oa77jy"}],["path",{d:"M20 10h-6V4",key:"mjg0md"}],["path",{d:"m3 21 7-7",key:"tjx5ai"}],["path",{d:"M4 14h6v6",key:"rmj7iw"}]],Lr=z("minimize-2",Ir);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jr=[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]],Nr=z("moon",jr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tr=[["path",{d:"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",key:"nt11vn"}],["path",{d:"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",key:"15qc1e"}],["path",{d:"m2.3 2.3 7.286 7.286",key:"1wuzzi"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]],Rr=z("pen-tool",Tr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pr=[["path",{d:"M2 3h20",key:"91anmk"}],["path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3",key:"2k9sn8"}],["path",{d:"m7 21 5-5 5 5",key:"bip4we"}]],Ur=z("presentation",Pr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gr=[["path",{d:"M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"14sxne"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",key:"1hlbsb"}],["path",{d:"M16 16h5v5",key:"ccwih5"}]],Vr=z("refresh-ccw",Gr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Or=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],Wr=z("rotate-ccw",Or);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kr=[["circle",{cx:"6",cy:"19",r:"3",key:"1kj8tv"}],["path",{d:"M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15",key:"1d8sl"}],["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}]],Hr=z("route",Kr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qr=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],ce=z("search",Qr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xr=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],dt=z("sparkles",Xr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yr=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],Zr=z("sun",Yr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jr=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],eo=z("triangle-alert",Jr);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const to=[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]],He=z("trophy",to);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ro=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],_e=z("x",ro);class oo extends $.Component{constructor(){super(...arguments);Oe(this,"state",{hasError:!1})}static getDerivedStateFromError(){return{hasError:!0}}componentDidCatch(t,r){console.error("EduVerse 页面渲染失败",t,r.componentStack)}render(){return this.state.hasError?s.jsx("main",{"trae-inspector-start-line":"27","trae-inspector-start-column":"6","trae-inspector-end-line":"44","trae-inspector-end-column":"13","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"app-shell-bg flex min-h-screen items-center justify-center p-6",children:s.jsxs("section",{"trae-inspector-start-line":"28","trae-inspector-start-column":"8","trae-inspector-end-line":"43","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"glass w-full max-w-lg rounded-2xl p-8 text-center shadow-float",children:[s.jsx("div",{"trae-inspector-start-line":"29","trae-inspector-start-column":"10","trae-inspector-end-line":"31","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-vermilion-500/15 text-vermilion-400",children:s.jsx(eo,{className:"h-7 w-7"})}),s.jsx("h1",{"trae-inspector-start-line":"32","trae-inspector-start-column":"10","trae-inspector-end-line":"32","trae-inspector-end-column":"92","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E5%AD%A6%E4%B9%A0%E7%A9%BA%E9%97%B4%E6%9A%82%E6%97%B6%E8%B5%B0%E7%A5%9E%E4%BA%86%22%2C%22textStartLine%22%3A%2232%22%2C%22textStartColumn%22%3A%2278%22%2C%22textEndLine%22%3A%2232%22%2C%22textEndColumn%22%3A%2287%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-5 font-serif text-2xl font-bold text-[var(--fg)]",children:"学习空间暂时走神了"}),s.jsx("p",{"trae-inspector-start-line":"33","trae-inspector-start-column":"10","trae-inspector-end-line":"35","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%9C%AC%E5%9C%B0%E6%95%B0%E6%8D%AE%E4%BB%8D%E7%84%B6%E5%AE%89%E5%85%A8%E3%80%82%E5%88%B7%E6%96%B0%E9%A1%B5%E9%9D%A2%E5%8D%B3%E5%8F%AF%E9%87%8D%E6%96%B0%E8%BF%9E%E6%8E%A5%E6%99%BA%E8%83%BD%E4%BD%93%E7%BC%96%E9%98%9F%E3%80%82%22%2C%22textStartLine%22%3A%2233%22%2C%22textStartColumn%22%3A%2277%22%2C%22textEndLine%22%3A%2235%22%2C%22textEndColumn%22%3A%2210%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-2 text-sm leading-relaxed text-[var(--fg-muted)]",children:"本地数据仍然安全。刷新页面即可重新连接智能体编队。"}),s.jsxs("button",{"trae-inspector-start-line":"36","trae-inspector-start-column":"10","trae-inspector-end-line":"42","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/AppErrorBoundary.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>window.location.reload(),className:"mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-vermilion-500 to-azure-500 px-5 py-2.5 text-sm font-medium text-white shadow-glow",children:[s.jsx(Vr,{className:"h-4 w-4"}),"重新加载"]})]})}):this.props.children}}function no(){return s.jsx("div",{"trae-inspector-start-line":"5","trae-inspector-start-column":"4","trae-inspector-end-line":"14","trae-inspector-end-column":"10","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex min-h-[60vh] items-center justify-center px-6",role:"status","aria-live":"polite",children:s.jsxs("div",{"trae-inspector-start-line":"6","trae-inspector-start-column":"6","trae-inspector-end-line":"13","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-center",children:[s.jsxs("div",{"trae-inspector-start-line":"7","trae-inspector-start-column":"8","trae-inspector-end-line":"10","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"relative mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-vermilion-500/30 bg-vermilion-500/10 text-vermilion-400",children:[s.jsx(dt,{className:"h-6 w-6 animate-pulse"}),s.jsx("span",{"trae-inspector-start-line":"9","trae-inspector-start-column":"10","trae-inspector-end-line":"9","trae-inspector-end-column":"100","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"absolute -inset-2 animate-ping rounded-2xl border border-azure-500/20"})]}),s.jsx("p",{"trae-inspector-start-line":"11","trae-inspector-start-column":"8","trae-inspector-end-line":"11","trae-inspector-end-column":"90","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%AD%A3%E5%9C%A8%E8%B0%83%E5%BA%A6%E5%AD%A6%E4%B9%A0%E7%A9%BA%E9%97%B4%22%2C%22textStartLine%22%3A%2211%22%2C%22textStartColumn%22%3A%2278%22%2C%22textEndLine%22%3A%2211%22%2C%22textEndColumn%22%3A%2286%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-4 font-serif text-sm font-semibold text-[var(--fg)]",children:"正在调度学习空间"}),s.jsx("p",{"trae-inspector-start-line":"12","trae-inspector-start-column":"8","trae-inspector-end-line":"12","trae-inspector-end-column":"75","trae-inspector-file-path":"src/components/PageLoader.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%99%BA%E8%83%BD%E4%BD%93%E7%BC%96%E9%98%9F%E6%AD%A3%E5%9C%A8%E5%87%86%E5%A4%87%E9%A1%B5%E9%9D%A2%E2%80%A6%22%2C%22textStartLine%22%3A%2212%22%2C%22textStartColumn%22%3A%2259%22%2C%22textEndLine%22%3A%2212%22%2C%22textEndColumn%22%3A%2271%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-1 text-xs text-[var(--fg-muted)]",children:"智能体编队正在准备页面…"})]})})}function pt(e){var o,t,r="";if(typeof e=="string"||typeof e=="number")r+=e;else if(typeof e=="object")if(Array.isArray(e)){var n=e.length;for(o=0;o<n;o++)e[o]&&(t=pt(e[o]))&&(r&&(r+=" "),r+=t)}else for(t in e)e[t]&&(r&&(r+=" "),r+=t);return r}function so(){for(var e,o,t=0,r="",n=arguments.length;t<n;t++)(e=arguments[t])&&(o=pt(e))&&(r&&(r+=" "),r+=o);return r}const io=(e,o)=>{const t=new Array(e.length+o.length);for(let r=0;r<e.length;r++)t[r]=e[r];for(let r=0;r<o.length;r++)t[e.length+r]=o[r];return t},ao=(e,o)=>({classGroupId:e,validator:o}),mt=(e=new Map,o=null,t)=>({nextPart:e,validators:o,classGroupId:t}),ue="-",Qe=[],lo="arbitrary..",co=e=>{const o=mo(e),{conflictingClassGroups:t,conflictingClassGroupModifiers:r}=e;return{getClassGroupId:a=>{if(a.startsWith("[")&&a.endsWith("]"))return po(a);const c=a.split(ue),l=c[0]===""&&c.length>1?1:0;return ut(c,l,o)},getConflictingClassGroupIds:(a,c)=>{if(c){const l=r[a],p=t[a];return l?p?io(p,l):l:p||Qe}return t[a]||Qe}}},ut=(e,o,t)=>{if(e.length-o===0)return t.classGroupId;const n=e[o],i=t.nextPart.get(n);if(i){const p=ut(e,o+1,i);if(p)return p}const a=t.validators;if(a===null)return;const c=o===0?e.join(ue):e.slice(o).join(ue),l=a.length;for(let p=0;p<l;p++){const u=a[p];if(u.validator(c))return u.classGroupId}},po=e=>e.slice(1,-1).indexOf(":")===-1?void 0:(()=>{const o=e.slice(1,-1),t=o.indexOf(":"),r=o.slice(0,t);return r?lo+r:void 0})(),mo=e=>{const{theme:o,classGroups:t}=e;return uo(t,o)},uo=(e,o)=>{const t=mt();for(const r in e){const n=e[r];ze(n,t,r,o)}return t},ze=(e,o,t,r)=>{const n=e.length;for(let i=0;i<n;i++){const a=e[i];fo(a,o,t,r)}},fo=(e,o,t,r)=>{if(typeof e=="string"){xo(e,o,t);return}if(typeof e=="function"){ho(e,o,t,r);return}yo(e,o,t,r)},xo=(e,o,t)=>{const r=e===""?o:ft(o,e);r.classGroupId=t},ho=(e,o,t,r)=>{if(go(e)){ze(e(r),o,t,r);return}o.validators===null&&(o.validators=[]),o.validators.push(ao(t,e))},yo=(e,o,t,r)=>{const n=Object.entries(e),i=n.length;for(let a=0;a<i;a++){const[c,l]=n[a];ze(l,ft(o,c),t,r)}},ft=(e,o)=>{let t=e;const r=o.split(ue),n=r.length;for(let i=0;i<n;i++){const a=r[i];let c=t.nextPart.get(a);c||(c=mt(),t.nextPart.set(a,c)),t=c}return t},go=e=>"isThemeGetter"in e&&e.isThemeGetter===!0,Ao=e=>{if(e<1)return{get:()=>{},set:()=>{}};let o=0,t=Object.create(null),r=Object.create(null);const n=(i,a)=>{t[i]=a,o++,o>e&&(o=0,r=t,t=Object.create(null))};return{get(i){let a=t[i];if(a!==void 0)return a;if((a=r[i])!==void 0)return n(i,a),a},set(i,a){i in t?t[i]=a:n(i,a)}}},Fe="!",Xe=":",wo=[],Ye=(e,o,t,r,n)=>({modifiers:e,hasImportantModifier:o,baseClassName:t,maybePostfixModifierPosition:r,isExternal:n}),bo=e=>{const{prefix:o,experimentalParseClassName:t}=e;let r=n=>{const i=[];let a=0,c=0,l=0,p;const u=n.length;for(let f=0;f<u;f++){const D=n[f];if(a===0&&c===0){if(D===Xe){i.push(n.slice(l,f)),l=f+1;continue}if(D==="/"){p=f;continue}}D==="["?a++:D==="]"?a--:D==="("?c++:D===")"&&c--}const m=i.length===0?n:n.slice(l);let w=m,A=!1;m.endsWith(Fe)?(w=m.slice(0,-1),A=!0):m.startsWith(Fe)&&(w=m.slice(1),A=!0);const x=p&&p>l?p-l:void 0;return Ye(i,A,w,x)};if(o){const n=o+Xe,i=r;r=a=>a.startsWith(n)?i(a.slice(n.length)):Ye(wo,!1,a,void 0,!0)}if(t){const n=r;r=i=>t({className:i,parseClassName:n})}return r},Eo=e=>{const o=new Map;return e.orderSensitiveModifiers.forEach((t,r)=>{o.set(t,1e6+r)}),t=>{const r=[];let n=[];for(let i=0;i<t.length;i++){const a=t[i],c=a[0]==="[",l=o.has(a);c||l?(n.length>0&&(n.sort(),r.push(...n),n=[]),r.push(a)):n.push(a)}return n.length>0&&(n.sort(),r.push(...n)),r}},Bo=e=>({cache:Ao(e.cacheSize),parseClassName:bo(e),sortModifiers:Eo(e),postfixLookupClassGroupIds:Do(e),...co(e)}),Do=e=>{const o=Object.create(null),t=e.postfixLookupClassGroups;if(t)for(let r=0;r<t.length;r++)o[t[r]]=!0;return o},Fo=/\s+/,ko=(e,o)=>{const{parseClassName:t,getClassGroupId:r,getConflictingClassGroupIds:n,sortModifiers:i,postfixLookupClassGroupIds:a}=o,c=[],l=e.trim().split(Fo);let p="";for(let u=l.length-1;u>=0;u-=1){const m=l[u],{isExternal:w,modifiers:A,hasImportantModifier:x,baseClassName:f,maybePostfixModifierPosition:D}=t(m);if(w){p=m+(p.length>0?" "+p:p);continue}let b=!!D,v;if(b){const q=f.substring(0,D);v=r(q);const g=v&&a[v]?r(f):void 0;g&&g!==v&&(v=g,b=!1)}else v=r(f);if(!v){if(!b){p=m+(p.length>0?" "+p:p);continue}if(v=r(f),!v){p=m+(p.length>0?" "+p:p);continue}b=!1}const _=A.length===0?"":A.length===1?A[0]:i(A).join(":"),d=x?_+Fe:_,B=d+v;if(c.indexOf(B)>-1)continue;c.push(B);const C=n(v,b);for(let q=0;q<C.length;++q){const g=C[q];c.push(d+g)}p=m+(p.length>0?" "+p:p)}return p},vo=(...e)=>{let o=0,t,r,n="";for(;o<e.length;)(t=e[o++])&&(r=xt(t))&&(n&&(n+=" "),n+=r);return n},xt=e=>{if(typeof e=="string")return e;let o,t="";for(let r=0;r<e.length;r++)e[r]&&(o=xt(e[r]))&&(t&&(t+=" "),t+=o);return t},$o=(e,...o)=>{let t,r,n,i;const a=l=>{const p=o.reduce((u,m)=>m(u),e());return t=Bo(p),r=t.cache.get,n=t.cache.set,i=c,c(l)},c=l=>{const p=r(l);if(p)return p;const u=ko(l,t);return n(l,u),u};return i=a,(...l)=>i(vo(...l))},_o=[],S=e=>{const o=t=>t[e]||_o;return o.isThemeGetter=!0,o},ht=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,yt=/^\((?:(\w[\w-]*):)?(.+)\)$/i,zo=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,Co=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,So=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,Mo=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,qo=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Io=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,O=e=>zo.test(e),k=e=>!!e&&!Number.isNaN(Number(e)),U=e=>!!e&&Number.isInteger(Number(e)),Be=e=>e.endsWith("%")&&k(e.slice(0,-1)),G=e=>Co.test(e),gt=()=>!0,Lo=e=>So.test(e)&&!Mo.test(e),Ce=()=>!1,jo=e=>qo.test(e),No=e=>Io.test(e),To=e=>!h(e)&&!y(e),Ro=e=>e.startsWith("@container")&&(e[10]==="/"&&e[11]!==void 0||e[11]==="s"&&e[16]!==void 0&&e.startsWith("-size/",10)||e[11]==="n"&&e[18]!==void 0&&e.startsWith("-normal/",10)),Po=e=>H(e,bt,Ce),h=e=>ht.test(e),X=e=>H(e,Et,Lo),Ze=e=>H(e,Qo,k),Uo=e=>H(e,Dt,gt),Go=e=>H(e,Bt,Ce),Je=e=>H(e,At,Ce),Vo=e=>H(e,wt,No),de=e=>H(e,Ft,jo),y=e=>yt.test(e),re=e=>J(e,Et),Oo=e=>J(e,Bt),et=e=>J(e,At),Wo=e=>J(e,bt),Ko=e=>J(e,wt),pe=e=>J(e,Ft,!0),Ho=e=>J(e,Dt,!0),H=(e,o,t)=>{const r=ht.exec(e);return r?r[1]?o(r[1]):t(r[2]):!1},J=(e,o,t=!1)=>{const r=yt.exec(e);return r?r[1]?o(r[1]):t:!1},At=e=>e==="position"||e==="percentage",wt=e=>e==="image"||e==="url",bt=e=>e==="length"||e==="size"||e==="bg-size",Et=e=>e==="length",Qo=e=>e==="number",Bt=e=>e==="family-name",Dt=e=>e==="number"||e==="weight",Ft=e=>e==="shadow",Xo=()=>{const e=S("color"),o=S("font"),t=S("text"),r=S("font-weight"),n=S("tracking"),i=S("leading"),a=S("breakpoint"),c=S("container"),l=S("spacing"),p=S("radius"),u=S("shadow"),m=S("inset-shadow"),w=S("text-shadow"),A=S("drop-shadow"),x=S("blur"),f=S("perspective"),D=S("aspect"),b=S("ease"),v=S("animate"),_=()=>["auto","avoid","all","avoid-page","page","left","right","column"],d=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],B=()=>[...d(),y,h],C=()=>["auto","hidden","clip","visible","scroll"],q=()=>["auto","contain","none"],g=()=>[y,h,l],I=()=>[O,"full","auto",...g()],je=()=>[U,"none","subgrid",y,h],Ne=()=>["auto",{span:["full",U,y,h]},U,y,h],oe=()=>[U,"auto",y,h],Te=()=>["auto","min","max","fr",y,h],ge=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],ee=()=>["start","end","center","stretch","center-safe","end-safe"],P=()=>["auto",...g()],Q=()=>[O,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...g()],Ae=()=>[O,"screen","full","dvw","lvw","svw","min","max","fit",...g()],we=()=>[O,"screen","full","lh","dvh","lvh","svh","min","max","fit",...g()],E=()=>[e,y,h],Re=()=>[...d(),et,Je,{position:[y,h]}],Pe=()=>["no-repeat",{repeat:["","x","y","space","round"]}],Ue=()=>["auto","cover","contain",Wo,Po,{size:[y,h]}],be=()=>[Be,re,X],L=()=>["","none","full",p,y,h],j=()=>["",k,re,X],ne=()=>["solid","dashed","dotted","double"],Ge=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],M=()=>[k,Be,et,Je],Ve=()=>["","none",x,y,h],se=()=>["none",k,y,h],ie=()=>["none",k,y,h],Ee=()=>[k,y,h],ae=()=>[O,"full",...g()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[G],breakpoint:[G],color:[gt],container:[G],"drop-shadow":[G],ease:["in","out","in-out"],font:[To],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[G],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[G],shadow:[G],spacing:["px",k],text:[G],"text-shadow":[G],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",O,h,y,D]}],container:["container"],"container-type":[{"@container":["","normal","size",y,h]}],"container-named":[Ro],columns:[{columns:[k,h,y,c]}],"break-after":[{"break-after":_()}],"break-before":[{"break-before":_()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:B()}],overflow:[{overflow:C()}],"overflow-x":[{"overflow-x":C()}],"overflow-y":[{"overflow-y":C()}],overscroll:[{overscroll:q()}],"overscroll-x":[{"overscroll-x":q()}],"overscroll-y":[{"overscroll-y":q()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:I()}],"inset-x":[{"inset-x":I()}],"inset-y":[{"inset-y":I()}],start:[{"inset-s":I(),start:I()}],end:[{"inset-e":I(),end:I()}],"inset-bs":[{"inset-bs":I()}],"inset-be":[{"inset-be":I()}],top:[{top:I()}],right:[{right:I()}],bottom:[{bottom:I()}],left:[{left:I()}],visibility:["visible","invisible","collapse"],z:[{z:[U,"auto",y,h]}],basis:[{basis:[O,"full","auto",c,...g()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[k,O,"auto","initial","none",h]}],grow:[{grow:["",k,y,h]}],shrink:[{shrink:["",k,y,h]}],order:[{order:[U,"first","last","none",y,h]}],"grid-cols":[{"grid-cols":je()}],"col-start-end":[{col:Ne()}],"col-start":[{"col-start":oe()}],"col-end":[{"col-end":oe()}],"grid-rows":[{"grid-rows":je()}],"row-start-end":[{row:Ne()}],"row-start":[{"row-start":oe()}],"row-end":[{"row-end":oe()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":Te()}],"auto-rows":[{"auto-rows":Te()}],gap:[{gap:g()}],"gap-x":[{"gap-x":g()}],"gap-y":[{"gap-y":g()}],"justify-content":[{justify:[...ge(),"normal"]}],"justify-items":[{"justify-items":[...ee(),"normal"]}],"justify-self":[{"justify-self":["auto",...ee()]}],"align-content":[{content:["normal",...ge()]}],"align-items":[{items:[...ee(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...ee(),{baseline:["","last"]}]}],"place-content":[{"place-content":ge()}],"place-items":[{"place-items":[...ee(),"baseline"]}],"place-self":[{"place-self":["auto",...ee()]}],p:[{p:g()}],px:[{px:g()}],py:[{py:g()}],ps:[{ps:g()}],pe:[{pe:g()}],pbs:[{pbs:g()}],pbe:[{pbe:g()}],pt:[{pt:g()}],pr:[{pr:g()}],pb:[{pb:g()}],pl:[{pl:g()}],m:[{m:P()}],mx:[{mx:P()}],my:[{my:P()}],ms:[{ms:P()}],me:[{me:P()}],mbs:[{mbs:P()}],mbe:[{mbe:P()}],mt:[{mt:P()}],mr:[{mr:P()}],mb:[{mb:P()}],ml:[{ml:P()}],"space-x":[{"space-x":g()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":g()}],"space-y-reverse":["space-y-reverse"],size:[{size:Q()}],"inline-size":[{inline:["auto",...Ae()]}],"min-inline-size":[{"min-inline":["auto",...Ae()]}],"max-inline-size":[{"max-inline":["none",...Ae()]}],"block-size":[{block:["auto",...we()]}],"min-block-size":[{"min-block":["auto",...we()]}],"max-block-size":[{"max-block":["none",...we()]}],w:[{w:[c,"screen",...Q()]}],"min-w":[{"min-w":[c,"screen","none",...Q()]}],"max-w":[{"max-w":[c,"screen","none","prose",{screen:[a]},...Q()]}],h:[{h:["screen","lh",...Q()]}],"min-h":[{"min-h":["screen","lh","none",...Q()]}],"max-h":[{"max-h":["screen","lh",...Q()]}],"font-size":[{text:["base",t,re,X]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[r,Ho,Uo]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",Be,h]}],"font-family":[{font:[Oo,Go,o]}],"font-features":[{"font-features":[h]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[n,y,h]}],"line-clamp":[{"line-clamp":[k,"none",y,Ze]}],leading:[{leading:[i,...g()]}],"list-image":[{"list-image":["none",y,h]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",y,h]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:E()}],"text-color":[{text:E()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...ne(),"wavy"]}],"text-decoration-thickness":[{decoration:[k,"from-font","auto",y,X]}],"text-decoration-color":[{decoration:E()}],"underline-offset":[{"underline-offset":[k,"auto",y,h]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:g()}],"tab-size":[{tab:[U,y,h]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",y,h]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",y,h]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:Re()}],"bg-repeat":[{bg:Pe()}],"bg-size":[{bg:Ue()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},U,y,h],radial:["",y,h],conic:[U,y,h]},Ko,Vo]}],"bg-color":[{bg:E()}],"gradient-from-pos":[{from:be()}],"gradient-via-pos":[{via:be()}],"gradient-to-pos":[{to:be()}],"gradient-from":[{from:E()}],"gradient-via":[{via:E()}],"gradient-to":[{to:E()}],rounded:[{rounded:L()}],"rounded-s":[{"rounded-s":L()}],"rounded-e":[{"rounded-e":L()}],"rounded-t":[{"rounded-t":L()}],"rounded-r":[{"rounded-r":L()}],"rounded-b":[{"rounded-b":L()}],"rounded-l":[{"rounded-l":L()}],"rounded-ss":[{"rounded-ss":L()}],"rounded-se":[{"rounded-se":L()}],"rounded-ee":[{"rounded-ee":L()}],"rounded-es":[{"rounded-es":L()}],"rounded-tl":[{"rounded-tl":L()}],"rounded-tr":[{"rounded-tr":L()}],"rounded-br":[{"rounded-br":L()}],"rounded-bl":[{"rounded-bl":L()}],"border-w":[{border:j()}],"border-w-x":[{"border-x":j()}],"border-w-y":[{"border-y":j()}],"border-w-s":[{"border-s":j()}],"border-w-e":[{"border-e":j()}],"border-w-bs":[{"border-bs":j()}],"border-w-be":[{"border-be":j()}],"border-w-t":[{"border-t":j()}],"border-w-r":[{"border-r":j()}],"border-w-b":[{"border-b":j()}],"border-w-l":[{"border-l":j()}],"divide-x":[{"divide-x":j()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":j()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...ne(),"hidden","none"]}],"divide-style":[{divide:[...ne(),"hidden","none"]}],"border-color":[{border:E()}],"border-color-x":[{"border-x":E()}],"border-color-y":[{"border-y":E()}],"border-color-s":[{"border-s":E()}],"border-color-e":[{"border-e":E()}],"border-color-bs":[{"border-bs":E()}],"border-color-be":[{"border-be":E()}],"border-color-t":[{"border-t":E()}],"border-color-r":[{"border-r":E()}],"border-color-b":[{"border-b":E()}],"border-color-l":[{"border-l":E()}],"divide-color":[{divide:E()}],"outline-style":[{outline:[...ne(),"none","hidden"]}],"outline-offset":[{"outline-offset":[k,y,h]}],"outline-w":[{outline:["",k,re,X]}],"outline-color":[{outline:E()}],shadow:[{shadow:["","none",u,pe,de]}],"shadow-color":[{shadow:E()}],"inset-shadow":[{"inset-shadow":["none",m,pe,de]}],"inset-shadow-color":[{"inset-shadow":E()}],"ring-w":[{ring:j()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:E()}],"ring-offset-w":[{"ring-offset":[k,X]}],"ring-offset-color":[{"ring-offset":E()}],"inset-ring-w":[{"inset-ring":j()}],"inset-ring-color":[{"inset-ring":E()}],"text-shadow":[{"text-shadow":["none",w,pe,de]}],"text-shadow-color":[{"text-shadow":E()}],opacity:[{opacity:[k,y,h]}],"mix-blend":[{"mix-blend":[...Ge(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":Ge()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[k]}],"mask-image-linear-from-pos":[{"mask-linear-from":M()}],"mask-image-linear-to-pos":[{"mask-linear-to":M()}],"mask-image-linear-from-color":[{"mask-linear-from":E()}],"mask-image-linear-to-color":[{"mask-linear-to":E()}],"mask-image-t-from-pos":[{"mask-t-from":M()}],"mask-image-t-to-pos":[{"mask-t-to":M()}],"mask-image-t-from-color":[{"mask-t-from":E()}],"mask-image-t-to-color":[{"mask-t-to":E()}],"mask-image-r-from-pos":[{"mask-r-from":M()}],"mask-image-r-to-pos":[{"mask-r-to":M()}],"mask-image-r-from-color":[{"mask-r-from":E()}],"mask-image-r-to-color":[{"mask-r-to":E()}],"mask-image-b-from-pos":[{"mask-b-from":M()}],"mask-image-b-to-pos":[{"mask-b-to":M()}],"mask-image-b-from-color":[{"mask-b-from":E()}],"mask-image-b-to-color":[{"mask-b-to":E()}],"mask-image-l-from-pos":[{"mask-l-from":M()}],"mask-image-l-to-pos":[{"mask-l-to":M()}],"mask-image-l-from-color":[{"mask-l-from":E()}],"mask-image-l-to-color":[{"mask-l-to":E()}],"mask-image-x-from-pos":[{"mask-x-from":M()}],"mask-image-x-to-pos":[{"mask-x-to":M()}],"mask-image-x-from-color":[{"mask-x-from":E()}],"mask-image-x-to-color":[{"mask-x-to":E()}],"mask-image-y-from-pos":[{"mask-y-from":M()}],"mask-image-y-to-pos":[{"mask-y-to":M()}],"mask-image-y-from-color":[{"mask-y-from":E()}],"mask-image-y-to-color":[{"mask-y-to":E()}],"mask-image-radial":[{"mask-radial":[y,h]}],"mask-image-radial-from-pos":[{"mask-radial-from":M()}],"mask-image-radial-to-pos":[{"mask-radial-to":M()}],"mask-image-radial-from-color":[{"mask-radial-from":E()}],"mask-image-radial-to-color":[{"mask-radial-to":E()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":d()}],"mask-image-conic-pos":[{"mask-conic":[k]}],"mask-image-conic-from-pos":[{"mask-conic-from":M()}],"mask-image-conic-to-pos":[{"mask-conic-to":M()}],"mask-image-conic-from-color":[{"mask-conic-from":E()}],"mask-image-conic-to-color":[{"mask-conic-to":E()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:Re()}],"mask-repeat":[{mask:Pe()}],"mask-size":[{mask:Ue()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",y,h]}],filter:[{filter:["","none",y,h]}],blur:[{blur:Ve()}],brightness:[{brightness:[k,y,h]}],contrast:[{contrast:[k,y,h]}],"drop-shadow":[{"drop-shadow":["","none",A,pe,de]}],"drop-shadow-color":[{"drop-shadow":E()}],grayscale:[{grayscale:["",k,y,h]}],"hue-rotate":[{"hue-rotate":[k,y,h]}],invert:[{invert:["",k,y,h]}],saturate:[{saturate:[k,y,h]}],sepia:[{sepia:["",k,y,h]}],"backdrop-filter":[{"backdrop-filter":["","none",y,h]}],"backdrop-blur":[{"backdrop-blur":Ve()}],"backdrop-brightness":[{"backdrop-brightness":[k,y,h]}],"backdrop-contrast":[{"backdrop-contrast":[k,y,h]}],"backdrop-grayscale":[{"backdrop-grayscale":["",k,y,h]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[k,y,h]}],"backdrop-invert":[{"backdrop-invert":["",k,y,h]}],"backdrop-opacity":[{"backdrop-opacity":[k,y,h]}],"backdrop-saturate":[{"backdrop-saturate":[k,y,h]}],"backdrop-sepia":[{"backdrop-sepia":["",k,y,h]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":g()}],"border-spacing-x":[{"border-spacing-x":g()}],"border-spacing-y":[{"border-spacing-y":g()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",y,h]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[k,"initial",y,h]}],ease:[{ease:["linear","initial",b,y,h]}],delay:[{delay:[k,y,h]}],animate:[{animate:["none",v,y,h]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[f,y,h]}],"perspective-origin":[{"perspective-origin":B()}],rotate:[{rotate:se()}],"rotate-x":[{"rotate-x":se()}],"rotate-y":[{"rotate-y":se()}],"rotate-z":[{"rotate-z":se()}],scale:[{scale:ie()}],"scale-x":[{"scale-x":ie()}],"scale-y":[{"scale-y":ie()}],"scale-z":[{"scale-z":ie()}],"scale-3d":["scale-3d"],skew:[{skew:Ee()}],"skew-x":[{"skew-x":Ee()}],"skew-y":[{"skew-y":Ee()}],transform:[{transform:[y,h,"","none","gpu","cpu"]}],"transform-origin":[{origin:B()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:ae()}],"translate-x":[{"translate-x":ae()}],"translate-y":[{"translate-y":ae()}],"translate-z":[{"translate-z":ae()}],"translate-none":["translate-none"],zoom:[{zoom:[U,y,h]}],accent:[{accent:E()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:E()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",y,h]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":E()}],"scrollbar-track-color":[{"scrollbar-track":E()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":g()}],"scroll-mx":[{"scroll-mx":g()}],"scroll-my":[{"scroll-my":g()}],"scroll-ms":[{"scroll-ms":g()}],"scroll-me":[{"scroll-me":g()}],"scroll-mbs":[{"scroll-mbs":g()}],"scroll-mbe":[{"scroll-mbe":g()}],"scroll-mt":[{"scroll-mt":g()}],"scroll-mr":[{"scroll-mr":g()}],"scroll-mb":[{"scroll-mb":g()}],"scroll-ml":[{"scroll-ml":g()}],"scroll-p":[{"scroll-p":g()}],"scroll-px":[{"scroll-px":g()}],"scroll-py":[{"scroll-py":g()}],"scroll-ps":[{"scroll-ps":g()}],"scroll-pe":[{"scroll-pe":g()}],"scroll-pbs":[{"scroll-pbs":g()}],"scroll-pbe":[{"scroll-pbe":g()}],"scroll-pt":[{"scroll-pt":g()}],"scroll-pr":[{"scroll-pr":g()}],"scroll-pb":[{"scroll-pb":g()}],"scroll-pl":[{"scroll-pl":g()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",y,h]}],fill:[{fill:["none",...E()]}],"stroke-w":[{stroke:[k,re,X,Ze]}],stroke:[{stroke:["none",...E()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},Yo=$o(Xo);function Z(...e){return Yo(so(e))}const Se=[{id:"captain",name:"灵境",role:"队长 · Captain",glyph:"灵",color:"#E63946",desc:"对话引导专家，负责学生画像构建与任务分发，是学生与智能体编队之间的桥梁。",skills:["对话式画像抽取","任务理解与分发","学习目标对齐"],triggers:"all"},{id:"deconstructor",name:"解构者",role:"知识架构师 · Deconstructor",glyph:"解",color:"#F4A261",desc:"将复杂知识点拆解为可学习的结构化骨架，输出思维导图与知识依赖关系。",skills:["知识结构拆解","思维导图骨架","前置依赖分析"],triggers:["document","mindmap","reading"]},{id:"weaver",name:"编织者",role:"内容撰写师 · Weaver",glyph:"织",color:"#1B9AAA",desc:"将知识骨架织就为详实、可读的讲解文档与拓展阅读，注重叙事逻辑与学术严谨。",skills:["学术叙事撰写","类比与例证","拓展阅读汇编"],triggers:["document","reading"]},{id:"quizmaster",name:"出题官",role:"评测设计师 · QuizMaster",glyph:"题",color:"#9D4EDD",desc:"依据知识图谱与画像易错点，生成多题型、多难度的练习题与解析。",skills:["多题型生成","难度梯度设计","易错点靶向"],triggers:["quiz"]},{id:"visualist",name:"视觉师",role:"多模态设计师 · Visualist",glyph:"视",color:"#22D3EE",desc:"将抽象概念可视化为 SVG 图解与动画分镜脚本，让难懂的概念一目了然。",skills:["SVG 图解生成","动画分镜脚本","信息图设计"],triggers:["animation"]},{id:"coder",name:"实操匠",role:"代码工程师 · Coder",glyph:"码",color:"#10B981",desc:"生成可运行的代码案例与实验项目，覆盖环境配置、注释与单元测试。",skills:["可运行代码生成","环境配置","单元测试编写"],triggers:["code"]},{id:"validator",name:"校验官",role:"防幻觉守门人 · Validator",glyph:"校",color:"#F87171",desc:"对照本地知识库进行事实核查、安全过滤与引用补全，确保输出无幻觉、无违规。",skills:["事实核查","安全过滤","引用补全"],triggers:"all"}],ss=e=>Se.find(o=>o.id===e),is={document:[{id:"deconstructor",phase:"拆解知识结构"},{id:"weaver",phase:"撰写讲解文档"},{id:"validator",phase:"事实核查与安全过滤"}],mindmap:[{id:"deconstructor",phase:"构建思维骨架"},{id:"visualist",phase:"渲染节点连线"},{id:"validator",phase:"节点校验"}],quiz:[{id:"deconstructor",phase:"锁定考点"},{id:"quizmaster",phase:"生成多梯度题目"},{id:"validator",phase:"答案与解析校验"}],reading:[{id:"deconstructor",phase:"梳理拓展方向"},{id:"weaver",phase:"汇编拓展阅读"},{id:"validator",phase:"引用补全"}],animation:[{id:"deconstructor",phase:"提取可视化要素"},{id:"visualist",phase:"设计分镜与图解"},{id:"validator",phase:"图解准确性校验"}],code:[{id:"deconstructor",phase:"分析实操需求"},{id:"coder",phase:"编写可运行代码"},{id:"validator",phase:"语法与安全校验"}]},Zo={sm:{box:"h-9 w-9",glyph:"text-sm"},md:{box:"h-12 w-12",glyph:"text-base"},lg:{box:"h-16 w-16",glyph:"text-xl"}};function Jo({agent:e,size:o="md",active:t=!1,pulse:r=!1,onClick:n}){const i=Zo[o];return s.jsxs("div",{"trae-inspector-start-line":"28","trae-inspector-start-column":"4","trae-inspector-end-line":"63","trae-inspector-end-column":"10","trae-inspector-file-path":"src/components/AgentAvatar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",onClick:n,className:Z("relative inline-flex items-center justify-center rounded-full transition-transform",i.box,n&&"cursor-pointer hover:scale-105"),title:`${e.name} · ${e.role}`,children:[s.jsx("div",{"trae-inspector-start-line":"38","trae-inspector-start-column":"6","trae-inspector-end-line":"47","trae-inspector-end-column":"8","trae-inspector-file-path":"src/components/AgentAvatar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:Z("absolute inset-0 rounded-full opacity-70",r&&"animate-breathe"),style:{background:`conic-gradient(from 0deg, ${e.color}, transparent, ${e.color})`,filter:"blur(1px)"}}),s.jsx("div",{"trae-inspector-start-line":"49","trae-inspector-start-column":"6","trae-inspector-end-line":"62","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/AgentAvatar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:Z("relative flex h-[78%] w-[78%] items-center justify-center rounded-full font-serif font-bold",i.glyph,t&&"ring-2"),style:{background:`radial-gradient(circle at 30% 30%, ${e.color}40, #0A0E1A 80%)`,color:e.color,boxShadow:t?`0 0 16px ${e.color}80`:"none"},children:e.glyph})]})}const tt=e=>{let o;const t=new Set,r=(p,u)=>{const m=typeof p=="function"?p(o):p;if(!Object.is(m,o)){const w=o;o=u??(typeof m!="object"||m===null)?m:Object.assign({},o,m),t.forEach(A=>A(o,w))}},n=()=>o,c={setState:r,getState:n,getInitialState:()=>l,subscribe:p=>(t.add(p),()=>t.delete(p))},l=o=e(r,n,c);return c},en=(e=>e?tt(e):tt),tn=e=>e;function rn(e,o=tn){const t=le.useSyncExternalStore(e.subscribe,le.useCallback(()=>o(e.getState()),[e,o]),le.useCallback(()=>o(e.getInitialState()),[e,o]));return le.useDebugValue(t),t}const rt=e=>{const o=en(e),t=r=>rn(o,r);return Object.assign(t,o),t},on=(e=>e?rt(e):rt),kt={id:"L2024-001",name:"林知远",avatar:"知",major:"人工智能 / 计算机科学与技术",grade:"本科大三",goal:"考研深造 · 大模型方向",enrolledAt:"2024-09-01"},te=[kt,{id:"L2024-002",name:"苏晴",avatar:"晴",major:"电子信息工程",grade:"本科大二",goal:"保研 · 计算机视觉方向",enrolledAt:"2024-09-01"},{id:"L2024-003",name:"陈墨",avatar:"墨",major:"计算机科学与技术",grade:"研一",goal:"就业 · 强化学习方向",enrolledAt:"2025-09-01"},{id:"L2024-004",name:"周屿",avatar:"屿",major:"数据科学",grade:"本科大三",goal:"竞赛 · Kaggle 方向",enrolledAt:"2024-09-01"}],V={id:"PV-001",version:1,createdAt:"2026-03-12 10:24",trigger:"首次对话引导",dimensions:[{name:"知识基础",score:68,evidence:"自评高数 78 / 线代 65 / 概率 72；Python 中级；近期 ML 课程作业均分 82。",tags:["高数 78","线代 65","Python 中级"]},{name:"认知风格",score:76,evidence:"倾向视觉+实践型：偏好图解、可运行代码与动手实验，纯符号推导注意力衰减较快。",tags:["视觉型","实践型"]},{name:"易错偏好",score:54,evidence:"梯度爆炸/消失场景易错；注意力机制 QKV 顺序易混；动态规划边界条件遗漏。",tags:["梯度爆炸","QKV 顺序","DP 边界"]},{name:"学习节奏",score:72,evidence:"稳健型：日均 1.5h，单次专注 45min，偏好小步快跑 + 复习巩固。",tags:["稳健","45min/次"]},{name:"兴趣方向",score:88,evidence:"强烈关注大模型推理优化与多智能体协同；对 CV 兴趣中等；对符号推理兴趣较低。",tags:["LLM 推理","Multi-Agent","RAG"]},{name:"目标导向",score:82,evidence:"考研 + 工程双导向：需体系化理论，同时希望产出可上线的小型 Agent 项目。",tags:["考研","工程落地"]}]},Me={id:"PV-002",version:2,createdAt:"2026-04-08 19:42",trigger:"完成 CNN 章节后随学随新",dimensions:[{name:"知识基础",score:74,evidence:"深度学习章节测验 86 分，知识基础提升；线代补强至 71。",tags:["DL 测验 86","线代 71"]},{name:"认知风格",score:76,evidence:"维持视觉+实践型偏好；新增对动画分镜反馈良好。",tags:["视觉型","实践型","动画偏好"]},{name:"易错偏好",score:61,evidence:"梯度问题已纠正；当前易错点转移到 Multi-Head Attention 维度拼接。",tags:["Multi-Head 维度","Padding Mask"]},{name:"学习节奏",score:78,evidence:"近两周日均 1.8h，单次专注提升至 55min，节奏更稳。",tags:["日均 1.8h","55min/次"]},{name:"兴趣方向",score:92,evidence:"明确聚焦大模型推理与 Agent 工程；主动探索 vLLM、Function Calling。",tags:["vLLM","Function Calling","Agent 工程"]},{name:"目标导向",score:85,evidence:"考研目标院校锁定；工程目标转为完成一个 3-Agent 协同 Demo。",tags:["院校锁定","3-Agent Demo"]}]},vt=[V,Me],as={goal:"大模型方向考研 + 工程 Demo 双目标",nodes:[{knowledgeId:"ai-intro",status:"done",order:1,reason:"基础认知，已掌握"},{knowledgeId:"ai-history",status:"done",order:2},{knowledgeId:"ai-schools",status:"done",order:3},{knowledgeId:"ml-overview",status:"done",order:4},{knowledgeId:"ml-linear",status:"done",order:5},{knowledgeId:"ml-tree",status:"done",order:6},{knowledgeId:"dl-fundamentals",status:"done",order:7},{knowledgeId:"dl-cnn",status:"done",order:8,reason:"近期完成，掌握度 86"},{knowledgeId:"dl-rnn",status:"doing",order:9,reason:"当前学习中，建议聚焦 LSTM 门控"},{knowledgeId:"dl-transformer",status:"recommended",order:10,reason:"兴趣+目标强相关，建议加速"},{knowledgeId:"llm-pretrain",status:"todo",order:11},{knowledgeId:"llm-rag",status:"todo",order:12},{knowledgeId:"llm-agent",status:"todo",order:13},{knowledgeId:"llm-multiagent",status:"todo",order:14,reason:"工程 Demo 终点"},{knowledgeId:"search-informed",status:"recommended",order:15,reason:"补强：A* 启发函数是面试高频"},{knowledgeId:"kr-knowledge-graph",status:"locked",order:16},{knowledgeId:"ml-eval",status:"todo",order:17},{knowledgeId:"ai-ethics",status:"recommended",order:18,reason:"考研论述题热点"}]},$t=[{knowledgeId:"ai-intro",mastery:92,timeSpent:28,lastVisit:"2026-03-13",exercisesCorrect:5,exercisesTotal:5,completedResources:["doc-1","anim-1"],quizAttempts:2,quizScore:90,learned:!0,quizCompleted:!0},{knowledgeId:"ai-history",mastery:88,timeSpent:32,lastVisit:"2026-03-14",exercisesCorrect:4,exercisesTotal:5,completedResources:["doc-2","anim-2"],quizAttempts:1,quizScore:80,learned:!0,quizCompleted:!0},{knowledgeId:"ai-schools",mastery:85,timeSpent:38,lastVisit:"2026-03-16",exercisesCorrect:7,exercisesTotal:8,completedResources:["doc-3"],quizAttempts:1,quizScore:75,learned:!0,quizCompleted:!0},{knowledgeId:"ai-ethics",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"search-uninformed",mastery:78,timeSpent:40,lastVisit:"2026-03-18",exercisesCorrect:6,exercisesTotal:8,completedResources:["doc-4","code-1"],quizAttempts:1,quizScore:70,learned:!0,quizCompleted:!0},{knowledgeId:"search-informed",mastery:72,timeSpent:50,lastVisit:"2026-03-20",exercisesCorrect:5,exercisesTotal:7,completedResources:["doc-5","code-2"],quizAttempts:1,quizScore:65,learned:!0,quizCompleted:!0},{knowledgeId:"search-local",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"search-adversarial",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"kr-logic",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"kr-frame",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"kr-uncertain",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"kr-knowledge-graph",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"ml-overview",mastery:84,timeSpent:35,lastVisit:"2026-03-19",exercisesCorrect:4,exercisesTotal:5,completedResources:["doc-6","mindmap-1"],quizAttempts:1,quizScore:80,learned:!0,quizCompleted:!0},{knowledgeId:"ml-linear",mastery:80,timeSpent:52,lastVisit:"2026-03-22",exercisesCorrect:8,exercisesTotal:10,completedResources:["doc-7","code-3"],quizAttempts:2,quizScore:75,learned:!0,quizCompleted:!0},{knowledgeId:"ml-tree",mastery:82,timeSpent:48,lastVisit:"2026-03-26",exercisesCorrect:7,exercisesTotal:9,completedResources:["doc-8","code-4"],quizAttempts:1,quizScore:78,learned:!0,quizCompleted:!0},{knowledgeId:"ml-eval",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"dl-fundamentals",mastery:78,timeSpent:65,lastVisit:"2026-04-02",exercisesCorrect:6,exercisesTotal:8,completedResources:["doc-9","code-5"],quizAttempts:1,quizScore:70,learned:!0,quizCompleted:!1},{knowledgeId:"dl-cnn",mastery:86,timeSpent:58,lastVisit:"2026-04-08",exercisesCorrect:9,exercisesTotal:10,completedResources:["doc-10","anim-3","code-6"],quizAttempts:2,quizScore:85,learned:!0,quizCompleted:!0},{knowledgeId:"dl-rnn",mastery:62,timeSpent:30,lastVisit:"2026-04-10",exercisesCorrect:3,exercisesTotal:5,completedResources:["doc-11"],quizAttempts:1,quizScore:60,learned:!0,quizCompleted:!1},{knowledgeId:"dl-transformer",mastery:35,timeSpent:8,lastVisit:"2026-04-11",exercisesCorrect:0,exercisesTotal:2,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"llm-pretrain",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"llm-rag",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"llm-agent",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1},{knowledgeId:"llm-multiagent",mastery:0,timeSpent:0,lastVisit:"",exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!1,quizCompleted:!1}],nn=[{id:"q-ai-intro-1",knowledgeId:"ai-intro",type:"single",question:"以下哪项不属于人工智能的研究范畴？",options:["机器学习","深度学习","云计算","自然语言处理"],correctAnswer:2,explanation:"云计算是一种基础设施服务，不属于人工智能的研究范畴。",difficulty:1},{id:"q-ai-intro-2",knowledgeId:"ai-intro",type:"single",question:"强人工智能（AGI）的特点是什么？",options:["只能完成特定任务","具备人类级别的通用智能","需要大量标注数据","基于规则引擎"],correctAnswer:1,explanation:"强人工智能指具备人类级别的通用智能，可以胜任任何智力任务。",difficulty:2},{id:"q-ai-history-1",knowledgeId:"ai-history",type:"single",question:"人工智能的第一次浪潮主要基于什么方法论？",options:["连接主义","行为主义","符号主义","深度学习"],correctAnswer:2,explanation:"第一次浪潮（1956-1974）以符号主义为主导，强调逻辑推理和知识表示。",difficulty:1},{id:"q-ai-history-2",knowledgeId:"ai-history",type:"single",question:"深度学习浪潮兴起的关键技术突破是？",options:["专家系统","卷积神经网络","决策树","支持向量机"],correctAnswer:1,explanation:"卷积神经网络（CNN）和深度学习的发展推动了第三次浪潮的兴起。",difficulty:2},{id:"q-ai-schools-1",knowledgeId:"ai-schools",type:"single",question:"连接主义学派的代表方法是什么？",options:["逻辑推理","神经网络","进化算法","专家系统"],correctAnswer:1,explanation:"连接主义以神经网络为代表，模拟人脑神经元的连接方式。",difficulty:1},{id:"q-ai-schools-2",knowledgeId:"ai-schools",type:"multiple",question:"以下哪些属于人工智能的研究学派？",options:["符号主义","连接主义","行为主义","实用主义"],correctAnswer:[0,1,2],explanation:"人工智能的三大研究学派是符号主义、连接主义和行为主义。",difficulty:2},{id:"q-ai-ethics-1",knowledgeId:"ai-ethics",type:"single",question:"AI 伦理中'价值对齐'指的是什么？",options:["算法效率优化","AI 目标与人类价值观一致","数据隐私保护","模型可解释性"],correctAnswer:1,explanation:"价值对齐确保 AI 系统的目标与人类价值观保持一致，避免产生有害行为。",difficulty:2},{id:"q-search-1",knowledgeId:"search-uninformed",type:"single",question:"BFS（广度优先搜索）的时间复杂度是？",options:["O(b)","O(b^d)","O(d)","O(b*d)"],correctAnswer:1,explanation:"BFS 的时间复杂度为 O(b^d)，其中 b 是分支因子，d 是解的深度。",difficulty:2},{id:"q-search-2",knowledgeId:"search-uninformed",type:"single",question:"以下哪种搜索策略是完备且最优的？",options:["DFS","BFS","迭代加深","UCS"],correctAnswer:3,explanation:"UCS（统一代价搜索）在边权非负时是完备且最优的。",difficulty:2},{id:"q-search-astar-1",knowledgeId:"search-informed",type:"single",question:"A* 算法的启发函数 h(n) 需要满足什么条件才能保证最优？",options:["可采纳性","单调性","可采纳性且单调性","无约束"],correctAnswer:2,explanation:"A* 算法需要启发函数满足可采纳性（h(n) <= h*(n)）且单调一致才能保证最优。",difficulty:3},{id:"q-search-astar-2",knowledgeId:"search-informed",type:"single",question:"当启发函数 h(n) = 0 时，A* 算法退化为？",options:["DFS","BFS","UCS","贪婪搜索"],correctAnswer:2,explanation:"当 h(n) = 0 时，f(n) = g(n)，A* 退化为统一代价搜索（UCS）。",difficulty:2},{id:"q-kr-logic-1",knowledgeId:"kr-logic",type:"single",question:"一阶谓词逻辑中，以下哪个符号表示全称量词？",options:["∃","∀","→","∧"],correctAnswer:1,explanation:"∀ 表示全称量词（for all），∃ 表示存在量词（exists）。",difficulty:1},{id:"q-kr-frame-1",knowledgeId:"kr-frame",type:"single",question:"框架表示法主要用于表示什么类型的知识？",options:["数学公式","结构化知识","图像数据","时序数据"],correctAnswer:1,explanation:"框架表示法适合表示结构化知识，如对象、概念及其属性。",difficulty:1},{id:"q-ml-overview-1",knowledgeId:"ml-overview",type:"single",question:"监督学习与无监督学习的主要区别是？",options:["计算复杂度","是否有标签","数据量大小","模型类型"],correctAnswer:1,explanation:"监督学习使用标注数据（有标签），无监督学习使用未标注数据。",difficulty:1},{id:"q-ml-linear-1",knowledgeId:"ml-linear",type:"single",question:"L1 正则化会产生什么效果？",options:["特征缩放","特征选择（稀疏解）","防止过拟合但不稀疏","加速收敛"],correctAnswer:1,explanation:"L1 正则化会产生稀疏解，使得一些特征权重变为 0，实现特征选择。",difficulty:2},{id:"q-ml-linear-2",knowledgeId:"ml-linear",type:"single",question:"逻辑回归用于解决什么类型的问题？",options:["回归","二分类","多分类","聚类"],correctAnswer:1,explanation:"逻辑回归主要用于二分类问题，输出概率值。",difficulty:1},{id:"q-ml-tree-1",knowledgeId:"ml-tree",type:"single",question:"决策树的 ID3 算法使用什么指标选择特征？",options:["信息增益","信息增益比","基尼系数","方差"],correctAnswer:0,explanation:"ID3 使用信息增益，C4.5 使用信息增益比，CART 使用基尼系数。",difficulty:2},{id:"q-ml-tree-2",knowledgeId:"ml-tree",type:"multiple",question:"以下哪些属于集成学习方法？",options:["随机森林","GBDT","XGBoost","SVM"],correctAnswer:[0,1,2],explanation:"随机森林、GBDT、XGBoost 都是集成学习方法，SVM 是单一模型。",difficulty:2},{id:"q-ml-eval-1",knowledgeId:"ml-eval",type:"single",question:"AUC（Area Under Curve）衡量的是什么？",options:["准确率","召回率","模型区分正负样本的能力","F1 分数"],correctAnswer:2,explanation:"AUC 衡量模型区分正负样本的能力，值越大越好。",difficulty:2},{id:"q-dl-fund-1",knowledgeId:"dl-fundamentals",type:"single",question:"反向传播算法的核心原理是什么？",options:["前向计算","链式法则","梯度下降","随机采样"],correctAnswer:1,explanation:"反向传播基于链式法则，从输出层向输入层逐层计算梯度。",difficulty:2},{id:"q-dl-fund-2",knowledgeId:"dl-fundamentals",type:"single",question:"ReLU 激活函数的优点是？",options:["处处可导","避免梯度消失","输出范围有限","计算复杂"],correctAnswer:1,explanation:"ReLU 在正值区间梯度为常数，有效缓解了梯度消失问题。",difficulty:2},{id:"q-dl-cnn-1",knowledgeId:"dl-cnn",type:"single",question:"卷积操作的主要作用是什么？",options:["降维","特征提取","分类","归一化"],correctAnswer:1,explanation:"卷积通过滑动窗口提取局部特征，是 CNN 的核心操作。",difficulty:1},{id:"q-dl-cnn-2",knowledgeId:"dl-cnn",type:"single",question:"池化层的作用是什么？",options:["增加参数","特征选择","降采样（减少计算量）","非线性变换"],correctAnswer:2,explanation:"池化层通过降采样减少特征图尺寸和计算量，同时增加平移不变性。",difficulty:2},{id:"q-dl-rnn-1",knowledgeId:"dl-rnn",type:"single",question:"LSTM 解决了 RNN 的什么问题？",options:["过拟合","梯度消失/爆炸","计算复杂度","内存不足"],correctAnswer:1,explanation:"LSTM 通过门控机制解决了 RNN 的梯度消失和梯度爆炸问题。",difficulty:2},{id:"q-dl-transformer-1",knowledgeId:"dl-transformer",type:"single",question:"Transformer 的核心创新是什么？",options:["卷积操作","自注意力机制","循环结构","池化操作"],correctAnswer:1,explanation:"Transformer 的核心是自注意力机制，可以并行计算序列中任意位置的依赖关系。",difficulty:2},{id:"q-dl-transformer-2",knowledgeId:"dl-transformer",type:"multiple",question:"Transformer 包含哪些关键组件？",options:["自注意力","位置编码","前馈网络","卷积层"],correctAnswer:[0,1,2],explanation:"Transformer 包含自注意力、位置编码、前馈网络等组件，不包含卷积层。",difficulty:3},{id:"q-llm-pretrain-1",knowledgeId:"llm-pretrain",type:"single",question:"SFT（监督微调）在大模型训练流程中的作用是？",options:["预训练","对齐人类偏好","增强推理能力","减少参数量"],correctAnswer:1,explanation:"SFT 通过标注数据微调预训练模型，使其输出与人类偏好对齐。",difficulty:2},{id:"q-llm-rag-1",knowledgeId:"llm-rag",type:"single",question:"RAG 的主要目的是什么？",options:["加速训练","增强模型的知识时效性和准确性","减少推理延迟","增加模型参数"],correctAnswer:1,explanation:"RAG 通过检索外部知识增强模型回答的准确性和时效性。",difficulty:2},{id:"q-llm-agent-1",knowledgeId:"llm-agent",type:"single",question:"ReAct 框架的核心思想是？",options:["纯推理","推理与行动交替","纯行动","监督学习"],correctAnswer:1,explanation:"ReAct 通过推理（Reason）和行动（Act）交替进行，让模型逐步解决问题。",difficulty:2}],ls=e=>nn.filter(o=>o.knowledgeId===e),cs=[{agent:"captain",text:"你好呀，我是灵境，你的专属 AI 学习队长。在正式为你启动学习之前，我想先简单地认识你一下——你目前的专业和年级是？"},{user:"我是人工智能专业大三学生，目标是考研深造大模型方向。"},{agent:"captain",text:"很棒的方向！大模型这条路既需要扎实的数学与深度学习基础，也考验工程能力。你目前高数、线代、概率的自评大概在什么水平？"},{user:"高数 78、线代 65、概率 72，Python 还算熟练。"},{agent:"captain",text:"了解了，基础很扎实。学习方式上，你更偏好看图解、听讲解、读文字，还是直接动手敲代码？或者几种混合？"},{user:"我比较喜欢图解 + 代码实操，纯公式推导容易走神。"},{agent:"captain",text:"明白，视觉+实践型学习者。我再问你两个问题：你过去学习 AI 时最容易在哪类知识点上栽跟头？你希望我们这次学习节奏是冲刺型还是稳健型？"},{user:"梯度爆炸/消失这块老搞混，动态规划边界也容易漏。节奏上希望稳健一些，每天 1-2 小时。"},{agent:"captain",text:"好的，信息已经齐全。我正在为你构建 6 维学习画像，并预生成首条学习路径。请稍候——你的专属智能体编队即将就位。"}],ds=[{name:"掌握度",score:78,benchmark:75},{name:"熟练度",score:72,benchmark:70},{name:"迁移力",score:68,benchmark:65},{name:"坚持度",score:86,benchmark:70},{name:"创新力",score:74,benchmark:65}],W=[{id:"ai-intro",chapter:1,title:"人工智能的定义与范畴",parentId:null,difficulty:1,estimatedMinutes:25,prerequisites:[],summary:"界定人工智能的研究对象、强弱 AI 之分，以及与机器学习、深度学习的关系。",category:"concept"},{id:"ai-history",chapter:1,title:"AI 发展三次浪潮",parentId:null,difficulty:1,estimatedMinutes:30,prerequisites:["ai-intro"],summary:"梳理符号主义、连接主义、深度学习三次浪潮的关键事件与代表成果。",category:"history"},{id:"ai-schools",chapter:1,title:"三大研究学派",parentId:null,difficulty:2,estimatedMinutes:35,prerequisites:["ai-history"],summary:"符号主义、连接主义、行为主义的方法论与代表人物。",category:"concept"},{id:"ai-ethics",chapter:1,title:"AI 伦理与安全",parentId:null,difficulty:2,estimatedMinutes:40,prerequisites:["ai-intro"],summary:"公平性、可解释性、隐私保护、价值对齐等核心议题。",category:"concept"},{id:"search-uninformed",chapter:2,title:"无信息搜索策略",parentId:null,difficulty:2,estimatedMinutes:40,prerequisites:["ai-intro"],summary:"BFS、DFS、UCS 的完备性、最优性与复杂度分析。",category:"algorithm"},{id:"search-informed",chapter:2,title:"启发式搜索 A*",parentId:null,difficulty:3,estimatedMinutes:50,prerequisites:["search-uninformed"],summary:"A* 算法的可采纳性、一致性、启发函数设计。",category:"algorithm"},{id:"search-local",chapter:2,title:"局部搜索与优化",parentId:null,difficulty:3,estimatedMinutes:45,prerequisites:["search-informed"],summary:" hill-climbing、模拟退火、遗传算法的原理与对比。",category:"algorithm"},{id:"search-adversarial",chapter:2,title:"对抗搜索与博弈",parentId:null,difficulty:4,estimatedMinutes:55,prerequisites:["search-informed"],summary:"Minimax、α-β 剪枝、蒙特卡洛树搜索 MCTS。",category:"algorithm"},{id:"kr-logic",chapter:3,title:"谓词逻辑与推理",parentId:null,difficulty:3,estimatedMinutes:50,prerequisites:["ai-schools"],summary:"一阶逻辑、归结原理、前向/后向链推理。",category:"concept"},{id:"kr-frame",chapter:3,title:"框架与语义网络",parentId:null,difficulty:2,estimatedMinutes:35,prerequisites:["kr-logic"],summary:"框架表示法、语义网络、本体论 Ontology。",category:"concept"},{id:"kr-uncertain",chapter:3,title:"不确定知识与概率推理",parentId:null,difficulty:4,estimatedMinutes:60,prerequisites:["kr-logic"],summary:"贝叶斯网络、置信度方法、D-S 证据理论。",category:"concept"},{id:"kr-knowledge-graph",chapter:3,title:"知识图谱构建与应用",parentId:null,difficulty:3,estimatedMinutes:45,prerequisites:["kr-frame"],summary:"实体抽取、关系抽取、知识融合、推理问答。",category:"concept"},{id:"ml-overview",chapter:4,title:"机器学习范式与分类",parentId:null,difficulty:2,estimatedMinutes:35,prerequisites:["ai-schools"],summary:"监督、无监督、半监督、强化学习的范式区分。",category:"concept"},{id:"ml-linear",chapter:4,title:"线性模型与正则化",parentId:null,difficulty:3,estimatedMinutes:50,prerequisites:["ml-overview"],summary:"线性回归、逻辑回归、L1/L2 正则、偏差-方差权衡。",category:"model"},{id:"ml-tree",chapter:4,title:"决策树与集成学习",parentId:null,difficulty:3,estimatedMinutes:50,prerequisites:["ml-linear"],summary:"ID3/C4.5/CART、Bagging、随机森林、GBDT、XGBoost。",category:"model"},{id:"ml-eval",chapter:4,title:"模型评估与超参调优",parentId:null,difficulty:3,estimatedMinutes:40,prerequisites:["ml-linear"],summary:"交叉验证、混淆矩阵、PR/F1/ROC/AUC、网格/贝叶斯搜索。",category:"concept"},{id:"dl-fundamentals",chapter:5,title:"神经网络与反向传播",parentId:null,difficulty:4,estimatedMinutes:60,prerequisites:["ml-linear"],summary:"感知机、MLP、激活函数、链式法则与 BP 算法。",category:"model"},{id:"dl-cnn",chapter:5,title:"卷积神经网络 CNN",parentId:null,difficulty:4,estimatedMinutes:55,prerequisites:["dl-fundamentals"],summary:"卷积、池化、感受野、经典架构 LeNet/VGG/ResNet。",category:"model"},{id:"dl-rnn",chapter:5,title:"循环网络与序列建模",parentId:null,difficulty:4,estimatedMinutes:55,prerequisites:["dl-fundamentals"],summary:"RNN、LSTM、GRU、Seq2Seq、注意力机制雏形。",category:"model"},{id:"dl-transformer",chapter:5,title:"Transformer 与注意力",parentId:null,difficulty:5,estimatedMinutes:70,prerequisites:["dl-rnn"],summary:"Self-Attention、Multi-Head、位置编码、Encoder-Decoder。",category:"model"},{id:"llm-pretrain",chapter:6,title:"大模型预训练范式",parentId:null,difficulty:5,estimatedMinutes:65,prerequisites:["dl-transformer"],summary:"Scaling Law、Pretrain-SFT-RLHF、涌现能力、MoE。",category:"concept"},{id:"llm-rag",chapter:6,title:"检索增强生成 RAG",parentId:null,difficulty:4,estimatedMinutes:50,prerequisites:["llm-pretrain"],summary:"向量检索、Chunk 策略、Rerank、RAG 评估指标。",category:"algorithm"},{id:"llm-agent",chapter:6,title:"智能体 Agent 架构",parentId:null,difficulty:5,estimatedMinutes:60,prerequisites:["llm-pretrain"],summary:"ReAct、Plan-and-Execute、Tool Use、Memory 机制。",category:"concept"},{id:"llm-multiagent",chapter:6,title:"多智能体协同框架",parentId:null,difficulty:5,estimatedMinutes:65,prerequisites:["llm-agent"],summary:"角色分工、消息传递、辩论/协作/竞争、AutoGen/LangGraph。",category:"concept"}],ps=[{no:1,title:"AI 绪论与发展史",icon:"Scroll",color:"#F4A261",desc:"建立 AI 学科全景认知"},{no:2,title:"搜索与优化",icon:"Network",color:"#1B9AAA",desc:"经典问题求解的核心方法"},{no:3,title:"知识表示与推理",icon:"Share2",color:"#9D4EDD",desc:"符号 AI 的形式化基础"},{no:4,title:"机器学习基础",icon:"TrendingUp",color:"#E63946",desc:"数据驱动的学习范式"},{no:5,title:"深度学习",icon:"BrainCircuit",color:"#10B981",desc:"现代 AI 的核心引擎"},{no:6,title:"大模型与多智能体",icon:"Bot",color:"#22D3EE",desc:"通往 AGI 的前沿路径"}],ms=e=>W.find(o=>o.id===e),sn=[{matchKeywords:["局部搜索","local search","hill-climbing","模拟退火","遗传算法"],formula:"xₙ₊₁ = xₙ + Δx",formulaDesc:"x: 当前解 · Δx: 搜索步长",formalDefinition:"在状态空间中从当前解出发，通过邻域搜索寻找更优解"},{matchKeywords:["对抗搜索","博弈","adversarial","minimax","α-β","剪枝","mcts"],formula:"v = min(max(v₁, v₂), max(v₃, v₄))",formulaDesc:"v: 极小极大值 · vᵢ: 子节点值",formalDefinition:"在双人零和博弈中，一方最大化收益，另一方最小化对方收益"},{matchKeywords:["启发式搜索","a*","a星","astar"],formula:"f(n) = g(n) + h(n)",formulaDesc:"g: 已耗代价 · h: 启发式估计",formalDefinition:"结合路径代价与启发式信息的最优搜索策略"},{matchKeywords:["无信息搜索","bfs","dfs","ucs","广度","深度"],formula:"Q = {s} → expand → goal?",formulaDesc:"Q: 搜索队列 · s: 起始节点",formalDefinition:"不使用领域知识，仅按固定策略遍历状态空间"},{matchKeywords:["梯度下降","gradient descent"],formula:"θ = θ - η · ∇J(θ)",formulaDesc:"η: 学习率 · ∇J: 损失梯度",formalDefinition:"沿损失函数负梯度方向更新参数，寻找极小值点"},{matchKeywords:["反向传播","backpropagation","bp"],formula:"∂J/∂w = ∂J/∂z · ∂z/∂w",formulaDesc:"链式法则 · 逐层求导",formalDefinition:"从输出层反向计算梯度，逐层更新神经网络参数"},{matchKeywords:["transformer","注意力","attention","self-attention"],formula:"Attention(Q,K,V) = softmax(QKᵀ/√dₖ)V",formulaDesc:"Q: 查询 · K: 键 · V: 值",formalDefinition:"通过计算查询与键的相似度，加权求和得到输出"},{matchKeywords:["cnn","卷积","convolution"],formula:"y = σ(W*x + b)",formulaDesc:"W: 卷积核 · *: 卷积运算",formalDefinition:"通过局部感受野和权值共享提取空间特征"},{matchKeywords:["rnn","lstm","gru","循环"],formula:"hₜ = σ(Wₓh·xₜ + Wₕh·hₜ₋₁ + b)",formulaDesc:"hₜ: 当前隐态 · hₜ₋₁: 前一隐态",formalDefinition:"通过隐状态传递，处理序列数据的时序依赖"},{matchKeywords:["逻辑回归","logistic"],formula:"ŷ = σ(w·x + b) = 1/(1+e⁻(w·x+b))",formulaDesc:"σ: Sigmoid 函数",formalDefinition:"通过 Sigmoid 函数将线性组合映射到 [0,1] 概率区间"},{matchKeywords:["决策树","decision tree","id3","c4.5"],formula:"Gain = H(S) - Σ|Sᵢ|/|S|·H(Sᵢ)",formulaDesc:"H: 熵 · Gain: 信息增益",formalDefinition:"基于信息增益选择最优特征，递归划分数据集"},{matchKeywords:["线性模型","线性回归","linear"],formula:"ŷ = w·x + b = Σwᵢxᵢ + b",formulaDesc:"w: 权重 · b: 偏置",formalDefinition:"通过特征的线性组合预测输出"},{matchKeywords:["正则化","regularization","l1","l2","lasso","ridge"],formula:"J = MSE + λ(Σ|wᵢ| + Σwᵢ²)",formulaDesc:"λ: 正则系数",formalDefinition:"在损失函数中加入权重惩罚，防止过拟合"},{matchKeywords:["贝叶斯","bayes","概率推理","bayesian"],formula:"P(A|B) = P(B|A)·P(A)/P(B)",formulaDesc:"贝叶斯定理",formalDefinition:"基于先验概率和似然更新后验概率"},{matchKeywords:["谓词逻辑","predicate logic","一阶逻辑","推理"],formula:"∀x (P(x) → Q(x))",formulaDesc:"全称量词 · 蕴含关系",formalDefinition:"使用谓词和量词进行形式化推理"},{matchKeywords:["知识图谱","knowledge graph","实体","关系"],formula:"G = (E, R, T)",formulaDesc:"E: 实体 · R: 关系 · T: 三元组",formalDefinition:"以图结构存储实体及其关系的知识表示"},{matchKeywords:["机器学习","machine learning","监督","无监督","强化"],formula:"y = f(x; θ) ≈ y*",formulaDesc:"f: 模型 · θ: 参数 · y*: 真实值",formalDefinition:"通过数据学习函数映射，使预测接近真实值"},{matchKeywords:["评价","评估","eval","metric","f1","auc","roc"],formula:"F1 = 2·P·R/(P+R)",formulaDesc:"P: 精确率 · R: 召回率",formalDefinition:"综合衡量分类模型的精确率与召回率"},{matchKeywords:["大模型","llm","预训练","pretrain","sft","rlhf"],formula:"L = Lₚᵣₑ + αLₛբₜ + βLᵣₗₕբ",formulaDesc:"多阶段训练损失",formalDefinition:"预训练+微调+人类反馈强化学习的三阶段范式"},{matchKeywords:["rag","检索增强","retrieval"],formula:"Answer = LLM(Context + Query)",formulaDesc:"Context: 检索文档",formalDefinition:"先检索相关文档，再结合查询生成回答"},{matchKeywords:["智能体","agent","react","tool use"],formula:"Agent = (Perception → Reasoning → Action)",formulaDesc:"感知-推理-行动循环",formalDefinition:"具备感知、推理、行动能力的自主智能系统"},{matchKeywords:["多智能体","multi-agent","协同","辩论"],formula:"Global = f(Agent₁, Agent₂, ..., Agentₙ)",formulaDesc:"个体交互产生全局行为",formalDefinition:"多个智能体通过协作或竞争完成复杂任务"},{matchKeywords:["人工智能","ai","定义","范畴"],formula:"AI = {感知, 推理, 学习, 行动}",formulaDesc:"四大核心能力",formalDefinition:"使计算机系统能够模拟人类智能的技术"},{matchKeywords:["伦理","ethics","公平","可解释"],formula:"Fairness: P(Y|X,A=a) = P(Y|X,A=b)",formulaDesc:"不同群体预测一致",formalDefinition:"确保 AI 系统公平、可解释、负责任"},{matchKeywords:["搜索策略","search strategy"],formula:"Strategy = (Frontier, Expansion, Goal)",formulaDesc:"搜索三要素",formalDefinition:"在状态空间中寻找目标状态的系统化方法"}];function an(e){const o=e.toLowerCase();for(const t of sn)if(t.matchKeywords.some(r=>o.includes(r.toLowerCase())))return t;return{matchKeywords:[],formula:"Goal = argmax U(a, s)",formulaDesc:"A: 动作集合 · s: 当前状态 · U: 效用函数",formalDefinition:"在动作集合 A 中，给定状态 s，寻找使效用函数 U 最大的解"}}const ln=[{id:"transformer",matchKeywords:["transformer","注意力","attention","自注意力","self-attention","multi-head","多头"],title:"Self-Attention",code:`import torch
import torch.nn.functional as F

def scaled_dot_product_attention(Q, K, V):
    d_k = Q.size(-1)
    scores = torch.matmul(Q, K.transpose(-2, -1)) / (d_k ** 0.5)
    weights = F.softmax(scores, dim=-1)
    output = torch.matmul(weights, V)
    return output, weights

# Q, K, V: [batch, heads, seq, d_k]
Q = torch.randn(1, 8, 10, 64)
K = torch.randn(1, 8, 10, 64)
V = torch.randn(1, 8, 10, 64)
out, w = scaled_dot_product_attention(Q, K, V)
print(out.shape)  # [1, 8, 10, 64]`,displayLines:[{text:"import torch",type:"keyword"},{text:"import torch.nn.functional as F",type:"keyword"},{text:"",type:"plain"},{text:"def scaled_dot_product_attention(Q, K, V):",type:"func"},{text:"    d_k = Q.size(-1)",type:"plain"},{text:"    scores = torch.matmul(Q, K.T) / sqrt(d_k)",type:"plain"},{text:"    weights = F.softmax(scores, dim=-1)",type:"func"},{text:"    output = torch.matmul(weights, V)",type:"plain"},{text:"    return output, weights",type:"keyword"},{text:"",type:"plain"},{text:"out, w = attention(Q, K, V)  # [1,8,10,64]",type:"string"}],vars:{name:"attention",init:"scores = Q·Kᵀ / √d_k",steps:["scores → [1,8,10,10]","weights = softmax(scores)","output = weights · V","out.shape = [1,8,10,64]"]}},{id:"cnn",matchKeywords:["cnn","卷积","convolution","conv","resnet","lenet","vgg","池化","pooling"],title:"Conv2D Forward",code:`import torch
import torch.nn as nn

class SimpleCNN(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(32 * 16 * 16, num_classes)

    def forward(self, x):
        x = self.pool(torch.relu(self.bn1(self.conv1(x))))
        x = x.view(x.size(0), -1)
        return self.fc(x)

model = SimpleCNN()
x = torch.randn(1, 3, 32, 32)
out = model(x)  # [1, 10]`,displayLines:[{text:"import torch.nn as nn",type:"keyword"},{text:"",type:"plain"},{text:"class SimpleCNN(nn.Module):",type:"func"},{text:"    def __init__(self, num_classes=10):",type:"func"},{text:"        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)",type:"plain"},{text:"        self.bn1 = nn.BatchNorm2d(32)",type:"plain"},{text:"        self.pool = nn.MaxPool2d(2, 2)",type:"plain"},{text:"        self.fc = nn.Linear(32*16*16, num_classes)",type:"plain"},{text:"",type:"plain"},{text:"    def forward(self, x):",type:"func"},{text:"        x = pool(relu(bn1(conv1(x))))",type:"plain"},{text:"        return self.fc(x.view(x.size(0), -1))",type:"keyword"}],vars:{name:"cnn",init:"input: [1,3,32,32]",steps:["conv1 → [1,32,32,32]","bn1 + relu → [1,32,32,32]","pool → [1,32,16,16]","fc → [1,10]"]}},{id:"rnn-lstm",matchKeywords:["rnn","lstm","gru","循环","序列","sequence","recurrent","门控"],title:"LSTM Cell",code:`import torch
import torch.nn as nn

class LSTMCell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.forget_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.input_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.output_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.cell_gate = nn.Linear(input_size + hidden_size, hidden_size)

    def forward(self, x, h, c):
        combined = torch.cat([x, h], dim=1)
        f = torch.sigmoid(self.forget_gate(combined))
        i = torch.sigmoid(self.input_gate(combined))
        o = torch.sigmoid(self.output_gate(combined))
        c_tilde = torch.tanh(self.cell_gate(combined))
        c_new = f * c + i * c_tilde
        h_new = o * torch.tanh(c_new)
        return h_new, c_new`,displayLines:[{text:"class LSTMCell(nn.Module):",type:"func"},{text:"    def __init__(self, input_size, hidden_size):",type:"func"},{text:"        self.forget_gate = nn.Linear(...)",type:"plain"},{text:"        self.input_gate = nn.Linear(...)",type:"plain"},{text:"        self.output_gate = nn.Linear(...)",type:"plain"},{text:"",type:"plain"},{text:"    def forward(self, x, h, c):",type:"func"},{text:"        combined = torch.cat([x, h], dim=1)",type:"plain"},{text:"        f = sigmoid(forget_gate(combined))",type:"func"},{text:"        i = sigmoid(input_gate(combined))",type:"func"},{text:"        c_new = f * c + i * tanh(cell_g)",type:"plain"},{text:"        h_new = o * tanh(c_new)",type:"keyword"}],vars:{name:"lstm",init:"h, c: [batch, hidden]",steps:["f = σ(W_f·[x,h])  遗忘门","i = σ(W_i·[x,h])  输入门","c̃ = tanh(W_c·[x,h])","c = f*c + i*c̃","h = o*tanh(c)"]}},{id:"astar",matchKeywords:["a*","a星","启发式搜索","heuristic","搜索策略","最短路径","pathfinding"],title:"A* Search",code:`import heapq

def astar(graph, start, goal, heuristic):
    open_set = [(heuristic(start), start)]
    came_from = {}
    g_score = {start: 0}

    while open_set:
        _, current = heapq.heappop(open_set)
        if current == goal:
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            return path[::-1]

        for neighbor, cost in graph[current]:
            tentative = g_score[current] + cost
            if tentative < g_score.get(neighbor, float('inf')):
                came_from[neighbor] = current
                g_score[neighbor] = tentative
                f = tentative + heuristic(neighbor)
                heapq.heappush(open_set, (f, neighbor))
    return None  # 无路径`,displayLines:[{text:"import heapq",type:"keyword"},{text:"",type:"plain"},{text:"def astar(graph, start, goal, h):",type:"func"},{text:"    open_set = [(h(start), start)]",type:"plain"},{text:"    came_from = {}",type:"plain"},{text:"    g_score = {start: 0}",type:"plain"},{text:"",type:"plain"},{text:"    while open_set:",type:"keyword"},{text:"        _, cur = heappop(open_set)",type:"func"},{text:"        if cur == goal: reconstruct path",type:"string"},{text:"        for nb, cost in graph[cur]:",type:"plain"},{text:"            tentative = g[cur] + cost",type:"plain"}],vars:{name:"astar",init:"open=[(f(start),start)]",steps:["弹出 f 最小的节点","遍历邻居计算 tentative_g","if tentative < g[nb]: 更新","f = g + h, 压入 open_set","goal 命中 → 回溯路径"]}},{id:"gradient-descent",matchKeywords:["梯度下降","gradient descent","优化","optimization","梯度","gradient","学习率","learning rate"],title:"Gradient Descent",code:`import numpy as np

def gradient_descent(f_grad, x0, lr=0.01, max_iter=1000, tol=1e-6):
    x = x0
    history = []
    for i in range(max_iter):
        grad = f_grad(x)
        x_new = x - lr * grad
        loss = 0.5 * np.sum(x_new ** 2)
        history.append(loss)
        if np.linalg.norm(x_new - x) < tol:
            print(f"收敛于第 {i} 步, loss={loss:.6f}")
            return x_new, history
        x = x_new
    return x, history

# 最小化 f(x) = 0.5 * ||x||^2,  grad = x
x_opt, hist = gradient_descent(lambda x: x, x0=np.array([5.0, -3.0]))
print(f"最优解: {x_opt}")`,displayLines:[{text:"import numpy as np",type:"keyword"},{text:"",type:"plain"},{text:"def gradient_descent(f_grad, x0, lr=0.01):",type:"func"},{text:"    x = x0",type:"plain"},{text:"    for i in range(max_iter):",type:"keyword"},{text:"        grad = f_grad(x)",type:"func"},{text:"        x_new = x - lr * grad",type:"plain"},{text:"        loss = 0.5 * sum(x_new ** 2)",type:"plain"},{text:"        if norm(x_new - x) < tol:",type:"keyword"},{text:"            print(f'收敛于第 {i} 步')",type:"string"},{text:"            return x_new",type:"keyword"},{text:"        x = x_new",type:"plain"}],vars:{name:"gd",init:"x = [5.0, -3.0]",steps:["grad = [5.0, -3.0]","x = x - 0.01*grad","loss = 0.5*||x||²","||Δx|| < 1e-6?","收敛 ✓"]}},{id:"backprop",matchKeywords:["反向传播","backpropagation","bp","链式法则","chain rule","梯度消失","梯度爆炸"],title:"Backpropagation",code:`import numpy as np

def backprop(X, y, W1, b1, W2, b2, lr):
    # 前向传播
    z1 = X @ W1 + b1
    a1 = 1 / (1 + np.exp(-z1))  # sigmoid
    z2 = a1 @ W2 + b2
    y_pred = 1 / (1 + np.exp(-z2))

    # 反向传播
    dz2 = y_pred - y
    dW2 = a1.T @ dz2
    da1 = dz2 @ W2.T
    dz1 = da1 * a1 * (1 - a1)  # sigmoid 导数
    dW1 = X.T @ dz1

    # 参数更新
    W1 -= lr * dW1
    W2 -= lr * dW2
    return W1, W2, loss(y_pred, y)`,displayLines:[{text:"def backprop(X, y, W1, b1, W2, b2, lr):",type:"func"},{text:"    # 前向传播",type:"comment"},{text:"    z1 = X @ W1 + b1",type:"plain"},{text:"    a1 = sigmoid(z1)  # 激活",type:"func"},{text:"    z2 = a1 @ W2 + b2",type:"plain"},{text:"    y_pred = sigmoid(z2)",type:"func"},{text:"",type:"plain"},{text:"    # 反向传播",type:"comment"},{text:"    dz2 = y_pred - y",type:"plain"},{text:"    dW2 = a1.T @ dz2",type:"plain"},{text:"    dz1 = da1 * a1 * (1-a1)  # 链式",type:"plain"},{text:"    W1 -= lr * dW1; W2 -= lr * dW2",type:"keyword"}],vars:{name:"bp",init:"W1, W2 随机初始化",steps:["前向: z1→a1→z2→ŷ","dz2 = ŷ - y","dW2 = a1ᵀ · dz2","dz1 = da1 · σ'(z1)","W -= lr · dW  更新"]}},{id:"kmeans",matchKeywords:["kmeans","k-means","聚类","clustering","无监督","unsupervised"],title:"K-Means",code:`import numpy as np

def kmeans(X, k, max_iter=100):
    centroids = X[np.random.choice(len(X), k, replace=False)]
    for _ in range(max_iter):
        # 计算每个点到各质心的距离
        dists = np.linalg.norm(X[:, None] - centroids, axis=2)
        labels = np.argmin(dists, axis=1)
        # 更新质心
        new_centroids = np.array([
            X[labels == i].mean(0) if np.any(labels == i) else centroids[i]
            for i in range(k)
        ])
        if np.allclose(centroids, new_centroids):
            break
        centroids = new_centroids
    return labels, centroids`,displayLines:[{text:"import numpy as np",type:"keyword"},{text:"",type:"plain"},{text:"def kmeans(X, k, max_iter=100):",type:"func"},{text:"    centroids = X[random.choice(len(X), k)]",type:"plain"},{text:"    for _ in range(max_iter):",type:"keyword"},{text:"        dists = norm(X[:,None] - centroids)",type:"func"},{text:"        labels = argmin(dists, axis=1)",type:"func"},{text:"        new_c = [X[labels==i].mean(0)",type:"plain"},{text:"                  for i in range(k)]",type:"plain"},{text:"        if allclose(centroids, new_c):",type:"func"},{text:"            break",type:"keyword"},{text:"        centroids = new_c",type:"plain"}],vars:{name:"kmeans",init:"centroids = random k",steps:["计算每个点到质心距离","labels = argmin(dists)","new_c = 各簇均值","质心不再变化?","收敛 ✓"]}},{id:"logistic-regression",matchKeywords:["逻辑回归","logistic","回归","regression","分类","classification","sigmoid"],title:"Logistic Regression",code:`import numpy as np

class LogisticRegression:
    def __init__(self, lr=0.01, epochs=100):
        self.lr = lr
        self.epochs = epochs

    def fit(self, X, y):
        n, d = X.shape
        self.w = np.zeros(d)
        self.b = 0
        for epoch in range(self.epochs):
            z = X @ self.w + self.b
            y_pred = 1 / (1 + np.exp(-z))
            # 梯度
            grad_w = X.T @ (y_pred - y) / n
            grad_b = (y_pred - y).mean()
            self.w -= self.lr * grad_w
            self.b -= self.lr * grad_b
        return self

    def predict(self, X):
        return (1 / (1 + np.exp(-(X @ self.w + self.b))) >= 0.5).astype(int)`,displayLines:[{text:"class LogisticRegression:",type:"func"},{text:"    def __init__(self, lr=0.01, epochs=100):",type:"func"},{text:"        self.lr = lr; self.epochs = epochs",type:"plain"},{text:"",type:"plain"},{text:"    def fit(self, X, y):",type:"func"},{text:"        self.w = zeros(d); self.b = 0",type:"plain"},{text:"        for epoch in range(epochs):",type:"keyword"},{text:"            z = X @ self.w + self.b",type:"plain"},{text:"            y_pred = sigmoid(z)",type:"func"},{text:"            grad_w = X.T @ (y_pred - y) / n",type:"plain"},{text:"            self.w -= lr * grad_w",type:"plain"},{text:"            self.b -= lr * grad_b",type:"keyword"}],vars:{name:"lr",init:"w = zeros(d), b = 0",steps:["z = X·w + b","ŷ = σ(z) = 1/(1+e⁻ᶻ)","grad_w = Xᵀ·(ŷ-y)/n","w -= lr · grad_w","收敛"]}},{id:"decision-tree",matchKeywords:["决策树","decision tree","id3","c4.5","cart","信息增益","information gain","熵","entropy"],title:"Decision Tree (ID3)",code:`import numpy as np

def entropy(y):
    _, counts = np.unique(y, return_counts=True)
    p = counts / len(y)
    return -np.sum(p * np.log2(p + 1e-10))

def info_gain(X, y, feature, threshold):
    left = y[X[:, feature] <= threshold]
    right = y[X[:, feature] > threshold]
    n = len(y)
    if len(left) == 0 or len(right) == 0:
        return 0
    return entropy(y) - (len(left)/n * entropy(left)
                        + len(right)/n * entropy(right))

def best_split(X, y):
    best_gain, best_feat, best_thr = 0, 0, 0
    for feat in range(X.shape[1]):
        for thr in np.unique(X[:, feat]):
            gain = info_gain(X, y, feat, thr)
            if gain > best_gain:
                best_gain, best_feat, best_thr = gain, feat, thr
    return best_feat, best_thr, best_gain`,displayLines:[{text:"import numpy as np",type:"keyword"},{text:"",type:"plain"},{text:"def entropy(y):",type:"func"},{text:"    p = counts / len(y)",type:"plain"},{text:"    return -sum(p * log2(p))",type:"func"},{text:"",type:"plain"},{text:"def info_gain(X, y, feat, thr):",type:"func"},{text:"    left = y[X[:,feat] <= thr]",type:"plain"},{text:"    right = y[X[:,feat] > thr]",type:"plain"},{text:"    return H(y) - weighted_H(left,right)",type:"plain"},{text:"",type:"plain"},{text:"best = max(info_gain)  →  split",type:"string"}],vars:{name:"dt",init:"H(y) = 熵",steps:["遍历每个特征 & 阈值","计算 info_gain = H - H_split","选取最大增益分裂","递归构建子树","叶节点 = 多数类"]}},{id:"rag",matchKeywords:["rag","检索增强","retrieval","向量检索","embedding","rerank"],title:"RAG Pipeline",code:`import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

def rag_retrieve(query, documents, embeddings, top_k=3):
    # 1. 向量化查询
    q_vec = embed(query)
    # 2. 计算相似度 (cosine)
    scores = np.dot(embeddings, q_vec) / (
        np.linalg.norm(embeddings, axis=1) * np.linalg.norm(q_vec)
    )
    # 3. 取 Top-K
    top_idx = np.argsort(scores)[-top_k:][::-1]
    retrieved = [documents[i] for i in top_idx]
    # 4. Rerank（可选）
    reranked = rerank(query, retrieved)
    return reranked, scores[top_idx]

def rag_generate(query, context_docs, llm):
    context = "\\n\\n".join(context_docs)
    prompt = f"基于以下资料回答问题：\\n{context}\\n\\n问题：{query}"
    return llm.generate(prompt)`,displayLines:[{text:"def rag_retrieve(query, docs, embeddings):",type:"func"},{text:"    q_vec = embed(query)  # 向量化",type:"func"},{text:"    scores = cosine_sim(embeddings, q_vec)",type:"func"},{text:"    top_idx = argsort(scores)[-k:][::-1]",type:"plain"},{text:"    retrieved = [docs[i] for i in top_idx]",type:"plain"},{text:"    reranked = rerank(query, retrieved)",type:"func"},{text:"    return reranked",type:"keyword"},{text:"",type:"plain"},{text:"def rag_generate(query, ctx, llm):",type:"func"},{text:"    context = '\\n'.join(ctx)",type:"string"},{text:"    prompt = f'资料:{context}\\n问题:{query}'",type:"string"},{text:"    return llm.generate(prompt)",type:"keyword"}],vars:{name:"rag",init:"query → embed",steps:["cosine_sim(query, docs)","Top-K 检索","Rerank 重排序","拼接 context + query","LLM 生成回答"]}}],cn={id:"default",matchKeywords:[],title:"Core Implementation",code:`import numpy as np
from dataclasses import dataclass

@dataclass
class Config:
    learning_rate: float = 1e-3
    max_steps: int = 1000
    tolerance: float = 1e-6

def optimize(config: Config):
    np.random.seed(42)
    state = np.random.randn(8)
    history = []

    for step in range(config.max_steps):
        grad = 2 * state  # 模拟梯度
        state = state - config.learning_rate * grad
        loss = float(np.sum(state ** 2))
        history.append(loss)
        if np.linalg.norm(grad) < config.tolerance:
            print(f"收敛于第 {step} 步, loss={loss:.6f}")
            return state, history
    return state, history

cfg = Config()
result, hist = optimize(cfg)
print(f"最终结果: {result}")`,displayLines:[{text:"import numpy as np",type:"keyword"},{text:"from dataclasses import dataclass",type:"keyword"},{text:"",type:"plain"},{text:"@dataclass",type:"func"},{text:"class Config:",type:"func"},{text:"    learning_rate: float = 1e-3",type:"plain"},{text:"    max_steps: int = 1000",type:"plain"},{text:"",type:"plain"},{text:"def optimize(config):",type:"func"},{text:"    state = random.randn(8)",type:"plain"},{text:"    for step in range(max_steps):",type:"keyword"},{text:"        grad = 2 * state  # 梯度",type:"comment"}],vars:{name:"default",init:"state = randn(8)",steps:["grad = 2 * state","state -= lr * grad","loss = ||state||²","||grad|| < tol?","收敛 ✓"]}};function fe(e){const o=e.toLowerCase(),t=an(e);for(const r of ln)if(r.matchKeywords.some(n=>o.includes(n.toLowerCase())))return{...r,formula:t.formula,formulaDesc:t.formulaDesc,formalDefinition:t.formalDefinition};return{...cn,formula:t.formula,formulaDesc:t.formulaDesc,formalDefinition:t.formalDefinition}}function _t(e){const o=encodeURIComponent(e),t=encodeURIComponent(e);return[{title:`B站搜索：${e}`,platform:"Bilibili",url:`https://search.bilibili.com/all?keyword=${o}`,duration:"10-60 min",desc:"B站拥有丰富的中文教学视频资源，搜索结果涵盖高校公开课、技术博主讲解等"},{title:`YouTube: ${e}`,platform:"YouTube",url:`https://www.youtube.com/results?search_query=${t}`,duration:"15-90 min",desc:"YouTube 上有大量英文技术教程，包含 3Blue1Brown、Stanford CS 等优质频道"},{title:`Coursera 课程：${e}`,platform:"Coursera",url:`https://www.coursera.org/search?query=${t}`,duration:"4-12 周",desc:"Coursera 提供系统化在线课程，含作业与证书，适合深度学习"},{title:`MIT OpenCourseWare: ${e}`,platform:"MIT OCW",url:`https://www.google.com/search?q=site:ocw.mit.edu+${t}`,duration:"50-90 min",desc:"MIT 公开课涵盖 AI/ML 核心课程，含讲义、作业与完整视频"},{title:`Stanford CS 系列：${e}`,platform:"Stanford CS",url:`https://www.google.com/search?q=site:youtube.com+stanford+${t}`,duration:"60-80 min",desc:"Stanford CS221/CS224N/CS231N 等经典 AI 课程讲座视频"},{title:`arXiv 论文：${e}`,platform:"arXiv",url:`https://arxiv.org/search/?query=${t}&searchtype=all`,duration:"阅读 30-60 min",desc:"arXiv 预印本论文库，获取最新学术研究成果与原始论文"}]}const zt={document:{label:"讲解文档",icon:"FileText",color:"#1B9AAA",desc:"由解构者拆解 + 编织者撰写，结构清晰的学术讲解"},mindmap:{label:"思维导图",icon:"Network",color:"#F4A261",desc:"解构者输出骨架，视觉师渲染节点连线"},quiz:{label:"题库",icon:"ListChecks",color:"#9D4EDD",desc:"出题官针对画像易错点生成多梯度题目"},reading:{label:"拓展阅读",icon:"BookOpen",color:"#10B981",desc:"编织者汇编论文与博文，校验官补全引用"},animation:{label:"教学动画",icon:"Clapperboard",color:"#22D3EE",desc:"视觉师设计 4 分镜矢量动画，播放器支持播放/暂停/进度拖拽"},code:{label:"代码实操",icon:"Code2",color:"#F87171",desc:"实操匠生成可运行代码与环境配置"}},Ct=e=>{const o=["历史","发展","浪潮","演进","起源","简史","发展史","里程碑"],t=["算法","搜索","排序","优化","策略","剪枝","迭代","求解","计算","A*","RAG"],r=["模型","网络","神经","架构","感知机","SVM","决策树","聚类","回归","CNN","RNN","Transformer"];return o.some(n=>e.includes(n))?"history":r.some(n=>e.includes(n))?"model":t.some(n=>e.includes(n))?"algorithm":"concept"},dn=e=>`# ${e.title}

> 学习时长约 ${e.estimatedMinutes} 分钟 · 难度 ${"★".repeat(e.difficulty)}${"☆".repeat(5-e.difficulty)}
> 📚 历史类知识点 · 建议结合时间轴动画学习

## 1. 历史背景与起源

${e.summary}

### 1.1 时代背景

任何技术的诞生都离不开特定的时代土壤。${e.title}的出现，既是学术探索的必然结果，也是社会需求推动的产物。

> 💡 **思考题**：为什么是在这个时间点，而不是更早或更晚？

### 1.2 先驱人物

| 人物 | 贡献 | 时代 |
|------|------|------|
| 先驱A | 奠基性理论工作 | 20世纪中叶 |
| 先驱B | 关键算法突破 | 20世纪后期 |
| 先驱C | 工程实践验证 | 21世纪初 |

[SVG:history-pioneers]

## 2. 发展阶段详解

### 2.1 萌芽期（1950s-1960s）

**核心特征**：理论奠基，概念初现

关键事件：
- 1950年：图灵测试提出
- 1956年：达特茅斯会议，AI 概念诞生
- 1958年：感知机模型提出

$$
\\text{Perceptron}: y = \\sigma\\left(\\sum_{i=1}^n w_i x_i + b\\right)
$$

其中 $\\sigma$ 为阶跃函数，$w_i$ 为权重，$b$ 为偏置。

### 2.2 第一次浪潮（1960s-1970s）

**核心特征**：符号主义盛行，期望过高

- 专家系统开始出现
- 逻辑推理成为主流
- 政府大力资助

> ⚠️ **历史教训**：过高的期望与实际能力的落差，导致了第一次"AI 寒冬"。

### 2.3 低潮与反思（1970s-1980s）

**核心特征**：资金削减，研究转向

研究方向的转变：
- 从通用智能转向特定领域
- 从符号推理转向知识工程
- 从理论探索转向工程应用

[SVG:winter-period]

### 2.4 第二次浪潮（1980s-1990s）

**核心特征**：专家系统商业化，连接主义复兴

关键进展：
- 反向传播算法重新发现
- 专家系统广泛应用
- 贝叶斯网络兴起

$$
\\frac{\\partial E}{\\partial w_{ij}} = \\delta_j \\cdot o_i
$$

其中 $\\delta_j$ 为第 $j$ 个神经元的误差项，$o_i$ 为第 $i$ 个神经元的输出。

### 2.5 第三次浪潮（2010s-至今）

**核心特征**：深度学习爆发，数据驱动

推动因素：
- 计算能力指数级增长（GPU）
- 互联网产生海量数据
- 算法创新（CNN、RNN、Transformer）

## 3. 关键里程碑事件

| 时间 | 事件 | 意义 |
|------|------|------|
| 1950 | 图灵测试 | 定义了智能的判定标准 |
| 1956 | 达特茅斯会议 | AI 作为学科正式诞生 |
| 1997 | 深蓝战胜卡斯帕罗夫 | 标志性的里程碑事件 |
| 2012 | AlexNet 夺冠 | 深度学习时代开启 |
| 2022 | ChatGPT 发布 | 大模型时代到来 |

[SVG:timeline-milestones]

## 4. 历史启示与思考

### 4.1 技术发展的规律

1. **螺旋上升**：技术发展不是线性的，而是在起伏中前进
2. **多因素驱动**：理论、算力、数据三者缺一不可
3. **期望周期**：技术成熟度曲线（Gartner Hype Cycle）

### 4.2 对当前的借鉴意义

- 保持理性，避免过度 hype
- 重视基础研究，不盲目跟风
- 关注交叉学科的融合创新

## 5. 延伸学习

- 推荐阅读：《人工智能：一种现代方法》第1章
- 纪录片：《The Age of AI》
- 经典论文：McCulloch & Pitts (1943), Rumelhart et al. (1986)
- 配合动画：时间轴演进 + 里程碑卡片

---

*本文档由解构者梳理历史脉络，编织者撰写详细内容，视觉师配套时间轴动画。*
`,pn=e=>`# ${e.title}

> 学习时长约 ${e.estimatedMinutes} 分钟 · 难度 ${"★".repeat(e.difficulty)}${"☆".repeat(5-e.difficulty)}
> 📖 概念类知识点 · 建议先建立直觉，再深入形式化

## 1. 概念引入与直觉

${e.summary}

### 1.1 为什么需要这个概念？

在深入形式化定义之前，先思考一个问题：

> 🤔 **如果没有这个概念，我们会遇到什么困难？**

答案是：我们将无法准确描述和讨论相关问题，也无法建立统一的认知基础。概念是学科的基石。

### 1.2 日常生活中的类比

为了建立直觉，我们可以用生活中的例子类比：

| 生活概念 | AI 对应概念 | 相似性 |
|----------|------------|--------|
| 工具 | 算法 | 都是解决问题的手段 |
| 经验 | 数据 | 都是知识的来源 |
| 判断 | 分类 | 都是决策的过程 |

[SVG:concept-analogy]

## 2. 形式化定义

### 2.1 核心定义

**${e.title}** 可以从多个角度来定义：

**定义1（描述性）**：${e.summary.replace(/。$/,"")}。

**定义2（数学化）**：从数学角度，可以形式化为：

$$
\\mathcal{C} = \\{ x \\mid P(x) \\}
$$

其中 $P(x)$ 是判定 $x$ 是否属于该概念的谓词。

**定义3（操作性）**：通过一组操作来定义概念的内涵与外延。

### 2.2 关键维度

每个概念都可以从多个维度来理解：

| 维度 | 说明 | 重要性 |
|------|------|--------|
| **内涵** | 概念的本质属性 | ⭐⭐⭐⭐⭐ |
| **外延** | 概念涵盖的实例范围 | ⭐⭐⭐⭐ |
| **边界** | 与其他概念的区分 | ⭐⭐⭐⭐ |
| **层次** | 在概念体系中的位置 | ⭐⭐⭐ |

[SVG:concept-dimensions]

## 3. 相关概念辨析

### 3.1 相似概念对比

学习概念时最容易混淆的是相似概念。下表列出了几组常见的对比：

| 概念 A | 概念 B | 核心区别 |
|--------|--------|----------|
| 强 AI | 弱 AI | 通用能力 vs 特定任务 |
| 监督学习 | 无监督学习 | 是否有标签 |
| 过拟合 | 欠拟合 | 模型复杂度 vs 数据量 |

### 3.2 概念关系图

概念之间不是孤立的，它们形成一个网络：

$$
\\mathcal{G} = (\\mathcal{V}, \\mathcal{E})
$$

其中 $\\mathcal{V}$ 是概念集合，$\\mathcal{E}$ 是概念间的关系边（包含、并列、对立等）。

[SVG:concept-relations]

## 4. 分类与层次

### 4.1 分类体系

根据不同的分类标准，${e.title}可以分为不同的类型：

1. **按应用领域分**
   - 类型A：应用于场景X
   - 类型B：应用于场景Y
   - 类型C：应用于场景Z

2. **按实现方式分**
   - 基于规则的方法
   - 基于统计的方法
   - 基于深度学习的方法

### 4.2 层次结构

概念体系呈现树状结构：

\`\`\`text
Root
  +-- Subclass A
  |    +-- Subclass A1
  |    +-- Subclass A2
  +-- Subclass B
  |    +-- Subclass B1
  +-- Subclass C
\`\`\`

## 5. 应用场景

### 5.1 典型应用领域

| 领域 | 应用方式 | 代表性工作 |
|------|----------|-----------|
| 自然语言处理 | 文本理解与生成 | BERT, GPT |
| 计算机视觉 | 图像识别与分割 | ResNet, ViT |
| 推荐系统 | 个性化推荐 | 协同过滤 |
| 自动驾驶 | 感知与决策 | Tesla FSD |

### 5.2 实际案例分析

> 📝 **案例研究**：某公司如何应用该概念解决实际问题
>
> **问题**：数据量庞大，人工处理效率低下
> **方案**：引入 ${e.title} 相关技术
> **效果**：效率提升 300%，成本降低 60%

[SVG:application-cases]

## 6. 常见误区与注意事项

### 6.1 典型误区

1. **误区一**：将相关性等同于因果性
   - 错误：因为 A 和 B 同时出现，所以 A 导致 B
   - 正确：需要通过控制变量实验验证因果关系

2. **误区二**：过度泛化
   - 错误：在有限数据上得出普适结论
   - 正确：明确适用范围和边界条件

3. **误区三**：非黑即白思维
   - 错误：认为一个概念要么正确要么错误
   - 正确：理解概念的发展演化和适用条件

### 6.2 学习建议

- ✅ 先建立直觉，再追求精确
- ✅ 对比相似概念，加深理解
- ✅ 在应用中巩固概念
- ❌ 不要死记硬背定义
- ❌ 不要忽略反例和边界情况

## 7. 小结

通过本章学习，你应该掌握：

1. ${e.title}的核心定义与本质
2. 关键维度与分类体系
3. 与相关概念的联系与区别
4. 典型应用场景
5. 常见误区与避坑指南

---

*本文档由解构者提炼核心概念，编织者撰写详细讲解，校验官补充常见误区。*
`,mn=e=>`# ${e.title} — 模型详解

> 学习时长约 ${e.estimatedMinutes} 分钟 · 难度 ${"★".repeat(e.difficulty)}${"☆".repeat(5-e.difficulty)}
> 🧠 模型类知识点 · 建议配合架构图动画学习

## 1. 模型概述

${e.summary}

### 1.1 模型设计思想

每一种模型都有其核心设计哲学。${e.title}的核心思想是：

> 💡 **核心洞察**：通过层次化的特征提取，逐步将原始数据转化为高级语义表示。

### 1.2 发展历史

| 时间 | 里程碑 | 意义 |
|------|--------|------|
| 1980s | 早期原型 | 概念验证 |
| 2010s | 深度学习时代 | 性能飞跃 |
| 2020s | 大模型时代 | 规模效应 |

[SVG:model-evolution]

## 2. 模型架构详解

### 2.1 整体架构图

${e.title}的整体架构如下：

$$
\\text{Model}(x) = f_L(f_{L-1}(\\dots f_1(x) \\dots))
$$

其中 $f_l$ 表示第 $l$ 层的变换函数，$L$ 为网络总层数。

### 2.2 各层详解

#### 输入层

- **作用**：接收原始数据
- **输入维度**：$d_{in}$
- **预处理**：归一化、标准化

$$
x_{norm} = \\frac{x - \\mu}{\\sigma}
$$

#### 隐藏层（核心）

[SVG:model-architecture]

隐藏层是模型的核心，包含以下关键组件：

| 组件 | 作用 | 数学表达 |
|------|------|----------|
| **线性变换** | 特征变换 | $z = Wx + b$ |
| **激活函数** | 引入非线性 | $a = \\sigma(z)$ |
| **归一化** | 稳定训练 | $\\hat{z} = \\frac{z - \\mu}{\\sqrt{\\sigma^2 + \\epsilon}}$ |
| **残差连接** | 缓解梯度消失 | $y = x + F(x)$ |

#### 输出层

- **作用**：产生最终预测
- 根据任务选择不同的激活函数：
  - 分类：Softmax
  - 回归：Linear
  - 二分类：Sigmoid

$$
\\text{Softmax}(z_i) = \\frac{e^{z_i}}{\\sum_{j=1}^K e^{z_j}}
$$

## 3. 关键机制详解

### 3.1 注意力机制（如适用）

如果模型包含注意力机制，其核心公式为：

$$
\\text{Attention}(Q, K, V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V
$$

其中：
- $Q$ 为查询矩阵
- $K$ 为键矩阵
- $V$ 为值矩阵
- $d_k$ 为键的维度，用于缩放

### 3.2 前馈网络

$$
\\text{FFN}(x) = \\max(0, xW_1 + b_1)W_2 + b_2
$$

两层线性变换，中间加 ReLU 激活。

### 3.3 层归一化

$$
\\text{LayerNorm}(x) = \\gamma \\odot \\frac{x - \\mu}{\\sqrt{\\sigma^2 + \\epsilon}} + \\beta
$$

其中 $\\gamma$ 和 $\\beta$ 是可学习的参数。

[SVG:key-mechanisms]

## 4. 训练流程

### 4.1 前向传播

数据从输入层流向输出层：

$$
\\begin{align*}
a^{(0)} &= x \\\\
z^{(l)} &= W^{(l)} a^{(l-1)} + b^{(l)} \\\\
a^{(l)} &= \\sigma(z^{(l)}) \\\\
\\hat{y} &= a^{(L)}
\\end{align*}
$$

### 4.2 损失函数

根据任务类型选择损失函数：

| 任务 | 损失函数 | 公式 |
|------|----------|------|
| 二分类 | 交叉熵 | $L = -[y\\log\\hat{y} + (1-y)\\log(1-\\hat{y})]$ |
| 多分类 | 交叉熵 | $L = -\\sum_{i=1}^K y_i\\log\\hat{y}_i$ |
| 回归 | MSE | $L = \\frac{1}{n}\\sum_{i=1}^n (y_i - \\hat{y}_i)^2$ |

### 4.3 反向传播

基于链式法则，从输出层向输入层逐层计算梯度：

$$
\\frac{\\partial L}{\\partial W^{(l)}} = \\frac{\\partial L}{\\partial z^{(l)}} \\cdot a^{(l-1)T}
$$

$$
\\frac{\\partial L}{\\partial b^{(l)}} = \\frac{\\partial L}{\\partial z^{(l)}}
$$

[SVG:training-flow]

### 4.4 参数更新

使用梯度下降算法更新参数：

$$
W^{(l)} \\leftarrow W^{(l)} - \\eta \\cdot \\frac{\\partial L}{\\partial W^{(l)}}
$$

$$
b^{(l)} \\leftarrow b^{(l)} - \\eta \\cdot \\frac{\\partial L}{\\partial b^{(l)}}
$$

其中 $\\eta$ 为学习率。

## 5. 模型变体与演进

### 5.1 主要变体

| 变体名称 | 改进点 | 适用场景 |
|----------|--------|----------|
| 基础版 | 标准结构 | 通用场景 |
| 轻量版 | 减少参数，加速推理 | 移动端、边缘设备 |
| 加强版 | 增加深度和宽度 | 追求高精度 |
| 改进版 | 引入新机制（注意力等） | 复杂任务 |

### 5.2 性能对比

[SVG:model-comparison]

## 6. 实现要点与调参技巧

### 6.1 常见超参数

| 超参数 | 作用 | 典型范围 | 调参建议 |
|--------|------|----------|----------|
| 学习率 | 控制更新步长 | 1e-5 ~ 1e-2 | 从大到小尝试 |
| 批次大小 | 并行样本数 | 8 ~ 512 | 显存允许范围内选大 |
| 层数 | 网络深度 | 3 ~ 100+ | 越深越难训练 |
| 隐藏维度 | 特征维度 | 64 ~ 1024 | 大模型选大值 |
| Dropout | 防止过拟合 | 0.1 ~ 0.5 | 数据少则调大 |

### 6.2 训练技巧

1. **学习率调度**：Warmup + 余弦退火
2. **权重衰减**：L2 正则化
3. **梯度裁剪**：防止梯度爆炸
4. **早停**：防止过拟合

## 7. 典型应用

- 图像分类：ImageNet 准确率 90%+
- 目标检测：COCO mAP 50+
- 语义分割：Cityscapes mIoU 80%+
- 自然语言处理：GLUE 基准刷新

---

*本文档由解构者拆解模型架构，视觉师设计架构图动画，实操匠配套代码实现。*
`,un=e=>`# ${e.title} — 算法详解

> 学习时长约 ${e.estimatedMinutes} 分钟 · 难度 ${"★".repeat(e.difficulty)}${"☆".repeat(5-e.difficulty)}
> ⚙️ 算法类知识点 · 建议配合流程图与代码实操学习

## 1. 问题定义

### 1.1 问题描述

${e.summary}

### 1.2 形式化定义

我们可以将问题形式化如下：

**输入**：

$$
\\mathcal{I} = \\{ \\text{状态空间 } S, \\text{动作空间 } A, \\text{初始状态 } s_0, \\text{目标状态 } G \\}
$$

**输出**：

$$
\\mathcal{O} = \\{ \\text{动作序列 } a_1, a_2, \\dots, a_n \\mid \\delta(s_0, a_1a_2\\dots a_n) \\in G \\}
$$

**优化目标**：

$$
\\min_{\\pi \\in \\Pi} \\quad C(\\pi)
$$

其中 $C(\\pi)$ 表示策略 $\\pi$ 的代价。

[SVG:problem-definition]

## 2. 算法原理

### 2.1 核心思想

${e.title}的核心思想是：

> 💡 **直觉理解**：在解空间中，按照特定策略系统地探索，逐步逼近最优解。

### 2.2 算法流程

算法的整体流程可以概括为以下步骤：

1. **初始化**：设置初始状态、数据结构、参数
2. **迭代搜索**：循环执行以下操作直到满足终止条件
   - 选择节点/状态
   - 扩展后继
   - 评估质量
   - 更新数据结构
3. **返回结果**：找到解或报告无解

[SVG:algorithm-flowchart]

### 2.3 伪代码

\`\`\`python
def algorithm(input_state):
    # 初始化
    frontier = initialize(input_state)
    explored = set()
    
    while frontier:
        # 选择节点
        node = select_node(frontier)
        
        # 目标检测
        if is_goal(node.state):
            return build_solution(node)
        
        # 标记已探索
        explored.add(node.state)
        
        # 扩展后继
        for action in get_actions(node.state):
            child = expand(node, action)
            if child.state not in explored:
                add_to_frontier(frontier, child)
    
    return None  # 无解
\`\`\`

## 3. 复杂度分析

### 3.1 时间复杂度

$$
T(n) = O(b^d)
$$

其中：
- $b$ 为分支因子（每个节点的平均后继数）
- $d$ 为解的深度
- $n$ 为问题规模

### 3.2 空间复杂度

$$
S(n) = O(b^d)
$$

空间复杂度通常与时间复杂度同阶，但某些算法（如迭代加深）可以显著降低空间需求。

### 3.3 对比分析

| 算法 | 时间 | 空间 | 完备性 | 最优性 |
|------|------|------|--------|--------|
| BFS | $O(b^d)$ | $O(b^d)$ | ✅ | ✅ |
| DFS | $O(b^m)$ | $O(bm)$ | ❌ | ❌ |
| UCS | $O(b^{1+\\lfloor C^*/\\epsilon \\rfloor})$ | $O(b^{1+\\lfloor C^*/\\epsilon \\rfloor})$ | ✅ | ✅ |
| A* | $O(b^d)$ | $O(b^d)$ | ✅ | ✅ |

[SVG:complexity-comparison]

## 4. 数学推导

### 4.1 关键公式推导

**定理**：如果启发函数 $h(n)$ 满足可采纳性，那么 A* 算法是最优的。

**证明**：

假设存在一个目标节点 $G_2$ 被先从 frontier 中取出，但存在另一个更优的目标节点 $G_1$（$f(G_1) < f(G_2)$）。

由于 $G_1$ 在最优路径上，设 $n$ 为最优路径上 frontier 中的某个节点，则：

$$
f(n) = g(n) + h(n) \\leq g(G_1) = f(G_1) < f(G_2)
$$

因此 $n$ 应该比 $G_2$ 先被取出，与假设矛盾。

$\\blacksquare$

### 4.2 可采纳性条件

$$
h(n) \\leq h^*(n), \\quad \\forall n
$$

其中 $h^*(n)$ 是从 $n$ 到目标的真实最小代价。

### 4.3 一致性条件

$$
h(n) \\leq c(n, a, n') + h(n')
$$

其中 $c(n, a, n')$ 是从 $n$ 通过动作 $a$ 到 $n'$ 的代价。

[SVG:admissible-heuristic]

## 5. 优化与变体

### 5.1 经典优化技术

1. **双向搜索**：从起点和终点同时搜索，相遇即停止
   - 时间复杂度：$O(b^{d/2})$（大幅降低）

2. **迭代加深**：结合 DFS 的空间效率和 BFS 的完备性
   - 空间复杂度：$O(bd)$

3. **剪枝策略**：Alpha-Beta 剪枝等，减少搜索空间

### 5.2 现代变体

- **元启发式**：遗传算法、模拟退火、粒子群优化
- **机器学习结合**：用学习到的策略指导搜索
- **并行化**：多节点并行探索

## 6. 应用场景

### 6.1 经典问题

| 问题 | 应用算法 | 复杂度 |
|------|----------|--------|
| 八数码 | A* | NP-Hard |
| 路径规划 | Dijkstra / A* | O((V+E)log V) |
| 博弈对抗 | Minimax + Alpha-Beta | O(b^{m/2}) |
| 调度问题 | 启发式搜索 | NP-Hard |

### 6.2 实际应用

- **机器人路径规划**：在地图中找到最优路径
- **游戏 AI**：状态空间搜索，决策树
- **物流调度**：车辆路径问题（VRP）
- **自然语言处理**：句法分析、机器翻译

[SVG:application-scenarios]

## 7. 常见误区

### 7.1 易错点

1. **忽略边界条件**：空输入、无解情况等
2. **启发函数不可采纳**：导致丢失最优解
3. **状态表示不当**：状态爆炸或丢失信息
4. **剪枝错误**：剪掉了正确的解

### 7.2 Debug 技巧

- 从小规模问题入手验证
- 打印中间状态检查逻辑
- 对比已知最优解
- 使用可视化工具追踪搜索过程

## 8. 学习建议

1. **先理解直觉**：不要一上来就啃公式
2. **动手实现**：写代码是理解算法的最好方式
3. **画流程图**：可视化有助于理解
4. **做练习题**：通过做题巩固理解
5. **对比学习**：将不同算法放在一起对比

---

*本文档由解构者分析算法原理，校验官补充复杂度证明，实操匠配套代码实现。*
`,fn=e=>{switch(e.category||Ct(e.title)){case"history":return dn(e);case"concept":return pn(e);case"model":return mn(e);case"algorithm":default:return un(e)}},xn=e=>`# ${e.title} · 思维导图

> 编织者设计 · 径向放射布局 · ${e.prerequisites.length+5} 主分支 · 交互式可视化（悬停高亮路径 / 点击展开 / 节点浮现动画）

## 交互说明

资源详情中渲染为完整 SVG 思维导图，支持：
- **悬停高亮**：鼠标移到任一节点，自动高亮从根节点到该节点的完整路径
- **节点详情**：悬停显示该节点的详细说明（tooltip）
- **主题配色**：根据知识点所属章节自动匹配主题色（朱砂/青金/翡翠/紫宸）
- **逐层浮现**：节点按层级延迟浮现，连线带绘制动画

## 知识结构

\`\`\`mermaid
mindmap
  root((${e.title}))
    核心概念
      形式化定义
      范畴与边界
      关键术语
    关键性质
      完备性
      最优性
      复杂度
      收敛性
    典型算法
      朴素实现
      工程优化
      现代变体
      对比选型
    应用场景
      学术研究
      工程实践
      前沿探索
      跨学科融合
    易错点
      概念混淆
      边界条件
      复杂度误判
      实现陷阱
\`\`\`

**节点统计**：5 主分支 · ${15+e.prerequisites.length} 子节点 · 关联知识点 ${e.prerequisites.length} 个
`,St=e=>{const t={ch1:"aurum",ch2:"azure",ch3:"amethyst",ch4:"azure",ch5:"jade",ch6:"aurum"}[e.id]||"azure",r={id:e.id,label:e.title,detail:e.summary,weight:"key",children:[{id:`${e.id}-c1`,label:"核心概念",detail:`${e.title} 的形式化定义、研究范畴与关键术语`,weight:"important",children:[{id:`${e.id}-c1-1`,label:"形式化定义",detail:"数学语言精确描述问题与解空间"},{id:`${e.id}-c1-2`,label:"范畴与边界",detail:"明确方法的适用条件与局限"},{id:`${e.id}-c1-3`,label:"关键术语",detail:"掌握领域核心词汇，避免理解偏差"}]},{id:`${e.id}-c2`,label:"关键性质",detail:"评价方法优劣的四大维度",weight:"important",children:[{id:`${e.id}-c2-1`,label:"完备性",detail:"保证找到解（若解存在）",weight:"key"},{id:`${e.id}-c2-2`,label:"最优性",detail:"解的质量保证，是否全局最优"},{id:`${e.id}-c2-3`,label:"复杂度",detail:"时间与空间成本，决定可扩展性"},{id:`${e.id}-c2-4`,label:"收敛性",detail:"迭代方法是否收敛及收敛速度"}]},{id:`${e.id}-c3`,label:"典型算法",detail:"从朴素到现代的算法谱系",weight:"important",children:[{id:`${e.id}-c3-1`,label:"朴素实现",detail:"最直观的基线方法，便于理解原理"},{id:`${e.id}-c3-2`,label:"工程优化",detail:"通过数据结构/并行化提升性能"},{id:`${e.id}-c3-3`,label:"现代变体",detail:"结合深度学习等新范式的扩展"},{id:`${e.id}-c3-4`,label:"对比选型",detail:"不同场景下的算法选择策略"}]},{id:`${e.id}-c4`,label:"应用场景",detail:`${e.title} 的真实落地领域`,children:[{id:`${e.id}-c4-1`,label:"学术研究",detail:"前沿论文中的理论创新与应用"},{id:`${e.id}-c4-2`,label:"工程实践",detail:"工业界的真实落地案例与经验"},{id:`${e.id}-c4-3`,label:"前沿探索",detail:"新兴方向的早期尝试与开放问题"},{id:`${e.id}-c4-4`,label:"跨学科融合",detail:"与其他领域结合产生的新方向"}]},{id:`${e.id}-c5`,label:"易错点",detail:"学习者常见误区与陷阱",weight:"important",children:[{id:`${e.id}-c5-1`,label:"概念混淆",detail:"相似概念之间的辨析与区分"},{id:`${e.id}-c5-2`,label:"边界条件",detail:"特殊输入与退化情况的处理"},{id:`${e.id}-c5-3`,label:"复杂度误判",detail:"常见的时间复杂度分析错误"},{id:`${e.id}-c5-4`,label:"实现陷阱",detail:"工程实现中的隐蔽 bug 来源"}]}]};return e.prerequisites.length>0&&r.children.push({id:`${e.id}-c6`,label:"前置知识",detail:"学习本节前应掌握的基础知识",children:e.prerequisites.map((n,i)=>({id:`${e.id}-c6-${i}`,label:n,detail:`前置知识点：${n}`}))}),{root:r,layout:"radial",theme:t}},hn=e=>`# ${e.title} · 题库

> 共 5 题 · 难度梯度 ★ ~ ★★★★★ · 出题官依据画像易错点靶向生成

## 一、单选题（★ ~ ★★）

**1.** 下列关于 ${e.title} 的描述，最准确的是？
- A. 仅适用于离散状态空间
- B. 是${e.summary.slice(0,8)}…的唯一方法
- C. 是一种${e.summary.slice(0,6)}的范式与方法体系 ✓
- D. 与机器学习完全无关

**答案**：C
**解析**：${e.title} 的范畴远超单一算法，它是一整套方法体系。

## 二、多选题（★★★）

**2.** 关于 ${e.title} 的关键性质，下列说法正确的有？
- A. 完备性指保证找到解（若存在） ✓
- B. 最优性指解一定全局最优
- C. 时间复杂度与问题规模无关
- D. 不同算法在三项性质上存在权衡 ✓

**答案**：A、D

## 三、判断题（★★）

**3.** ${e.title} 的复杂度只取决于输入规模，与启发函数设计无关。（ ）

**答案**：✗
**解析**：启发函数质量直接影响搜索效率，从而影响实际复杂度。

## 四、简答题（★★★★）

**4.** 请简述 ${e.title} 在${e.summary.split("，")[0]}场景中的适用边界。

## 五、综合题（★★★★★）

**5.** 给定一个具体问题实例，请设计完整的求解流程，并分析其完备性与最优性。
`,yn=e=>`# ${e.title} · 拓展阅读

> 编织者汇编 · 校验官补全引用 · 共 4 篇

## 1. 经典教材章节

**Russell & Norvig, AIMV 4th ed., Ch. 相关章节**
- 推荐阅读：第 ${e.chapter+2} 章关于 ${e.title} 的完整论述
- 阅读重点：形式化定义与完备性证明

## 2. 综述论文

**A Survey on ${e.title} (ACM Computing Surveys, 2023)**
- 引用量 1.2k+
- 覆盖：方法分类、性能对比、开放问题

## 3. 工程博客

**Anthropic / OpenAI 技术博客系列**
- 实践视角的 ${e.title} 落地经验
- 包含可复现的实验配置

## 4. 视频资源

**Stanford CS221 / CS224N 对应讲座**
- 时长 50-80 分钟
- 含课后习题与讨论区

---

**引用规范**：所有引用已由校验官交叉核对，缺失部分标注"待补充"。
`,gn=e=>`# ${e.title} · 教学动画

> 视觉师设计 · 7 分镜 · 总时长约 150 秒 · 矢量动画播放器（SVG + CSS 时序驱动）
>
> 本动画由多智能体协作生成：解构者输出知识骨架 → 编织者产出算法流程图 → 实操匠提供目标代码 → 视觉师设计分镜与 SVG → 校验官核对内容真实性。
> 播放器支持播放/暂停/进度拖拽/分镜跳转/字幕语音播报，矢量渲染保证任意分辨率清晰。
> 代码分镜基于主题代码库匹配真实实现，并推荐外部视频资源供深入学习。

## 播放说明

资源详情中点击「播放动画」即可观看。每分镜含：
- **画面**：SVG 矢量图，元素带时序动画（粒子汇聚 / 概念定义 / 流程图 / 代码逐行高亮 / 运行演示 / 对比卡片 / 视频推荐）
- **字幕**：同步解说文本，支持语音播报（TTS）
- **时长**：精准时间轴，支持 seek

## 分镜脚本

### 分镜 1（0-15s）— 问题导入 · 粒子汇聚

**画面**：墨色背景中浮现抽象问题图标，粒子从四周向中心汇聚成核心节点。
**字幕**："当我们面对${e.summary.split("，")[0]}的问题时，第一步是建立直觉。粒子从四周汇聚成核心节点，象征问题的聚焦。"

### 分镜 2（15-35s）— 概念定义 · 形式化

**画面**：标题与公式展示区浮现，Goal = argmax U(a, s)，下方三个关键术语卡片（输入空间/核心映射/输出结果）。
**字幕**："${e.title} 的形式化定义：在动作集合 A 中，给定状态 s，寻找使效用函数 U 最大的解。"

### 分镜 3（35-60s）— 算法流程图 · 多节点执行

**画面**：完整算法流程图，含输入/预处理/核心计算/判断分支/输出 5 个节点，连线带流动虚线，节点依次点亮，判断节点带循环箭头。
**字幕**："${e.title} 的算法流程：输入 → 预处理 → 核心计算 → 判断收敛 → 输出，含循环反馈。核心计算节点是整个流程的关键。"

### 分镜 4（60-95s）— 核心代码 · 逐行执行

**画面**：模拟代码编辑器，基于主题代码库匹配的真实 Python 实现，逐行高亮（keyword/comment/string 不同色），右侧显示变量状态与执行结果。
**字幕**："对应真实代码实现，右侧实时显示运行时状态变量变化，逐行高亮展示执行流程。"

### 分镜 5（95-115s）— 运行演示 · 变量状态

**画面**：左侧展示执行步骤列表（带编号），右侧显示输出结果面板，逐步点亮执行步骤。
**字幕**："代码逐步执行，最终收敛并输出结果，每一步的变量状态实时更新。"

### 分镜 6（115-135s）— 关键性质 · 三栏对比

**画面**：三列对比卡片自下而上浮现，分别标注完备性 / 最优性 / 复杂度，含中英文标注与影响说明。
**字幕**："评价${e.title}的三个维度：完备性决定可行性，最优性决定质量，复杂度决定可扩展性。三者需权衡取舍。"

### 分镜 7（135-150s）— 应用拓展 · 视频推荐

**画面**：三个应用场景（工业应用/学术研究/工程实践）缩略图，底部浮现外部视频推荐区域，提示查看 B站/YouTube/Coursera 等平台资源。
**字幕**："${e.title}已应用于工业界与学术界。查看下方外部视频推荐，深入理解主题。"

---

## 技术实现

- **渲染**：SVG 矢量 + CSS keyframes 时序动画
- **播放器**：自研轻量组件（play/pause/seek/进度条/分镜跳转/TTS 字幕播报）
- **流程图**：5 节点带分支判断与循环反馈，连线虚线流动 + 节点依次点亮
- **代码展示**：模拟编辑器界面，基于主题代码库匹配真实实现，关键字 / 注释 / 字符串差异化配色，逐行高亮执行
- **TTS 播报**：基于 Web Speech API 的 speechSynthesis，支持中文字幕语音朗读
- **外部视频**：根据主题推荐 B站/YouTube/Coursera/MIT OCW/Stanford/arXiv 等平台资源
- **扩展性**：已预留 SeeDance / 讯飞星火多模态生成大模型 Provider 接口，可扩展为真实视频流
- **防幻觉**：所有字幕与画面元素经校验官四重校验，命中知识点白名单
`,xe=(e,o)=>`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-intro">
  <defs>
    <radialGradient id="core1" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#22D3EE" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#1B9AAA" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <circle cx="240" cy="110" r="60" fill="url(#core1)" data-anim="core-pulse"/>
  <g data-anim="particles">
    <circle cx="60" cy="60" r="3" fill="#F4A261" data-anim="p1"/>
    <circle cx="420" cy="60" r="3" fill="#1B9AAA" data-anim="p2"/>
    <circle cx="60" cy="180" r="3" fill="#9D4EDD" data-anim="p3"/>
    <circle cx="420" cy="180" r="3" fill="#F4A261" data-anim="p4"/>
    <circle cx="100" cy="110" r="2" fill="#22D3EE" data-anim="p5"/>
    <circle cx="380" cy="110" r="2" fill="#22D3EE" data-anim="p6"/>
  </g>
  <circle cx="240" cy="110" r="22" fill="none" stroke="#22D3EE" stroke-width="2" data-anim="ring-expand"/>
  <text x="240" y="200" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${e}</text>
  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="11" font-family="serif">${o}</text>
</svg>`,he=e=>`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-outro">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="28" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${e} · 应用与拓展</text>

  <g data-anim="scene-1">
    <rect x="30" y="50" width="130" height="100" rx="8" fill="#22D3EE15" stroke="#22D3EE" stroke-width="1.5"/>
    <circle cx="95" cy="90" r="14" fill="#22D3EE" opacity="0.6"/>
    <text x="95" y="135" text-anchor="middle" fill="#22D3EE" font-size="11" font-family="serif">工业应用</text>
    <text x="95" y="150" text-anchor="middle" fill="#8B94A8" font-size="8">真实落地</text>
  </g>
  <g data-anim="scene-2" opacity="0.4">
    <rect x="175" y="50" width="130" height="100" rx="8" fill="#F4A26115" stroke="#F4A261" stroke-width="1.5"/>
    <rect x="215" y="78" width="50" height="24" rx="3" fill="#F4A261" opacity="0.6"/>
    <text x="240" y="135" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif">学术研究</text>
    <text x="240" y="150" text-anchor="middle" fill="#8B94A8" font-size="8">前沿论文</text>
  </g>
  <g data-anim="scene-3" opacity="0.4">
    <rect x="320" y="50" width="130" height="100" rx="8" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1.5"/>
    <path d="M360 100 L385 80 L385 120 Z" fill="#9D4EDD" opacity="0.6"/>
    <text x="385" y="135" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif">工程实践</text>
    <text x="385" y="150" text-anchor="middle" fill="#8B94A8" font-size="8">代码实战</text>
  </g>

  <g data-anim="video-recommend" opacity="0">
    <rect x="30" y="165" width="420" height="55" rx="8" fill="#1a223580" stroke="#F4A261" stroke-width="1" stroke-dasharray="4 4"/>
    <text x="240" y="185" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">📺 外部视频推荐</text>
    <text x="240" y="205" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">B站 · YouTube · Coursera · MIT OCW · Stanford · arXiv</text>
  </g>
</svg>`,ye=(e,o)=>{const t={cyan:"#22D3EE",orange:"#F4A261",purple:"#9D4EDD",teal:"#1B9AAA",green:"#10B981"};return`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-compare">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="30" text-anchor="middle" fill="#22D3EE" font-size="13" font-family="serif" font-weight="bold">${e}</text>
  ${o.map((r,n)=>{const i=30+n*145,a=t[r.color]||t.cyan;return`<g data-anim="card-${n+1}" opacity="${n===0?1:0}">
    <rect x="${i}" y="55" width="130" height="140" rx="8" fill="${a}15" stroke="${a}" stroke-width="1.5"/>
    <text x="${i+65}" y="90" text-anchor="middle" fill="${a}" font-size="14" font-family="serif" font-weight="bold">${r.label}</text>
    <text x="${i+65}" y="115" text-anchor="middle" fill="#8B94A8" font-size="10">${r.sub1}</text>
    <text x="${i+65}" y="135" text-anchor="middle" fill="#8B94A8" font-size="10">${r.sub2}</text>
    <text x="${i+65}" y="165" text-anchor="middle" fill="${a}" font-size="9">→ ${r.impact}</text>
    <text x="${i+65}" y="185" text-anchor="middle" fill="#4a5670" font-size="8">${r.en}</text>
  </g>`}).join("")}
  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">多维度全面理解</text>
</svg>`},An=e=>{const o=e.title,t=o.slice(0,4),r=e.summary.split("，")[0],n=fe(o),i=xe("问题导入",`问题：${r}`),a=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-concept">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="32" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold" data-anim="concept-title">${o} · 形式化定义</text>

  <g data-anim="formula-block" opacity="0">
    <rect x="60" y="55" width="360" height="80" rx="8" fill="#1a223580" stroke="#22D3EE" stroke-width="1" stroke-dasharray="4 4"/>
    <text x="240" y="90" text-anchor="middle" fill="#F4A261" font-size="16" font-family="serif" font-style="italic">${n.formula}</text>
    <text x="240" y="115" text-anchor="middle" fill="#8B94A8" font-size="11" font-family="serif">${n.formulaDesc}</text>
  </g>

  <g data-anim="terms" opacity="0">
    <rect x="40" y="150" width="130" height="60" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1"/>
    <text x="105" y="172" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">输入空间</text>
    <text x="105" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">数据 / 状态</text>

    <rect x="180" y="150" width="130" height="60" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="1"/>
    <text x="245" y="172" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">核心映射</text>
    <text x="245" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">函数 / 模型</text>

    <rect x="320" y="150" width="130" height="60" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1"/>
    <text x="385" y="172" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">输出结果</text>
    <text x="385" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">决策 / 预测</text>
  </g>
</svg>`,c=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-flowchart">
  <defs>
    <linearGradient id="fc-g" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#F4A261"/>
      <stop offset="100%" stop-color="#9D4EDD"/>
    </linearGradient>
    <marker id="arrow-fc" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
      <path d="M0 0 L8 4 L0 8 Z" fill="#22D3EE"/>
    </marker>
  </defs>
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="24" text-anchor="middle" fill="#8B94A8" font-size="11" font-family="serif">${o} · 算法流程图</text>

  <path d="M80 50 L80 80" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="fc-dash-1" marker-end="url(#arrow-fc)"/>
  <path d="M80 110 L120 140" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="fc-dash-2" marker-end="url(#arrow-fc)"/>
  <path d="M280 155 L340 155" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="fc-dash-3" marker-end="url(#arrow-fc)"/>
  <path d="M400 118 L400 60" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="fc-dash-4" marker-end="url(#arrow-fc)"/>
  <text x="410" y="90" fill="#10B981" font-size="8" font-family="serif">收敛</text>

  <path d="M360 172 L360 192 L220 192 L200 172" stroke="#F4A261" stroke-width="1.5" stroke-dasharray="3 3" fill="none" data-anim="fc-loop" marker-end="url(#arrow-fc)" opacity="0"/>
  <text x="290" y="204" fill="#F4A261" font-size="8" font-family="serif" data-anim="fc-loop-label" opacity="0">未收敛 · 循环迭代</text>

  <g data-anim="fc-node-1" opacity="0.3">
    <rect x="40" y="35" width="80" height="28" rx="14" fill="#0A0E1A" stroke="#F4A261" stroke-width="2"/>
    <text x="80" y="53" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif">输入</text>
  </g>
  <g data-anim="fc-node-2" opacity="0.3">
    <rect x="40" y="95" width="80" height="28" rx="4" fill="#0A0E1A" stroke="#1B9AAA" stroke-width="2"/>
    <text x="80" y="113" text-anchor="middle" fill="#1B9AAA" font-size="10" font-family="serif">预处理</text>
  </g>
  <g data-anim="fc-node-3" opacity="0.3">
    <rect x="200" y="140" width="80" height="30" rx="4" fill="#0A0E1A" stroke="#22D3EE" stroke-width="2.5"/>
    <circle cx="240" cy="155" r="36" fill="none" stroke="#22D3EE" stroke-width="1" opacity="0.4" data-anim="core-ring"/>
    <text x="240" y="159" text-anchor="middle" fill="#22D3EE" font-size="12" font-family="serif" font-weight="bold">${t}</text>
  </g>
  <g data-anim="fc-node-4" opacity="0.3">
    <path d="M340 155 L390 125 L440 155 L390 185 Z" fill="#0A0E1A" stroke="#9D4EDD" stroke-width="2"/>
    <text x="390" y="159" text-anchor="middle" fill="#9D4EDD" font-size="10" font-family="serif">收敛?</text>
  </g>
  <g data-anim="fc-node-5" opacity="0.3">
    <rect x="360" y="35" width="80" height="28" rx="14" fill="#0A0E1A" stroke="#10B981" stroke-width="2"/>
    <text x="400" y="53" text-anchor="middle" fill="#10B981" font-size="11" font-family="serif">输出</text>
  </g>

  <g font-family="monospace" font-size="8" fill="#4a5670">
    <text x="42" y="38">01</text>
    <text x="42" y="98">02</text>
    <text x="202" y="143">03</text>
    <text x="346" y="130">04</text>
    <text x="362" y="38">05</text>
  </g>
</svg>`,l={keyword:"#9D4EDD",func:"#1B9AAA",string:"#F4A261",comment:"#4a5670",number:"#10B981",plain:"#8B94A8"},p=n.displayLines.slice(0,12),u=11,m=42,w=p.map((d,B)=>{const C=m+B*u,q=l[d.type]||l.plain,g=d.text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");return`${`<rect x="30" y="${C-9}" width="250" height="11" fill="#22D3EE20" data-anim="code-hl-${B+1}" opacity="0"/>`}<text x="34" y="${C}" fill="${q}" font-family="monospace" font-size="9">${g}</text>`}).join(""),A=n.vars,f=[A.init,...A.steps].slice(0,6).map((d,B)=>`<text x="300" y="${55+B*18}" fill="#8B94A8" font-family="monospace" font-size="8">${d}</text>`).join(""),D=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-code">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <rect x="0" y="0" width="480" height="22" fill="#141B2E"/>
  <circle cx="14" cy="11" r="3" fill="#F4A261"/>
  <circle cx="26" cy="11" r="3" fill="#22D3EE"/>
  <circle cx="38" cy="11" r="3" fill="#10B981"/>
  <text x="240" y="15" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="monospace">${n.id}.py · ${n.title}</text>

  <g font-family="monospace" font-size="9">
    <g fill="#4a5670" data-anim="code-gutter">
      ${p.map((d,B)=>`<text x="14" y="${m+B*u}">${B+1}</text>`).join("")}
    </g>
    <g data-anim="code-content">
      ${w}
    </g>
  </g>

  <line x1="290" y1="22" x2="290" y2="240" stroke="#1a2235" stroke-width="1"/>
  <text x="385" y="36" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">运行时状态 · ${A.name}</text>

  <g font-family="monospace" font-size="8" data-anim="code-state">
    ${f}
  </g>

  <text x="300" y="180" fill="#8B94A8" font-size="8" font-family="serif">执行进度</text>
  <rect x="300" y="186" width="165" height="4" rx="2" fill="#1a2235"/>
  <rect x="300" y="186" width="0" height="4" rx="2" fill="#22D3EE" data-anim="conv-bar"/>
  <text x="465" y="200" text-anchor="end" fill="#22D3EE" font-size="8" font-family="monospace" data-anim="conv-pct">0%</text>

  <text x="240" y="225" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">真实代码 · ${n.title}</text>
</svg>`,b=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-runtime">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="30" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">运行演示 · ${n.title}</text>

  <g data-anim="runtime-steps">
    <text x="30" y="60" fill="#8B94A8" font-size="10" font-family="serif">执行步骤：</text>
    ${A.steps.map((d,B)=>{const C=80+B*22;return`<g data-anim="step-${B+1}" opacity="0.4">
      <circle cx="40" cy="${C-3}" r="8" fill="#1a2235" stroke="#22D3EE" stroke-width="1"/>
      <text x="40" y="${C}" text-anchor="middle" fill="#22D3EE" font-size="9" font-family="monospace">${B+1}</text>
      <text x="58" y="${C}" fill="#8B94A8" font-size="9" font-family="monospace">${d}</text>
    </g>`}).join("")}
  </g>

  <g data-anim="output-panel" opacity="0">
    <rect x="300" y="55" width="160" height="140" rx="8" fill="#1a223580" stroke="#10B981" stroke-width="1"/>
    <text x="380" y="80" text-anchor="middle" fill="#10B981" font-size="11" font-family="serif" font-weight="bold">✓ 执行完成</text>
    <text x="380" y="110" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="monospace">初始: ${A.init}</text>
    <text x="380" y="140" text-anchor="middle" fill="#22D3EE" font-size="10" font-family="monospace">→ 收敛</text>
    <text x="380" y="170" text-anchor="middle" fill="#F4A261" font-size="10" font-family="serif">结果已输出</text>
  </g>
</svg>`,v=ye(`${o} · 三大评价维度`,[{label:"完备性",sub1:"保证找到解",sub2:"（若解存在）",impact:"影响可行性",en:"Completeness",color:"teal"},{label:"最优性",sub1:"全局最优解",sub2:"vs 局部最优",impact:"影响质量",en:"Optimality",color:"orange"},{label:"复杂度",sub1:"时间 / 空间",sub2:"O(n) / O(n²)",impact:"影响扩展性",en:"Complexity",color:"purple"}]),_=he(o);return[{index:1,startMs:0,durationMs:15e3,title:"问题导入 · 粒子汇聚",subtitle:`当我们面对${r}的问题时，第一步是建立直觉。粒子从四周汇聚成核心节点，象征问题的聚焦。`,svg:i,motion:"intro"},{index:2,startMs:15e3,durationMs:2e4,title:"概念定义 · 形式化",subtitle:`${o} 的形式化定义：${n.formalDefinition}。输入空间经核心映射得到输出结果。`,svg:a,motion:"concept"},{index:3,startMs:35e3,durationMs:25e3,title:"算法流程图 · 多节点执行",subtitle:`${o} 的算法流程：输入 → 预处理 → 核心计算 → 判断收敛 → 输出，含循环反馈。核心计算节点是整个流程的关键。`,svg:c,motion:"flowchart"},{index:4,startMs:6e4,durationMs:35e3,title:`核心代码 · ${n.title}`,subtitle:`对应真实代码实现：${n.title}。右侧实时显示运行时状态变量变化，逐行高亮展示执行流程。`,svg:D,motion:"code"},{index:5,startMs:95e3,durationMs:2e4,title:"运行演示 · 变量状态",subtitle:`代码执行步骤：${A.steps.join(" → ")}。最终收敛并输出结果，每一步的变量状态实时更新。`,svg:b,motion:"runtime"},{index:6,startMs:115e3,durationMs:2e4,title:"关键性质 · 三栏对比",subtitle:`评价${o}的三个维度：完备性决定可行性，最优性决定质量，复杂度决定可扩展性。三者需权衡取舍。`,svg:v,motion:"compare"},{index:7,startMs:135e3,durationMs:15e3,title:"应用拓展 · 视频推荐",subtitle:`${o}已应用于工业界与学术界。查看下方外部视频推荐，深入理解主题：B站、YouTube、Coursera 等平台资源。`,svg:_,motion:"outro"}]},wn=e=>{const o=e.title,t=e.summary.split("，")[0],r=fe(o),n=xe(`主题：${o}`,t),i=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-timeline">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="28" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${o} · 演进脉络</text>

  <line x1="240" y1="50" x2="240" y2="210" stroke="#22D3EE" stroke-width="2" stroke-dasharray="4 4" data-anim="timeline-line"/>

  <g data-anim="tl-node-1">
    <circle cx="240" cy="65" r="8" fill="#F4A261" stroke="#F4A261" stroke-width="2"/>
    <text x="200" y="70" text-anchor="end" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">萌芽期</text>
    <text x="280" y="70" fill="#8B94A8" font-size="9" font-family="serif">思想起源与早期探索</text>
  </g>
  <g data-anim="tl-node-2" opacity="0">
    <circle cx="240" cy="105" r="8" fill="#1B9AAA" stroke="#1B9AAA" stroke-width="2"/>
    <text x="200" y="110" text-anchor="end" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">诞生期</text>
    <text x="280" y="110" fill="#8B94A8" font-size="9" font-family="serif">正式确立与符号主义</text>
  </g>
  <g data-anim="tl-node-3" opacity="0">
    <circle cx="240" cy="145" r="8" fill="#9D4EDD" stroke="#9D4EDD" stroke-width="2"/>
    <text x="200" y="150" text-anchor="end" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">发展期</text>
    <text x="280" y="150" fill="#8B94A8" font-size="9" font-family="serif">连接主义复兴与进步</text>
  </g>
  <g data-anim="tl-node-4" opacity="0">
    <circle cx="240" cy="185" r="8" fill="#10B981" stroke="#10B981" stroke-width="2"/>
    <text x="200" y="190" text-anchor="end" fill="#10B981" font-size="11" font-family="serif" font-weight="bold">繁荣期</text>
    <text x="280" y="190" fill="#8B94A8" font-size="9" font-family="serif">深度学习与大模型时代</text>
  </g>

  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">四个阶段见证领域的演进历程</text>
</svg>`,a=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-timeline-cards">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="28" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${o} · 关键里程碑</text>

  <g data-anim="tc-card-1">
    <rect x="30" y="50" width="130" height="150" rx="8" fill="#F4A26115" stroke="#F4A261" stroke-width="1.5"/>
    <text x="95" y="75" text-anchor="middle" fill="#F4A261" font-size="12" font-family="serif" font-weight="bold">里程碑一</text>
    <line x1="50" y1="88" x2="140" y2="88" stroke="#F4A261" stroke-width="1" opacity="0.5"/>
    <text x="95" y="108" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">开创性事件</text>
    <text x="95" y="128" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">奠定基础理论</text>
    <text x="95" y="150" text-anchor="middle" fill="#F4A261" font-size="9" font-family="serif">→ 推动领域起步</text>
    <text x="95" y="180" text-anchor="middle" fill="#4a5670" font-size="8" font-family="serif">奠基性贡献</text>
  </g>
  <g data-anim="tc-card-2" opacity="0">
    <rect x="175" y="50" width="130" height="150" rx="8" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1.5"/>
    <text x="240" y="75" text-anchor="middle" fill="#1B9AAA" font-size="12" font-family="serif" font-weight="bold">里程碑二</text>
    <line x1="195" y1="88" x2="285" y2="88" stroke="#1B9AAA" stroke-width="1" opacity="0.5"/>
    <text x="240" y="108" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">突破性进展</text>
    <text x="240" y="128" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">范式转换时刻</text>
    <text x="240" y="150" text-anchor="middle" fill="#1B9AAA" font-size="9" font-family="serif">→ 开启新纪元</text>
    <text x="240" y="180" text-anchor="middle" fill="#4a5670" font-size="8" font-family="serif">突破性贡献</text>
  </g>
  <g data-anim="tc-card-3" opacity="0">
    <rect x="320" y="50" width="130" height="150" rx="8" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1.5"/>
    <text x="385" y="75" text-anchor="middle" fill="#9D4EDD" font-size="12" font-family="serif" font-weight="bold">里程碑三</text>
    <line x1="340" y1="88" x2="430" y2="88" stroke="#9D4EDD" stroke-width="1" opacity="0.5"/>
    <text x="385" y="108" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">现代成果</text>
    <text x="385" y="128" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">大规模应用落地</text>
    <text x="385" y="150" text-anchor="middle" fill="#9D4EDD" font-size="9" font-family="serif">→ 改变世界格局</text>
    <text x="385" y="180" text-anchor="middle" fill="#4a5670" font-size="8" font-family="serif">划时代贡献</text>
  </g>

  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">关键事件推动历史车轮前进</text>
</svg>`,c=ye(`${o} · 代表人物与成果`,[{label:"先驱者",sub1:"开创领域",sub2:"奠定理论基础",impact:"思想启迪",en:"Pioneers",color:"orange"},{label:"推动者",sub1:"关键突破",sub2:"实现技术跨越",impact:"承前启后",en:"Pioneers",color:"teal"},{label:"集大成者",sub1:"体系化贡献",sub2:"推动应用落地",impact:"影响深远",en:"Masters",color:"purple"}]),l={keyword:"#9D4EDD",func:"#1B9AAA",string:"#F4A261",comment:"#4a5670",number:"#10B981",plain:"#8B94A8"},p=r.displayLines.slice(0,12),u=11,m=42,w=p.map((_,d)=>{const B=m+d*u,C=l[_.type]||l.plain,q=_.text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");return`${`<rect x="30" y="${B-9}" width="250" height="11" fill="#22D3EE20" data-anim="code-hl-${d+1}" opacity="0"/>`}<text x="34" y="${B}" fill="${C}" font-family="monospace" font-size="9">${q}</text>`}).join(""),A=r.vars,f=[A.init,...A.steps].slice(0,6).map((_,d)=>`<text x="300" y="${55+d*18}" fill="#8B94A8" font-family="monospace" font-size="8">${_}</text>`).join(""),D=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-code">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <rect x="0" y="0" width="480" height="22" fill="#141B2E"/>
  <circle cx="14" cy="11" r="3" fill="#F4A261"/>
  <circle cx="26" cy="11" r="3" fill="#22D3EE"/>
  <circle cx="38" cy="11" r="3" fill="#10B981"/>
  <text x="240" y="15" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="monospace">${r.id}.py · ${r.title}</text>

  <g font-family="monospace" font-size="9">
    <g fill="#4a5670" data-anim="code-gutter">
      ${p.map((_,d)=>`<text x="14" y="${m+d*u}">${d+1}</text>`).join("")}
    </g>
    <g data-anim="code-content">
      ${w}
    </g>
  </g>

  <line x1="290" y1="22" x2="290" y2="240" stroke="#1a2235" stroke-width="1"/>
  <text x="385" y="36" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">运行时状态 · ${A.name}</text>

  <g font-family="monospace" font-size="8" data-anim="code-state">
    ${f}
  </g>

  <text x="300" y="180" fill="#8B94A8" font-size="8" font-family="serif">执行进度</text>
  <rect x="300" y="186" width="165" height="4" rx="2" fill="#1a2235"/>
  <rect x="300" y="186" width="0" height="4" rx="2" fill="#22D3EE" data-anim="conv-bar"/>
  <text x="465" y="200" text-anchor="end" fill="#22D3EE" font-size="8" font-family="monospace" data-anim="conv-pct">0%</text>

  <text x="240" y="225" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">真实代码 · ${r.title}</text>
</svg>`,b=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-concept">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="32" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold" data-anim="concept-title">${o} · 影响与启示</text>

  <g data-anim="formula-block" opacity="0">
    <rect x="60" y="55" width="360" height="70" rx="8" fill="#1a223580" stroke="#F4A261" stroke-width="1" stroke-dasharray="4 4"/>
    <text x="240" y="85" text-anchor="middle" fill="#F4A261" font-size="13" font-family="serif">历史照亮未来，经验启迪智慧</text>
    <text x="240" y="108" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">从历史中汲取前进的力量</text>
  </g>

  <g data-anim="terms" opacity="0">
    <rect x="40" y="145" width="130" height="65" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1"/>
    <text x="105" y="168" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">学术影响</text>
    <text x="105" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">理论方法传承</text>
    <text x="105" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">跨学科融合</text>

    <rect x="180" y="145" width="130" height="65" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="1"/>
    <text x="245" y="168" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">产业变革</text>
    <text x="245" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">生产力跃升</text>
    <text x="245" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">新模式涌现</text>

    <rect x="320" y="145" width="130" height="65" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1"/>
    <text x="385" y="168" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">社会意义</text>
    <text x="385" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">生活方式改变</text>
    <text x="385" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">认知边界拓展</text>
  </g>
</svg>`,v=he(o);return[{index:1,startMs:0,durationMs:15e3,title:"导入 · 主题引入",subtitle:`今天我们来了解${o}。粒子从四面八方汇聚成核心节点，象征着历史长河中无数思想的碰撞与融合，最终凝聚成这一重要主题。`,svg:n,motion:"intro"},{index:2,startMs:15e3,durationMs:2e4,title:"时间轴 · 演进脉络",subtitle:`${o}的发展经历了四个主要阶段：从萌芽期的思想起源，到诞生期的正式确立，再到发展期的连接主义复兴，最终进入繁荣期的深度学习时代。每个阶段都有其标志性的事件与成果。`,svg:i,motion:"timeline"},{index:3,startMs:35e3,durationMs:25e3,title:"关键事件 · 里程碑卡片",subtitle:`三个里程碑事件塑造了${o}的发展轨迹：第一个里程碑奠定了理论基础，第二个里程碑实现了范式转换，第三个里程碑推动了大规模应用落地。每一步都在历史上留下了深刻印记。`,svg:a,motion:"timeline-cards"},{index:4,startMs:6e4,durationMs:2e4,title:"代表人物 · 成果展示",subtitle:`在${o}的发展历程中，涌现出了无数杰出人物：先驱者们开创了领域先河，推动者们实现了关键突破，集大成者们推动了体系化发展。他们的智慧与努力共同铸就了今天的成就。`,svg:c,motion:"compare"},{index:5,startMs:8e4,durationMs:35e3,title:`核心代码 · ${r.title}`,subtitle:`对应真实代码实现：${r.title}。右侧实时显示运行时状态变量变化，逐行高亮展示执行流程。`,svg:D,motion:"code"},{index:6,startMs:115e3,durationMs:2e4,title:"影响与启示",subtitle:`${o}的发展不仅带来了学术上的深远影响，推动了理论方法的传承与跨学科融合，更引发了产业变革，实现了生产力的跃升和新模式的涌现，最终深刻改变了人们的生活方式，拓展了人类的认知边界。`,svg:b,motion:"concept"},{index:7,startMs:135e3,durationMs:15e3,title:"拓展 · 视频推荐",subtitle:`了解完${o}的发展历程，你可以进一步探索相关内容。我们为你推荐了B站、YouTube、Coursera 等平台的优质视频资源，帮助你从更多维度深入理解这一主题。`,svg:v,motion:"outro"}]},bn=e=>{const o=e.title,t=e.summary.split("，")[0],r=fe(o),n=xe("问题引入",t),i=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-concept">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="32" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold" data-anim="concept-title">${o} · 核心定义</text>

  <g data-anim="formula-block" opacity="0">
    <rect x="50" y="55" width="380" height="80" rx="8" fill="#1a223580" stroke="#22D3EE" stroke-width="1" stroke-dasharray="4 4"/>
    <text x="240" y="90" text-anchor="middle" fill="#F4A261" font-size="14" font-family="serif" font-style="italic">${r.formula}</text>
    <text x="240" y="115" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">${r.formulaDesc}</text>
  </g>

  <g data-anim="terms" opacity="0">
    <rect x="40" y="150" width="130" height="60" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1"/>
    <text x="105" y="172" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">内涵</text>
    <text x="105" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">概念的本质属性</text>

    <rect x="180" y="150" width="130" height="60" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="1"/>
    <text x="245" y="172" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">外延</text>
    <text x="245" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">涵盖的具体范围</text>

    <rect x="320" y="150" width="130" height="60" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1"/>
    <text x="385" y="172" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">特征</text>
    <text x="385" y="192" text-anchor="middle" fill="#8B94A8" font-size="9">显著的标志特点</text>
  </g>
</svg>`,a=ye(`${o} · 关键维度`,[{label:"维度一",sub1:"核心属性",sub2:"本质特征描述",impact:"决定性质",en:"Dimension 1",color:"teal"},{label:"维度二",sub1:"分类依据",sub2:"划分标准说明",impact:"构建体系",en:"Dimension 2",color:"orange"},{label:"维度三",sub1:"表现形式",sub2:"具体呈现方式",impact:"指导应用",en:"Dimension 3",color:"purple"}]),c={keyword:"#9D4EDD",func:"#1B9AAA",string:"#F4A261",comment:"#4a5670",number:"#10B981",plain:"#8B94A8"},l=r.displayLines.slice(0,12),p=11,u=42,m=l.map((_,d)=>{const B=u+d*p,C=c[_.type]||c.plain,q=_.text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");return`${`<rect x="30" y="${B-9}" width="250" height="11" fill="#22D3EE20" data-anim="code-hl-${d+1}" opacity="0"/>`}<text x="34" y="${B}" fill="${C}" font-family="monospace" font-size="9">${q}</text>`}).join(""),w=r.vars,x=[w.init,...w.steps].slice(0,6).map((_,d)=>`<text x="300" y="${55+d*18}" fill="#8B94A8" font-family="monospace" font-size="8">${_}</text>`).join(""),f=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-code">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <rect x="0" y="0" width="480" height="22" fill="#141B2E"/>
  <circle cx="14" cy="11" r="3" fill="#F4A261"/>
  <circle cx="26" cy="11" r="3" fill="#22D3EE"/>
  <circle cx="38" cy="11" r="3" fill="#10B981"/>
  <text x="240" y="15" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="monospace">${r.id}.py · ${r.title}</text>

  <g font-family="monospace" font-size="9">
    <g fill="#4a5670" data-anim="code-gutter">
      ${l.map((_,d)=>`<text x="14" y="${u+d*p}">${d+1}</text>`).join("")}
    </g>
    <g data-anim="code-content">
      ${m}
    </g>
  </g>

  <line x1="290" y1="22" x2="290" y2="240" stroke="#1a2235" stroke-width="1"/>
  <text x="385" y="36" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">运行时状态 · ${w.name}</text>

  <g font-family="monospace" font-size="8" data-anim="code-state">
    ${x}
  </g>

  <text x="300" y="180" fill="#8B94A8" font-size="8" font-family="serif">执行进度</text>
  <rect x="300" y="186" width="165" height="4" rx="2" fill="#1a2235"/>
  <rect x="300" y="186" width="0" height="4" rx="2" fill="#22D3EE" data-anim="conv-bar"/>
  <text x="465" y="200" text-anchor="end" fill="#22D3EE" font-size="8" font-family="monospace" data-anim="conv-pct">0%</text>

  <text x="240" y="225" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">真实代码 · ${r.title}</text>
</svg>`,D=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-compare">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="28" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${o} · 对比辨析</text>

  <line x1="240" y1="45" x2="240" y2="215" stroke="#1a2235" stroke-width="2" stroke-dasharray="4 4"/>
  <text x="240" y="40" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">VS</text>

  <g data-anim="left-col">
    <rect x="40" y="55" width="180" height="140" rx="8" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1.5"/>
    <text x="130" y="80" text-anchor="middle" fill="#1B9AAA" font-size="13" font-family="serif" font-weight="bold">${o}</text>
    <line x1="60" y1="95" x2="200" y2="95" stroke="#1B9AAA" stroke-width="1" opacity="0.5"/>
    <text x="130" y="118" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 核心特征描述</text>
    <text x="130" y="138" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 适用场景说明</text>
    <text x="130" y="158" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 典型代表举例</text>
    <text x="130" y="180" text-anchor="middle" fill="#1B9AAA" font-size="9" font-family="serif">→ 把握本质</text>
  </g>

  <g data-anim="right-col" opacity="0">
    <rect x="260" y="55" width="180" height="140" rx="8" fill="#F4A26115" stroke="#F4A261" stroke-width="1.5"/>
    <text x="350" y="80" text-anchor="middle" fill="#F4A261" font-size="13" font-family="serif" font-weight="bold">易混淆概念</text>
    <line x1="280" y1="95" x2="420" y2="95" stroke="#F4A261" stroke-width="1" opacity="0.5"/>
    <text x="350" y="118" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 形似之处辨析</text>
    <text x="350" y="138" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 关键区别说明</text>
    <text x="350" y="158" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">• 辨别方法技巧</text>
    <text x="350" y="180" text-anchor="middle" fill="#F4A261" font-size="9" font-family="serif">→ 避免混淆</text>
  </g>

  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">通过对比精准把握概念边界</text>
</svg>`,b=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-compare">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="30" text-anchor="middle" fill="#22D3EE" font-size="13" font-family="serif" font-weight="bold">${o} · 应用场景</text>
  <g data-anim="card-1">
    <rect x="30" y="55" width="130" height="140" rx="8" fill="#22D3EE15" stroke="#22D3EE" stroke-width="1.5"/>
    <circle cx="95" cy="85" r="16" fill="#22D3EE" opacity="0.3"/>
    <text x="95" y="90" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">场景一</text>
    <text x="95" y="115" text-anchor="middle" fill="#8B94A8" font-size="10">领域应用</text>
    <text x="95" y="135" text-anchor="middle" fill="#8B94A8" font-size="9">具体情境描述</text>
    <text x="95" y="165" text-anchor="middle" fill="#22D3EE" font-size="9">→ 解决实际问题</text>
    <text x="95" y="185" text-anchor="middle" fill="#4a5670" font-size="8">典型应用</text>
  </g>
  <g data-anim="card-2" opacity="0">
    <rect x="175" y="55" width="130" height="140" rx="8" fill="#F4A26115" stroke="#F4A261" stroke-width="1.5"/>
    <rect x="220" y="75" width="40" height="20" rx="3" fill="#F4A261" opacity="0.4"/>
    <text x="240" y="90" text-anchor="middle" fill="#F4A261" font-size="14" font-family="serif" font-weight="bold">场景二</text>
    <text x="240" y="115" text-anchor="middle" fill="#8B94A8" font-size="10">学术研究</text>
    <text x="240" y="135" text-anchor="middle" fill="#8B94A8" font-size="9">理论探索方向</text>
    <text x="240" y="165" text-anchor="middle" fill="#F4A261" font-size="9">→ 推动前沿发展</text>
    <text x="240" y="185" text-anchor="middle" fill="#4a5670" font-size="8">研究热点</text>
  </g>
  <g data-anim="card-3" opacity="0">
    <rect x="320" y="55" width="130" height="140" rx="8" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1.5"/>
    <path d="M365 82 L385 70 L385 94 Z" fill="#9D4EDD" opacity="0.4"/>
    <text x="385" y="90" text-anchor="middle" fill="#9D4EDD" font-size="14" font-family="serif" font-weight="bold">场景三</text>
    <text x="385" y="115" text-anchor="middle" fill="#8B94A8" font-size="10">工程实践</text>
    <text x="385" y="135" text-anchor="middle" fill="#8B94A8" font-size="9">技术落地实施</text>
    <text x="385" y="165" text-anchor="middle" fill="#9D4EDD" font-size="9">→ 创造实用价值</text>
    <text x="385" y="185" text-anchor="middle" fill="#4a5670" font-size="8">实战场景</text>
  </g>
  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">理论联系实际，学以致用</text>
</svg>`,v=he(o);return[{index:1,startMs:0,durationMs:15e3,title:"导入 · 问题引入",subtitle:`当我们面对${t}的问题时，首先需要建立清晰的概念认知。粒子从四周汇聚成核心节点，象征着我们对这一概念从模糊到清晰的认识过程。`,svg:n,motion:"intro"},{index:2,startMs:15e3,durationMs:2e4,title:"核心定义",subtitle:`${o}的核心定义是：${e.summary.replace(/。$/,"")}。理解一个概念需要从三个层面入手：内涵揭示概念的本质属性，外延界定概念涵盖的具体范围，特征则是概念最显著的标志特点。`,svg:i,motion:"concept"},{index:3,startMs:35e3,durationMs:25e3,title:"关键维度 · 分类体系",subtitle:`${o}可以从多个关键维度来理解和分类：第一个维度揭示其核心属性，决定了概念的根本性质；第二个维度提供分类依据，帮助我们构建完整的知识体系；第三个维度展现其表现形式，指导我们在实践中如何应用。`,svg:a,motion:"compare"},{index:4,startMs:6e4,durationMs:35e3,title:`核心代码 · ${r.title}`,subtitle:`对应真实代码实现：${r.title}。右侧实时显示运行时状态变量变化，逐行高亮展示执行流程。`,svg:f,motion:"code"},{index:5,startMs:95e3,durationMs:2e4,title:"对比辨析",subtitle:`学习${o}的过程中，很容易与一些相似概念混淆。通过左右对比，我们可以清晰地看到两者之间的形似之处与关键区别，掌握辨别方法技巧，从而精准把握概念的边界，避免在应用中出现偏差。`,svg:D,motion:"compare"},{index:6,startMs:115e3,durationMs:2e4,title:"应用场景",subtitle:`${o}在现实世界中有着广泛的应用：在领域应用中解决实际问题，在学术研究中推动前沿发展，在工程实践中创造实用价值。理论联系实际，才能真正掌握并灵活运用这一概念。`,svg:b,motion:"compare"},{index:7,startMs:135e3,durationMs:15e3,title:"拓展 · 视频推荐",subtitle:`掌握了${o}的核心概念后，你可以进一步探索更多相关内容。我们为你推荐了B站、YouTube、Coursera 等平台的优质视频资源，帮助你从更多维度深化理解，拓展知识边界。`,svg:v,motion:"outro"}]},En=e=>{const o=e.title,t=o.slice(0,4),r=e.summary.split("，")[0],n=fe(o),i=xe("问题引入",r),a=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-concept">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="32" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold" data-anim="concept-title">${o} · 核心思想</text>

  <g data-anim="formula-block" opacity="0">
    <rect x="60" y="55" width="360" height="70" rx="8" fill="#1a223580" stroke="#22D3EE" stroke-width="1" stroke-dasharray="4 4"/>
    <text x="240" y="85" text-anchor="middle" fill="#F4A261" font-size="14" font-family="serif" font-style="italic">${n.formula}</text>
    <text x="240" y="108" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">${n.formulaDesc}</text>
  </g>

  <g data-anim="terms" opacity="0">
    <rect x="40" y="145" width="130" height="65" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="1"/>
    <text x="105" y="168" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">输入表示</text>
    <text x="105" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">数据编码方式</text>
    <text x="105" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">特征工程</text>

    <rect x="180" y="145" width="130" height="65" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="1"/>
    <text x="245" y="168" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">变换机制</text>
    <text x="245" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">信息处理方式</text>
    <text x="245" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">核心算法</text>

    <rect x="320" y="145" width="130" height="65" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="1"/>
    <text x="385" y="168" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">输出预测</text>
    <text x="385" y="188" text-anchor="middle" fill="#8B94A8" font-size="9">结果生成方式</text>
    <text x="385" y="204" text-anchor="middle" fill="#8B94A8" font-size="8">决策函数</text>
  </g>
</svg>`,c=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-architecture">
  <defs>
    <marker id="arch-arrow" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
      <path d="M0 0 L8 4 L0 8 Z" fill="#22D3EE"/>
    </marker>
  </defs>
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="26" text-anchor="middle" fill="#22D3EE" font-size="14" font-family="serif" font-weight="bold">${o} · 模型架构</text>

  <g data-anim="arch-input">
    <rect x="60" y="50" width="100" height="35" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="2"/>
    <text x="110" y="72" text-anchor="middle" fill="#1B9AAA" font-size="12" font-family="serif" font-weight="bold">输入层</text>
    <text x="110" y="100" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">Input Layer</text>
  </g>

  <path d="M160 67 L200 67" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="arch-line-1" marker-end="url(#arch-arrow)" opacity="0"/>

  <g data-anim="arch-hidden1" opacity="0">
    <rect x="200" y="45" width="100" height="45" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="2"/>
    <text x="250" y="65" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">隐藏层 1</text>
    <text x="250" y="82" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">特征提取</text>
  </g>

  <path d="M300 67 L340 67" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="arch-line-2" marker-end="url(#arch-arrow)" opacity="0"/>

  <g data-anim="arch-hidden2" opacity="0">
    <rect x="340" y="45" width="100" height="45" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="2"/>
    <text x="390" y="65" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">隐藏层 2</text>
    <text x="390" y="82" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">抽象表示</text>
  </g>

  <path d="M390 90 L390 120" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="arch-line-3" marker-end="url(#arch-arrow)" opacity="0"/>

  <g data-anim="arch-output" opacity="0">
    <rect x="340" y="125" width="100" height="40" rx="6" fill="#10B98115" stroke="#10B981" stroke-width="2"/>
    <text x="390" y="150" text-anchor="middle" fill="#10B981" font-size="12" font-family="serif" font-weight="bold">输出层</text>
    <text x="390" y="178" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">Output Layer</text>
  </g>

  <g data-anim="arch-labels" opacity="0">
    <text x="110" y="155" fill="#1B9AAA" font-size="9" font-family="serif">原始数据输入</text>
    <text x="250" y="120" fill="#F4A261" font-size="9" font-family="serif">逐层特征变换</text>
    <text x="390" y="200" fill="#10B981" font-size="9" font-family="serif">最终预测结果</text>
  </g>

  <text x="240" y="225" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">层级结构实现从输入到输出的端到端映射</text>
</svg>`,l=ye(`${o} · 关键模块`,[{label:"模块一",sub1:"核心组件",sub2:"功能定位说明",impact:"基础支撑",en:"Module 1",color:"teal"},{label:"模块二",sub1:"关键机制",sub2:"工作原理描述",impact:"核心驱动",en:"Module 2",color:"orange"},{label:"模块三",sub1:"输出组件",sub2:"结果生成方式",impact:"最终呈现",en:"Module 3",color:"purple"}]),p={keyword:"#9D4EDD",func:"#1B9AAA",string:"#F4A261",comment:"#4a5670",number:"#10B981",plain:"#8B94A8"},u=n.displayLines.slice(0,12),m=11,w=42,A=u.map((d,B)=>{const C=w+B*m,q=p[d.type]||p.plain,g=d.text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");return`${`<rect x="30" y="${C-9}" width="250" height="11" fill="#22D3EE20" data-anim="code-hl-${B+1}" opacity="0"/>`}<text x="34" y="${C}" fill="${q}" font-family="monospace" font-size="9">${g}</text>`}).join(""),x=n.vars,D=[x.init,...x.steps].slice(0,6).map((d,B)=>`<text x="300" y="${55+B*18}" fill="#8B94A8" font-family="monospace" font-size="8">${d}</text>`).join(""),b=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-code">
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <rect x="0" y="0" width="480" height="22" fill="#141B2E"/>
  <circle cx="14" cy="11" r="3" fill="#F4A261"/>
  <circle cx="26" cy="11" r="3" fill="#22D3EE"/>
  <circle cx="38" cy="11" r="3" fill="#10B981"/>
  <text x="240" y="15" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="monospace">${n.id}.py · ${n.title}</text>

  <g font-family="monospace" font-size="9">
    <g fill="#4a5670" data-anim="code-gutter">
      ${u.map((d,B)=>`<text x="14" y="${w+B*m}">${B+1}</text>`).join("")}
    </g>
    <g data-anim="code-content">
      ${A}
    </g>
  </g>

  <line x1="290" y1="22" x2="290" y2="240" stroke="#1a2235" stroke-width="1"/>
  <text x="385" y="36" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">运行时状态 · ${x.name}</text>

  <g font-family="monospace" font-size="8" data-anim="code-state">
    ${D}
  </g>

  <text x="300" y="180" fill="#8B94A8" font-size="8" font-family="serif">执行进度</text>
  <rect x="300" y="186" width="165" height="4" rx="2" fill="#1a2235"/>
  <rect x="300" y="186" width="0" height="4" rx="2" fill="#22D3EE" data-anim="conv-bar"/>
  <text x="465" y="200" text-anchor="end" fill="#22D3EE" font-size="8" font-family="monospace" data-anim="conv-pct">0%</text>

  <text x="240" y="225" text-anchor="middle" fill="#8B94A8" font-size="10" font-family="serif">核心代码 · ${n.title}</text>
</svg>`,v=`<svg viewBox="0 0 480 240" xmlns="http://www.w3.org/2000/svg" class="anim-svg anim-flowchart">
  <defs>
    <marker id="train-arrow" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
      <path d="M0 0 L8 4 L0 8 Z" fill="#22D3EE"/>
    </marker>
  </defs>
  <rect width="480" height="240" fill="#0A0E1A" rx="12"/>
  <text x="240" y="24" text-anchor="middle" fill="#22D3EE" font-size="13" font-family="serif" font-weight="bold">${o} · 训练流程</text>

  <g data-anim="train-step-1">
    <rect x="30" y="50" width="100" height="40" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="2"/>
    <text x="80" y="70" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">数据准备</text>
    <text x="80" y="86" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">数据集划分</text>
  </g>

  <path d="M130 70 L170 70" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="train-line-1" marker-end="url(#train-arrow)" opacity="0"/>

  <g data-anim="train-step-2" opacity="0">
    <rect x="170" y="50" width="100" height="40" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="2"/>
    <text x="220" y="70" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">初始化</text>
    <text x="220" y="86" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">参数随机初始化</text>
  </g>

  <path d="M270 70 L310 70" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="train-line-2" marker-end="url(#train-arrow)" opacity="0"/>

  <g data-anim="train-step-3" opacity="0">
    <rect x="310" y="50" width="100" height="40" rx="6" fill="#9D4EDD15" stroke="#9D4EDD" stroke-width="2"/>
    <text x="360" y="70" text-anchor="middle" fill="#9D4EDD" font-size="11" font-family="serif" font-weight="bold">前向传播</text>
    <text x="360" y="86" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">计算预测输出</text>
  </g>

  <path d="M410 70 L410 100" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="train-line-3" marker-end="url(#train-arrow)" opacity="0"/>

  <g data-anim="train-step-4" opacity="0">
    <rect x="310" y="105" width="100" height="40" rx="6" fill="#10B98115" stroke="#10B981" stroke-width="2"/>
    <text x="360" y="125" text-anchor="middle" fill="#10B981" font-size="11" font-family="serif" font-weight="bold">计算损失</text>
    <text x="360" y="141" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">误差评估</text>
  </g>

  <path d="M310 125 L270 125" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="train-line-4" marker-end="url(#train-arrow)" opacity="0"/>

  <g data-anim="train-step-5" opacity="0">
    <rect x="170" y="105" width="100" height="40" rx="6" fill="#F4A26115" stroke="#F4A261" stroke-width="2"/>
    <text x="220" y="125" text-anchor="middle" fill="#F4A261" font-size="11" font-family="serif" font-weight="bold">反向传播</text>
    <text x="220" y="141" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">梯度计算</text>
  </g>

  <path d="M170 125 L130 125" stroke="#22D3EE" stroke-width="1.5" stroke-dasharray="4 4" data-anim="train-line-5" marker-end="url(#train-arrow)" opacity="0"/>

  <g data-anim="train-step-6" opacity="0">
    <rect x="30" y="105" width="100" height="40" rx="6" fill="#1B9AAA15" stroke="#1B9AAA" stroke-width="2"/>
    <text x="80" y="125" text-anchor="middle" fill="#1B9AAA" font-size="11" font-family="serif" font-weight="bold">参数更新</text>
    <text x="80" y="141" text-anchor="middle" fill="#8B94A8" font-size="8" font-family="serif">优化器迭代</text>
  </g>

  <path d="M80 145 L80 175 L360 175 L360 145" stroke="#F4A261" stroke-width="1.5" stroke-dasharray="3 3" fill="none" data-anim="train-loop" marker-end="url(#train-arrow)" opacity="0"/>
  <text x="220" y="195" fill="#F4A261" font-size="9" font-family="serif" data-anim="train-loop-label" opacity="0">循环迭代直至收敛</text>

  <text x="240" y="222" text-anchor="middle" fill="#8B94A8" font-size="9" font-family="serif">数据 → 前向 → 损失 → 反向 → 更新，循环往复</text>
</svg>`,_=he(o);return[{index:1,startMs:0,durationMs:15e3,title:"导入 · 问题引入",subtitle:`当我们面对${r}的问题时，模型方法为我们提供了强大的解决工具。粒子从四周汇聚成核心节点，象征着从复杂问题中提炼出模型的核心思想。`,svg:i,motion:"intro"},{index:2,startMs:15e3,durationMs:2e4,title:"核心思想",subtitle:`${o}的核心思想是：${e.summary.replace(/。$/,"")}。一个完整的模型包含三个关键部分：输入表示负责数据的编码方式和特征工程，变换机制实现信息处理和核心算法，输出预测则生成最终结果和决策函数。`,svg:a,motion:"concept"},{index:3,startMs:35e3,durationMs:3e4,title:"模型架构图",subtitle:`${o}采用层级化的架构设计：数据从输入层进入，经过隐藏层1进行特征提取，再通过隐藏层2完成更高层次的抽象表示，最终由输出层产生预测结果。这种端到端的层级结构实现了从原始数据到最终输出的完整映射。`,svg:c,motion:"architecture"},{index:4,startMs:65e3,durationMs:25e3,title:"关键模块",subtitle:`${t}模型由三大关键模块组成：模块一作为基础支撑组件，提供核心功能定位；模块二是核心驱动机制，实现主要的工作原理；模块三负责最终结果的生成和呈现。三大模块协同工作，构成完整的模型系统。`,svg:l,motion:"compare"},{index:5,startMs:9e4,durationMs:3e4,title:"核心代码",subtitle:`对应真实代码实现：${n.title}。右侧实时显示运行时状态变量变化，逐行高亮展示执行流程。通过代码可以更深入地理解模型的具体实现细节。`,svg:b,motion:"code"},{index:6,startMs:12e4,durationMs:15e3,title:"训练流程",subtitle:"模型的训练是一个循环迭代的过程：从数据准备开始，经过参数初始化、前向传播计算预测、计算损失评估误差、反向传播计算梯度，最后更新参数。如此循环往复，直至模型收敛，达到预期的性能指标。",svg:v,motion:"flowchart"},{index:7,startMs:135e3,durationMs:15e3,title:"拓展 · 视频推荐",subtitle:`掌握了${o}的架构与训练方法后，你可以进一步探索更多相关内容。我们为你推荐了B站、YouTube、Coursera 等平台的优质视频资源，帮助你从更多维度深入理解模型原理与实践。`,svg:_,motion:"outro"}]},Mt=e=>{switch(e.category||Ct(e.title)){case"history":return wn(e);case"concept":return bn(e);case"model":return En(e);case"algorithm":default:return An(e)}},Bn=e=>`# ${e.title} · 代码实操

> 实操匠生成 · Python 3.10+ · 含单元测试 · 一键复制

## 环境准备

\`\`\`bash
pip install numpy torch matplotlib
\`\`\`

## 核心实现

\`\`\`python
"""
${e.title} 最小可运行实现
作者: 实操匠智能体
"""
import numpy as np
from dataclasses import dataclass


@dataclass
class ${e.id.replace(/-/g,"_").replace(/^(\w)/,o=>o.toUpperCase())}Config:
    """配置项"""
    learning_rate: float = 1e-3
    max_steps: int = 1000
    tolerance: float = 1e-6


def run_${e.id.replace(/-/g,"_")}(config: ${e.id.replace(/-/g,"_").replace(/^(\w)/,o=>o.toUpperCase())}Config) -> dict:
    """
    运行 ${e.title} 的最小示例。
    返回: {"steps": int, "result": float, "converged": bool}
    """
    np.random.seed(42)
    state = np.random.randn(8)
    
    for step in range(config.max_steps):
        # 简化的迭代更新逻辑
        grad = 2 * state  # 模拟梯度
        state = state - config.learning_rate * grad
        if np.linalg.norm(grad) < config.tolerance:
            return {"steps": step, "result": float(state.mean()), "converged": True}
    return {"steps": config.max_steps, "result": float(state.mean()), "converged": False}


if __name__ == "__main__":
    cfg = ${e.id.replace(/-/g,"_").replace(/^(\w)/,o=>o.toUpperCase())}Config()
    out = run_${e.id.replace(/-/g,"_")}(cfg)
    print(f"收敛: {out['converged']}  步数: {out['steps']}  结果: {out['result']:.4f}")
\`\`\`

## 单元测试

\`\`\`python
def test_convergence():
    cfg = ${e.id.replace(/-/g,"_").replace(/^(\w)/,o=>o.toUpperCase())}Config(max_steps=10000)
    out = run_${e.id.replace(/-/g,"_")}(cfg)
    assert out["converged"] is True
    assert abs(out["result"]) < 1.0
\`\`\`

## 思考题

1. 将 \`learning_rate\` 调大到 1.0 会发生什么？为什么？
2. 如何将该实现扩展到批量数据？
3. 请尝试用 PyTorch 重写并支持 GPU。
`,qt={document:fn,mindmap:xn,quiz:hn,reading:yn,animation:gn,code:Bn},It={document:e=>`围绕"${e.title}"展开的学术讲解，含定义、性质、典型算法与学习建议，约 ${e.estimatedMinutes} 分钟。`,mindmap:e=>`"${e.title}" 思维导图：5 主分支 / 15 子节点，覆盖核心概念、关键性质、典型算法、应用与易错点。`,quiz:e=>`"${e.title}" 题库：5 题，难度 ★ ~ ★★★★★，含单选、多选、判断、简答、综合，针对画像易错点靶向出题。`,reading:e=>`"${e.title}" 拓展阅读 4 篇：经典教材章节、ACM 综述、工程博客、Stanford 讲座。`,animation:e=>`"${e.title}" 教学动画：7 分镜 / 150 秒可播放矢量动画，含粒子汇聚、概念定义、算法流程图、真实代码逐行执行、运行演示、对比卡片、视频推荐七种动效，支持字幕语音播报。`,code:e=>`"${e.title}" 代码实操：Python 3.10+ 可运行实现，含配置项、单元测试与思考题。`},us=(e,o)=>{const t=`custom-${Date.now()}`,r={id:t,chapter:0,title:o,parentId:null,difficulty:3,estimatedMinutes:30,prerequisites:[],summary:o};return{id:`R-${t}-${e}`,type:e,title:`${o} · ${zt[e].label}`,knowledgeId:t,content:qt[e](r),excerpt:It[e](r),metadata:{duration:e==="animation"?150:e==="quiz"?15:e==="code"?30:r.estimatedMinutes,difficulty:r.difficulty,knowledgePoints:[t],citations:e==="reading"||e==="document"?["Russell & Norvig, AIMA 4th","ACM Computing Surveys 2023"]:void 0,questionCount:e==="quiz"?5:void 0,nodeCount:e==="mindmap"?15:void 0,runtime:e==="code"?"Python 3.10+":void 0,scenes:e==="animation"?7:void 0,animationScenes:e==="animation"?Mt(r):void 0,videoProvider:e==="animation"?"vector":void 0,mindmap:e==="mindmap"?St(r):void 0,externalVideos:e==="animation"?_t(o):void 0},safetyCheck:{passed:!0,flags:[],score:100},createdAt:new Date().toLocaleString("zh-CN")}};function De(e,o,t){return Object.defineProperty(e,o,{configurable:!0,enumerable:!0,get(){const r=t();return Object.defineProperty(e,o,{value:r,configurable:!0,enumerable:!0,writable:!0}),r}}),e}const Lt=W.flatMap(e=>["document","mindmap","quiz","reading","animation","code"].map((t,r)=>{const n={duration:t==="animation"?120:t==="quiz"?15:t==="code"?30:e.estimatedMinutes,difficulty:e.difficulty,knowledgePoints:[e.id],citations:t==="reading"||t==="document"?["Russell & Norvig, AIMA 4th","ACM Computing Surveys 2023"]:void 0,questionCount:t==="quiz"?5:void 0,nodeCount:t==="mindmap"?15+e.prerequisites.length:void 0,runtime:t==="code"?"Python 3.10+":void 0,scenes:t==="animation"?7:void 0,videoProvider:t==="animation"?"vector":void 0,externalVideos:t==="animation"?_t(e.title):void 0};return t==="animation"&&De(n,"animationScenes",()=>Mt(e)),t==="mindmap"&&De(n,"mindmap",()=>St(e)),De({id:`R-${e.id}-${t}-${r}`,type:t,title:`${e.title} · ${zt[t].label}`,knowledgeId:e.id,excerpt:It[t](e),metadata:n,safetyCheck:{passed:!0,flags:[],score:100},createdAt:"2026-03-10 09:00"},"content",()=>qt[t](e))})),fs=e=>Lt.filter(o=>o.knowledgeId===e),xs=[{id:"pq-001",knowledgeId:"ai-intro",type:"single",question:"Python 中定义函数使用哪个关键字？",options:["function","def","func","define"],correctAnswer:1,explanation:"Python 使用 def 关键字定义函数。",difficulty:1},{id:"pq-002",knowledgeId:"ai-intro",type:"fill",question:"Python 中使用 ______ 关键字定义函数。",correctAnswer:"def",explanation:"def 是 define 的缩写，用于定义函数。",difficulty:1},{id:"pq-003",knowledgeId:"ai-intro",type:"code-fill",question:"补全代码，实现一个返回两数之和的函数：",codeTemplate:`def add(a, b):
    ______ a + b`,blanks:["return"],correctAnswer:["return"],explanation:"函数使用 return 语句返回计算结果。",difficulty:1},{id:"pq-004",knowledgeId:"ai-intro",type:"judge",question:"Python 函数必须有 return 语句。",correctAnswer:0,explanation:"Python 函数可以没有 return 语句，默认返回 None。",difficulty:1},{id:"pq-005",knowledgeId:"ai-intro",type:"code-fill",question:"补全代码，实现一个欢迎函数：",codeTemplate:`def welcome(name):
    print(f'欢迎, ______!')`,blanks:["{name}"],correctAnswer:["{name}"],explanation:"使用 f-string 格式化字符串，将 name 参数拼接到欢迎语中。",difficulty:2},{id:"pq-006",knowledgeId:"ai-history",type:"single",question:"被称为人工智能元年的是哪一年？",options:["1942 年","1956 年","1969 年","1980 年"],correctAnswer:1,explanation:"1956 年达特茅斯会议上，John McCarthy 首次提出人工智能（Artificial Intelligence）概念。",difficulty:1},{id:"pq-007",knowledgeId:"ai-history",type:"fill",question:"1956 年的 ______ 会议被认为是人工智能诞生的标志。",correctAnswer:"达特茅斯",explanation:"达特茅斯会议（Dartmouth Conference）由 John McCarthy 组织，首次提出了人工智能概念。",difficulty:1},{id:"pq-008",knowledgeId:"ai-history",type:"multiple",question:"以下哪些属于人工智能的研究领域？（多选）",options:["机器学习","计算机视觉","自然语言处理","软件工程"],correctAnswer:[0,1,2],explanation:"机器学习、计算机视觉、自然语言处理都是人工智能的重要研究领域，软件工程不属于。",difficulty:1},{id:"pq-009",knowledgeId:"ai-history",type:"single",question:"图灵测试是用来检验什么的？",options:["机器的计算速度","机器是否具有智能","机器的存储容量","机器的能耗"],correctAnswer:1,explanation:"图灵测试由 Alan Turing 提出，用于判断机器是否具有人类级别的智能。",difficulty:2},{id:"pq-010",knowledgeId:"ml-overview",type:"single",question:"机器学习中，以下哪种属于监督学习？",options:["聚类","分类","降维","关联规则"],correctAnswer:1,explanation:"分类是监督学习的典型任务，需要带标签的数据进行训练。",difficulty:2},{id:"pq-011",knowledgeId:"ml-overview",type:"fill",question:"机器学习按照学习方式可分为监督学习、______和强化学习三大类。",correctAnswer:"无监督学习",explanation:"机器学习主要分为监督学习、无监督学习、强化学习三大类。",difficulty:2},{id:"pq-012",knowledgeId:"ml-overview",type:"judge",question:"K-Means 是一种监督学习算法。",correctAnswer:0,explanation:"K-Means 是无监督学习中的聚类算法，不需要标签。",difficulty:1},{id:"pq-013",knowledgeId:"ml-overview",type:"code-fill",question:"补全代码，导入 sklearn 中的线性回归模型：",codeTemplate:`from sklearn.______ import LinearRegression
model = LinearRegression()`,blanks:["linear_model"],correctAnswer:["linear_model"],explanation:"sklearn.linear_model 模块包含线性回归等线性模型。",difficulty:2},{id:"pq-014",knowledgeId:"dl-fundamentals",type:"single",question:"神经网络中，常用的激活函数不包括？",options:["ReLU","Sigmoid","Tanh","Fibonacci"],correctAnswer:3,explanation:"Fibonacci（斐波那契）是数列，不是激活函数。",difficulty:2},{id:"pq-015",knowledgeId:"dl-fundamentals",type:"fill",question:"神经网络中，______ 层用于减少过拟合，随机丢弃部分神经元。",correctAnswer:"Dropout",explanation:"Dropout 层在训练时随机丢弃部分神经元，防止过拟合。",difficulty:2},{id:"pq-016",knowledgeId:"dl-fundamentals",type:"code-fill",question:"补全 PyTorch 代码，定义一个简单的全连接层：",codeTemplate:`import torch.nn as nn
layer = nn.______(in_features=784, out_features=256)`,blanks:["Linear"],correctAnswer:["Linear"],explanation:"nn.Linear 是 PyTorch 中的全连接（线性）层。",difficulty:2},{id:"pq-017",knowledgeId:"dl-cnn",type:"single",question:"CNN（卷积神经网络）最适合处理什么类型的数据？",options:["文本数据","图像数据","音频数据","表格数据"],correctAnswer:1,explanation:"CNN 通过卷积核提取局部特征，非常适合图像处理。",difficulty:1},{id:"pq-018",knowledgeId:"dl-cnn",type:"multiple",question:"以下哪些是 CNN 的常用组件？（多选）",options:["卷积层","池化层","全连接层","循环层"],correctAnswer:[0,1,2],explanation:"卷积层、池化层、全连接层是 CNN 的核心组件，循环层属于 RNN。",difficulty:2},{id:"pq-019",knowledgeId:"dl-cnn",type:"fill",question:"CNN 中，______ 层用于降低特征图的空间尺寸，减少计算量。",correctAnswer:"池化",explanation:"池化层（Pooling）通过下采样降低特征图尺寸，减少参数和计算量。",difficulty:2},{id:"pq-020",knowledgeId:"dl-transformer",type:"single",question:"Transformer 架构的核心机制是什么？",options:["卷积","循环","自注意力","池化"],correctAnswer:2,explanation:"自注意力（Self-Attention）是 Transformer 的核心机制。",difficulty:2},{id:"pq-021",knowledgeId:"dl-transformer",type:"fill",question:"Transformer 论文的论文标题是 Attention Is ______。",correctAnswer:"All You Need",explanation:"2017 年的论文 Attention Is All You Need 提出了 Transformer 架构。",difficulty:3},{id:"pq-022",knowledgeId:"dl-transformer",type:"judge",question:"Transformer 只能处理文本数据。",correctAnswer:0,explanation:"Transformer 不仅可以处理文本，也可以应用于图像（ViT）、音频等多种模态。",difficulty:2},{id:"pq-023",knowledgeId:"llm-pretrain",type:"single",question:"以下哪个不是大语言模型？",options:["GPT","BERT","ResNet","LLaMA"],correctAnswer:2,explanation:"ResNet 是计算机视觉中的卷积网络，不是大语言模型。",difficulty:1},{id:"pq-024",knowledgeId:"llm-pretrain",type:"fill",question:"LLM 的中文全称是 ______。",correctAnswer:"大语言模型",explanation:"LLM = Large Language Model，即大语言模型。",difficulty:1},{id:"pq-025",knowledgeId:"llm-pretrain",type:"multiple",question:"大语言模型的能力包括？（多选）",options:["文本生成","代码生成","图像生成","推理思考"],correctAnswer:[0,1,3],explanation:"大语言模型可以进行文本生成、代码生成和推理思考，图像生成是图像模型的专长。",difficulty:2},{id:"pq-026",knowledgeId:"llm-agent",type:"single",question:"Prompt Engineering（提示工程）的目的是什么？",options:["训练模型","优化模型输入以获得更好输出","压缩模型","部署模型"],correctAnswer:1,explanation:"提示工程通过设计巧妙的输入提示，让大模型输出更好的结果。",difficulty:2},{id:"pq-027",knowledgeId:"llm-agent",type:"fill",question:"让模型按照给定示例学习的提示技术叫做 ______ 提示（Few-shot）。",correctAnswer:"少样本",explanation:"Few-shot Learning（少样本学习）通过给几个示例让模型理解任务。",difficulty:2},{id:"pq-028",knowledgeId:"llm-agent",type:"judge",question:"Chain-of-Thought（思维链）提示可以提升模型的推理能力。",correctAnswer:1,explanation:"思维链提示让模型逐步思考，显著提升推理类任务的表现。",difficulty:2},{id:"pq-029",knowledgeId:"llm-rag",type:"single",question:"RAG（检索增强生成）的核心作用是？",options:["加速训练","减少参数","补充外部知识","降低部署成本"],correctAnswer:2,explanation:"RAG 通过检索外部知识库来增强生成内容的准确性和时效性。",difficulty:3},{id:"pq-030",knowledgeId:"llm-rag",type:"fill",question:"RAG 的三个主要步骤是检索、______、生成。",correctAnswer:"增强",explanation:"RAG = Retrieval-Augmented Generation，即检索-增强-生成。",difficulty:3},{id:"pq-031",knowledgeId:"dl-rnn",type:"single",question:"时间序列预测中，常用的深度学习模型是？",options:["ResNet","LSTM","BERT","GAN"],correctAnswer:1,explanation:"LSTM（长短期记忆网络）擅长处理序列数据，常用于时间序列预测。",difficulty:2},{id:"pq-032",knowledgeId:"dl-rnn",type:"fill",question:"ARIMA 模型用于 ______ 序列预测。",correctAnswer:"时间",explanation:"ARIMA 是经典的时间序列预测统计模型。",difficulty:2},{id:"pq-033",knowledgeId:"ml-overview",type:"single",question:"推荐系统中，协同过滤的核心思想是？",options:["内容相似","用户行为相似","价格相似","标签相似"],correctAnswer:1,explanation:"协同过滤基于用户或物品的行为相似性进行推荐。",difficulty:2},{id:"pq-034",knowledgeId:"ml-overview",type:"multiple",question:"推荐系统的常用方法有？（多选）",options:["协同过滤","内容推荐","混合推荐","随机推荐"],correctAnswer:[0,1,2],explanation:"协同过滤、内容推荐、混合推荐都是常用方法，随机推荐不是有效方法。",difficulty:2},{id:"pq-035",knowledgeId:"dl-cnn",type:"single",question:"计算机视觉中，目标检测的任务是？",options:["分类图像","定位并识别物体","生成图像","压缩图像"],correctAnswer:1,explanation:"目标检测既要定位物体位置，又要识别物体类别。",difficulty:2},{id:"pq-036",knowledgeId:"dl-cnn",type:"fill",question:"YOLO 是一种实时 ______ 检测算法。",correctAnswer:"目标",explanation:"YOLO（You Only Look Once）是著名的实时目标检测算法系列。",difficulty:2},{id:"pq-037",knowledgeId:"search-local",type:"single",question:"强化学习中，智能体通过什么来学习？",options:["标签数据","奖励信号","无标签数据","规则"],correctAnswer:1,explanation:"强化学习通过环境反馈的奖励信号来学习最优策略。",difficulty:2},{id:"pq-038",knowledgeId:"search-local",type:"fill",question:"强化学习的三要素是状态、动作和 ______。",correctAnswer:"奖励",explanation:"强化学习中，智能体在某状态下采取动作，获得奖励。",difficulty:2},{id:"pq-039",knowledgeId:"search-informed",type:"single",question:"Q-Learning 中，Q 值代表什么？",options:["质量","动作价值","数量","查询"],correctAnswer:1,explanation:"Q 值表示在某状态下采取某动作的预期累积奖励价值。",difficulty:3},{id:"pq-040",knowledgeId:"search-informed",type:"judge",question:"强化学习需要大量标注数据。",correctAnswer:0,explanation:"强化学习通过与环境交互获取奖励，不需要标注数据。",difficulty:2}],Dn={algorithms:[2],ml:[4],dl:[5],nlp:[6],cv:[5],rl:[2,5],agent:[6],engineering:[3,6]},Fn={beginner:.8,intermediate:1,advanced:1.3};function kn(e){const o=e.estimatedMinutes||30,t=[];return e.category==="concept"||e.category==="history"?(t.push({title:`学习概念：${e.title}`,description:e.summary||`掌握 ${e.title} 的核心概念与背景知识。`,estimatedMinutes:Math.round(o*.5),knowledgeId:e.id,knowledgeTitle:e.title,type:"video"}),t.push({title:`深度阅读：${e.title}`,description:`阅读相关材料，整理笔记，理解 ${e.title} 的关键要点。`,estimatedMinutes:Math.round(o*.4),knowledgeId:e.id,knowledgeTitle:e.title,type:"reading"})):e.category==="algorithm"?(t.push({title:`算法原理：${e.title}`,description:e.summary||`理解 ${e.title} 的算法思想与流程。`,estimatedMinutes:Math.round(o*.5),knowledgeId:e.id,knowledgeTitle:e.title,type:"video"}),t.push({title:`算法实现：${e.title}`,description:`动手实现或复现 ${e.title}，加深对细节的理解。`,estimatedMinutes:Math.round(o*.5),knowledgeId:e.id,knowledgeTitle:e.title,type:"practice"})):e.category==="model"&&(t.push({title:`模型原理：${e.title}`,description:e.summary||`学习 ${e.title} 的网络结构与训练方法。`,estimatedMinutes:Math.round(o*.5),knowledgeId:e.id,knowledgeTitle:e.title,type:"video"}),t.push({title:`代码实践：${e.title}`,description:`使用 PyTorch / sklearn 等工具实现 ${e.title} 的小例子。`,estimatedMinutes:Math.round(o*.5),knowledgeId:e.id,knowledgeTitle:e.title,type:"practice"})),t.push({title:`巩固测验：${e.title}`,description:`完成 ${e.title} 相关的练习题与测验，检验掌握情况。`,estimatedMinutes:Math.max(10,Math.round(o*.25)),knowledgeId:e.id,knowledgeTitle:e.title,type:"quiz"}),t}function vn(e,o,t,r){const n=Fn[t],i=e.flatMap(l=>kn(l).map(p=>({...p,estimatedMinutes:Math.round(p.estimatedMinutes*n)}))),a=Math.max(1,Math.ceil(i.length/o)),c=[];for(let l=0;l<i.length;l++){const p=Math.min(o,Math.floor(l/a)+1),u=new Date(r);u.setDate(u.getDate()+p-1),c.push({...i[l],day:p,date:u.toISOString().slice(0,10)})}return c}function jt(e,o){const{goal:t,focusAreas:r,difficulty:n,dailyMinutes:i,durationDays:a}=e;let c;if(r.length>0){const A=new Set;r.forEach(x=>{(Dn[x]||[]).forEach(f=>A.add(f))}),c=W.filter(x=>A.has(x.chapter)).sort((x,f)=>x.chapter-f.chapter)}else if(o&&o.some(A=>A.learned)){const A=new Set(o.filter(x=>x.learned||x.mastery>0).map(x=>x.knowledgeId));c=W.filter(x=>!A.has(x.id)).sort((x,f)=>x.difficulty-f.difficulty).slice(0,Math.max(6,Math.floor(a/3)))}else c=W.slice(0,Math.max(6,Math.floor(a/3)));c.length===0&&(c=W.slice(0,6));const l=new Date,p=new Date(l);p.setDate(p.getDate()+a-1);const u=vn(c,a,n,l),m=[],w=3;for(let A=0;A<w;A++){const x=Math.floor(A*a/w)+1,f=Math.floor((A+1)*a/w),D=u.filter(d=>d.day>=x&&d.day<=f),b=Array.from(new Set(D.map(d=>d.knowledgeId))),v=new Date(l);v.setDate(v.getDate()+f-1);const _=["夯实基础","深入核心","综合实战"];m.push({date:v.toISOString().slice(0,10),title:`第 ${A+1} 阶段：${_[A]}（${x}-${f} 天）`,knowledgeIds:b,tasks:D})}return{id:`plan-${Date.now()}`,title:t||"AI 学习计划",goal:t||"系统学习 AI 基础知识",createdAt:new Date().toISOString(),startDate:l.toISOString().slice(0,10),endDate:p.toISOString().slice(0,10),dailyMinutes:i,focusAreas:r,difficulty:n,milestones:m,status:"active"}}function ke(e){return jt({goal:"零基础入门人工智能",focusAreas:[],difficulty:"beginner",dailyMinutes:60,durationDays:30},e)}function N(e,o){if(typeof localStorage>"u")return o;try{const t=localStorage.getItem(e);return t?JSON.parse(t):o}catch(t){return console.warn(`Failed to load ${e} from localStorage`,t),o}}function F(e,o){if(!(typeof localStorage>"u"))try{localStorage.setItem(e,JSON.stringify(o))}catch(t){console.warn(`Failed to save ${e} to localStorage`,t)}}function ot(e){const o={知识基础:{up:["学完","掌握","理解","学会","完成","巩固","复习","做完了","掌握了","弄懂了","搞懂了","吃透了","入门了","上手了","基础扎实","基础不错","学得不错","进步很大","提升明显","越来越好了","有进步","知识增强","变强了"],down:["困难","不会","没学","不懂","忘记","卡住","看不懂","跟不上","太难了","好难","搞不懂","弄不明白","吃力","费劲","基础差","零基础","没基础","底子薄","很多不会","都忘了","难度大"]},认知风格:{up:["视觉","图解","动画","图","看视频","看图","可视化","看例子","看代码","实践","动手","写代码"],down:["文字","纯文本","听","朗读","看书","读文档","理论","纯理论"]},易错偏好:{up:["易错","错了","搞错","混淆","记错","做错","经常错","老错","容易错","粗心","不仔细"],down:["纠正","改对","不会再错","掌握了","搞清楚了","不混了","不会混淆了","细心了"]},学习节奏:{up:["快","加快","提速","加速","赶进度","冲刺","抓紧","高效","节奏快","进度快","学得快","吸收快","状态好","干劲足"],down:["慢","放慢","减速","降低速度","调慢","慢慢来","稳一点","节奏慢","进度慢","学不动","累了","疲惫","状态不好","压力大","跟不上","太赶了","太快了","难度大了"]},目标导向:{up:["目标明确","有目标","考研","考公","找工作","面试","项目","竞赛","比赛","考试","考证","冲","奋斗","坚持"],down:["迷茫","不知道学啥","没目标","方向不明","随便学学","兴趣爱好","随便看看"]},兴趣方向:{up:["感兴趣","喜欢","想学","想了解","好奇","着迷","ai","人工智能","机器学习","深度学习","神经网络","大模型","llm","gpt","transformer","nlp","cv","计算机视觉","自然语言","强化学习","多智能体","agent","算法","数据结构","编程","代码"],down:["不感兴趣","没兴趣","不想学","讨厌","无聊","枯燥","没意思"]}},t={},r={};for(const[n,i]of Object.entries(o)){let a=0,c="";for(const l of i.up)e.includes(l.toLowerCase())&&(a+=5+Math.floor(Math.random()*6),c||(c=l));for(const l of i.down)e.includes(l.toLowerCase())&&(a-=5+Math.floor(Math.random()*6),c||(c=l));a===0&&(a=Math.floor(Math.random()*7)-3),t[n]=a,c&&(r[n]=`基于「${c}」更新`)}return/transformer|注意力|attention/.test(e)&&(t.兴趣方向=(t.兴趣方向||0)+4,r.兴趣方向="对 Transformer / 注意力机制方向兴趣增强"),/神经网络|cnn|rnn|lstm/.test(e)&&(t.知识基础=(t.知识基础||0)+4,r.知识基础="深度学习相关知识基础提升"),/大模型|llm|gpt|prompt|rag/.test(e)&&(t.兴趣方向=(t.兴趣方向||0)+6,r.兴趣方向="大模型方向兴趣显著增强"),/算法|dp|动态规划|搜索|排序/.test(e)&&(t.知识基础=(t.知识基础||0)+4,r.知识基础="算法基础提升"),/代码|编程|实践|实操|实现|写代码/.test(e)&&(t.认知风格=(t.认知风格||0)+4,r.认知风格="实践型认知风格增强"),/项目|考试|面试/.test(e)&&(t.目标导向=(t.目标导向||0)+4,r.目标导向="目标导向更明确"),{dimensionDeltas:t,dimensionEvidences:r}}const Nt=N("eduverse-theme","dark"),$n=N("eduverse-onboarded",!1),Tt=N("eduverse-learner",null),nt=N("eduverse-profile",null),st=N("eduverse-profile-history",null),_n=N("eduverse-learning-records",null),zn=N("eduverse-practice-records",[]),ve=N("eduverse-study-plans",[]),Cn=N("eduverse-user-questions",[]),Sn=N("eduverse-custom-learners",[]),Mn=[...te,...Sn.filter(e=>!te.some(o=>o.id===e.id))];function qn(e){return e?te.some(o=>o.id===e.id):!1}const qe=qn(Tt),Rt=qe?_n||$t:[],In=qe?nt||Me:nt||V,Ln=qe?st||vt:st||[V],Ie=ve.length>0?ve:[ke(Rt)];var at;const Pt=N("eduverse-current-plan-id",null)??((at=Ie[0])==null?void 0:at.id)??null;ve.length===0&&(F("eduverse-study-plans",Ie),F("eduverse-current-plan-id",Pt));typeof document<"u"&&(document.documentElement.classList.remove("dark","light"),document.documentElement.classList.add(Nt));const K=on((e,o)=>({theme:Nt,toggleTheme:()=>e(t=>{const r=t.theme==="dark"?"light":"dark";return typeof document<"u"&&(document.documentElement.classList.remove("dark","light"),document.documentElement.classList.add(r)),F("eduverse-theme",r),{theme:r}}),learner:Tt||kt,presetLearners:Mn,onboarded:$n,setOnboarded:t=>{F("eduverse-onboarded",t),e({onboarded:t})},selectLearner:t=>e(r=>{var D,b;const n=r.presetLearners.find(v=>v.id===t)||r.learner,i=n.id===r.learner.id,a=N("eduverse-learner-snapshots",{});r.onboarded&&!i&&(a[r.learner.id]={profile:r.currentProfile,profileHistory:r.profileHistory,learningRecords:r.learningRecords,practiceRecords:r.practiceRecords,userQuestions:r.userQuestions,studyPlans:r.studyPlans,currentPlanId:r.currentPlanId},F("eduverse-learner-snapshots",a));const c=te.some(v=>v.id===n.id),l=i?void 0:a[n.id],p=(l==null?void 0:l.profile)??(c?Me:V),u=(l==null?void 0:l.profileHistory)??(c?vt:[V]),m=(l==null?void 0:l.learningRecords)??(c?$t:[]),w=(l==null?void 0:l.practiceRecords)??[],A=(l==null?void 0:l.userQuestions)??[],x=(D=l==null?void 0:l.studyPlans)!=null&&D.length?l.studyPlans:[ke(m)],f=(l==null?void 0:l.currentPlanId)??((b=x[0])==null?void 0:b.id)??null;return F("eduverse-learner",n),F("eduverse-profile",p),F("eduverse-profile-history",u),F("eduverse-learning-records",m),F("eduverse-practice-records",w),F("eduverse-user-questions",A),F("eduverse-study-plans",x),F("eduverse-current-plan-id",f),{learner:n,currentProfile:p,profileHistory:u,learningRecords:m,practiceRecords:w,userQuestions:A,studyPlans:x,currentPlanId:f,profileMessages:[],tutorMessages:[]}}),resetToNewUser:()=>e(()=>{const t={id:"L-NEW-"+Date.now().toString(36),name:"新同学",avatar:"新",major:"尚未填写",grade:"尚未填写",goal:"尚未填写",enrolledAt:new Date().toISOString().slice(0,10)},r=ke([]);return F("eduverse-onboarded",!1),F("eduverse-learner",t),F("eduverse-profile",V),F("eduverse-profile-history",[V]),F("eduverse-learning-records",[]),F("eduverse-practice-records",[]),F("eduverse-user-questions",[]),F("eduverse-study-plans",[r]),F("eduverse-current-plan-id",r.id),{onboarded:!1,learner:t,currentProfile:V,profileHistory:[V],profileMessages:[],learningRecords:[],practiceRecords:[],userQuestions:[],studyPlans:[r],currentPlanId:r.id,tutorMessages:[]}}),currentProfile:In,profileHistory:Ln,updateProfile:t=>e(r=>{const n=[...r.profileHistory,t];return F("eduverse-profile",t),F("eduverse-profile-history",n),{currentProfile:t,profileHistory:n}}),regenerateProfile:(t,r)=>{const n=o(),i=n.currentProfile,a=new Date,c=a.getFullYear()+"-"+String(a.getMonth()+1).padStart(2,"0")+"-"+String(a.getDate()).padStart(2,"0")+" "+String(a.getHours()).padStart(2,"0")+":"+String(a.getMinutes()).padStart(2,"0"),l=(r||t||"").toLowerCase(),{dimensionDeltas:p,dimensionEvidences:u}=ot(l),m={id:"PV-"+Date.now().toString(36),version:i.version+1,createdAt:c,trigger:t,dimensions:i.dimensions.map(x=>{const f=p[x.name]||0,D=Math.min(98,Math.max(25,x.score+f)),b=u[x.name]||x.evidence;return{...x,score:D,evidence:b}})},w=[...n.profileHistory,m];F("eduverse-profile",m),F("eduverse-profile-history",w),e({currentProfile:m,profileHistory:w});const A=i.dimensions.map(x=>{const f=m.dimensions.find(b=>b.name===x.name),D=((f==null?void 0:f.score)||0)-x.score;return{name:x.name,oldScore:x.score,newScore:(f==null?void 0:f.score)||x.score,delta:D}}).sort((x,f)=>Math.abs(f.delta)-Math.abs(x.delta));return{profile:m,changes:A}},predictProfileChanges:t=>{const n=o().currentProfile,i=t.toLowerCase(),{dimensionDeltas:a}=ot(i);return n.dimensions.map(c=>{const l=a[c.name]||0,p=Math.min(98,Math.max(25,c.score+l));return{name:c.name,oldScore:c.score,newScore:p,delta:l}}).sort((c,l)=>Math.abs(l.delta)-Math.abs(c.delta))},buildInitialProfileFromOnboarding:(t,r)=>{const n=o(),i=n.currentProfile,a=new Date,c=a.getFullYear()+"-"+String(a.getMonth()+1).padStart(2,"0")+"-"+String(a.getDate()).padStart(2,"0")+" "+String(a.getHours()).padStart(2,"0")+":"+String(a.getMinutes()).padStart(2,"0"),l=r==null?void 0:r.username,p=(r==null?void 0:r.mathCorrect)??0,u=(r==null?void 0:r.mathTotal)??0,m=u>0?p/u:0;if(l&&l.trim()){const b={...n.learner,name:l.trim(),avatar:l.trim().charAt(0).toUpperCase()};F("eduverse-learner",b);const _=[...N("eduverse-custom-learners",[]).filter(d=>d.id!==b.id),b];F("eduverse-custom-learners",_),e({learner:b,presetLearners:[...te,..._.filter(d=>!te.some(B=>B.id===d.id))]})}const w={};for(const b of t)b.startsWith("年级：")?w.目标导向=`年级 ${b.slice(3)}；${n.learner.goal}`:b.startsWith("目标：")?w.目标导向=`目标：${b.slice(3)}`:b.startsWith("基础自评：")?w.知识基础=`自评分数：${b.slice(5)}`:b.startsWith("认知风格：")?w.认知风格=`偏好：${b.slice(5)}`:b.startsWith("易错点：")?w.易错偏好=`易错点：${b.slice(4)}`:b.startsWith("学习节奏：")&&(w.学习节奏=`节奏：${b.slice(5)}`);const A=Math.round(35+m*50);u>0&&(m>=.8?w.易错偏好=`数学测试 ${p}/${u}，基础扎实，不易在数学推导上出错`:m>=.5?w.易错偏好=`数学测试 ${p}/${u}，中等水平，需注意公式推导细节`:w.易错偏好=`数学测试 ${p}/${u}，数学基础薄弱，易在推导和计算上出错`,w.知识基础=`数学测试正确率 ${Math.round(m*100)}%，基础分数 ${A}`);const x=A-50,f={id:"PV-"+Date.now().toString(36),version:1,createdAt:c,trigger:l?`首次对话引导构建（用户：${l}）`:"首次对话引导构建",dimensions:i.dimensions.map(b=>{let v=b.score,_=Math.floor(Math.random()*7)-3;b.name==="知识基础"&&u>0?(v=A,_=0):b.name==="知识基础"&&(_+=x),b.name==="易错偏好"&&u>0&&(m<.5?_-=5:m>=.8&&(_+=5));const d=Math.min(95,Math.max(30,v+_));return{...b,score:d,evidence:w[b.name]||b.evidence}})},D=[f];return F("eduverse-profile",f),F("eduverse-profile-history",D),e({currentProfile:f,profileHistory:D}),f},resources:Lt,likedResource:t=>e(r=>({resources:r.resources.map(n=>n.id===t?{...n,liked:!n.liked}:n)})),tutorMessages:[],addTutorMessage:t=>e(r=>({tutorMessages:[...r.tutorMessages,t]})),updateLastTutorMessage:t=>e(r=>{const n=[...r.tutorMessages],i=n[n.length-1];return i&&i.role==="agent"&&(n[n.length-1]={...i,content:t}),{tutorMessages:n}}),profileMessages:[],addProfileMessage:t=>e(r=>({profileMessages:[...r.profileMessages,t]})),updateLastProfileMessage:t=>e(r=>{const n=[...r.profileMessages],i=n[n.length-1];return i&&i.role==="agent"&&(n[n.length-1]={...i,content:t}),{profileMessages:n}}),learningRecords:Rt,markAsLearned:t=>e(r=>{const n=new Date().toISOString().slice(0,10),a=r.learningRecords.find(c=>c.knowledgeId===t)?r.learningRecords.map(c=>c.knowledgeId===t?{...c,learned:!0,lastVisit:n}:c):[...r.learningRecords,{knowledgeId:t,mastery:0,timeSpent:0,lastVisit:n,exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!0,quizCompleted:!1}];return F("eduverse-learning-records",a),{learningRecords:a}}),completeQuiz:(t,r)=>e(n=>{const i=new Date().toISOString().slice(0,10),c=n.learningRecords.find(l=>l.knowledgeId===t)?n.learningRecords.map(l=>l.knowledgeId===t?{...l,quizAttempts:l.quizAttempts+1,quizScore:Math.max(l.quizScore,r.score),quizCompleted:!0,mastery:r.score,exercisesCorrect:l.exercisesCorrect+r.correctCount,exercisesTotal:l.exercisesTotal+r.totalQuestions,lastVisit:i}:l):[...n.learningRecords,{knowledgeId:t,mastery:r.score,timeSpent:0,lastVisit:i,exercisesCorrect:r.correctCount,exercisesTotal:r.totalQuestions,completedResources:[],quizAttempts:1,quizScore:r.score,learned:!1,quizCompleted:!0}];return F("eduverse-learning-records",c),{learningRecords:c}}),getRecordById:t=>o().learningRecords.find(r=>r.knowledgeId===t),practiceRecords:zn,addPracticeRecord:t=>e(r=>{const n=new Date().toISOString().slice(0,10),i=t.totalQuestions>0?Math.round(t.correctCount/t.totalQuestions*100):0,a={...t,date:n,accuracy:i},c=[...r.practiceRecords,a];F("eduverse-practice-records",c);const l=new Set(t.knowledgeIds),p=r.learningRecords.map(u=>{if(l.has(u.knowledgeId)){const m=Math.min(100,u.mastery+Math.max(1,Math.floor(i/20)));return{...u,mastery:m,lastVisit:n}}return u});return F("eduverse-learning-records",p),{practiceRecords:c,learningRecords:p}}),getPracticeByDate:t=>o().practiceRecords.filter(r=>r.date===t),getTotalPracticeStats:()=>{const t=o().practiceRecords,r=t.reduce((a,c)=>a+c.totalQuestions,0),n=t.reduce((a,c)=>a+c.correctCount,0),i=new Set(t.map(a=>a.date)).size;return{totalQuestions:r,correctCount:n,accuracy:r>0?Math.round(n/r*100):0,days:i}},studyPlans:Ie,currentPlanId:Pt,createStudyPlan:t=>{const r=jt(t,o().learningRecords);return e(n=>{const i=[...n.studyPlans,r];return F("eduverse-study-plans",i),F("eduverse-current-plan-id",r.id),{studyPlans:i,currentPlanId:r.id}}),r},setCurrentPlan:t=>{F("eduverse-current-plan-id",t),e({currentPlanId:t})},completeStudyPlanTask:(t,r)=>e(n=>{let i=0,a=!1;const c=n.studyPlans.map(m=>{if(m.id!==t)return m;const w=m.milestones.map(x=>({...x,tasks:x.tasks.map(f=>!a&&f.day===r.day&&f.knowledgeId===r.knowledgeId&&f.type===r.type?(a=!0,f.completed||(i=f.estimatedMinutes),{...f,completed:!0}):f)})),A=w.every(x=>x.tasks.every(f=>f.completed));return{...m,milestones:w,status:A?"completed":m.status}});if(!a)return{};const l=new Date().toISOString().slice(0,10),u=n.learningRecords.find(m=>m.knowledgeId===r.knowledgeId)?n.learningRecords.map(m=>m.knowledgeId===r.knowledgeId?{...m,learned:!0,timeSpent:m.timeSpent+i,lastVisit:l}:m):[...n.learningRecords,{knowledgeId:r.knowledgeId,mastery:0,timeSpent:i,lastVisit:l,exercisesCorrect:0,exercisesTotal:0,completedResources:[],quizAttempts:0,quizScore:0,learned:!0,quizCompleted:!1}];return F("eduverse-study-plans",c),F("eduverse-learning-records",u),{studyPlans:c,learningRecords:u}}),userQuestions:Cn,addUserQuestion:t=>e(r=>{const n=new Date,i=n.getFullYear()+"-"+String(n.getMonth()+1).padStart(2,"0")+"-"+String(n.getDate()).padStart(2,"0")+" "+String(n.getHours()).padStart(2,"0")+":"+String(n.getMinutes()).padStart(2,"0"),c=[{...t,id:"uq-"+Date.now().toString(36),author:r.learner.name,authorAvatar:r.learner.avatar,createdAt:i,likes:0,comments:[]},...r.userQuestions];return F("eduverse-user-questions",c),{userQuestions:c}}),likeUserQuestion:t=>e(r=>{const n=r.userQuestions.map(i=>i.id===t?{...i,likedByMe:!i.likedByMe,likes:i.likedByMe?i.likes-1:i.likes+1}:i);return F("eduverse-user-questions",n),{userQuestions:n}}),addQuestionComment:(t,r)=>e(n=>{const i=new Date,a=i.getFullYear()+"-"+String(i.getMonth()+1).padStart(2,"0")+"-"+String(i.getDate()).padStart(2,"0")+" "+String(i.getHours()).padStart(2,"0")+":"+String(i.getMinutes()).padStart(2,"0"),c={id:"cmt-"+Date.now().toString(36),author:n.learner.name,authorAvatar:n.learner.avatar,content:r,createdAt:a},l=n.userQuestions.map(p=>p.id===t?{...p,comments:[...p.comments,c]}:p);return F("eduverse-user-questions",l),{userQuestions:l}}),workshopLog:[],workshopStreaming:"",workshopBusy:!1,workshopResourceType:null,workshopGenerated:null,setWorkshop:t=>e(t),pushWorkshopLog:t=>e(r=>({workshopLog:[...r.workshopLog,t]})),appendWorkshopStream:t=>e(r=>({workshopStreaming:r.workshopStreaming+t})),resetWorkshop:()=>e({workshopLog:[],workshopStreaming:"",workshopBusy:!1,workshopResourceType:null,workshopGenerated:null})})),Le=[{to:"/",label:"工作台",description:"学习概览与快捷入口",icon:kr},{to:"/showcase",label:"决赛演示",description:"3 分钟验证学习闭环",icon:Ur},{to:"/profile",label:"学习画像",description:"查看与更新六维画像",icon:hr},{to:"/plan",label:"学习计划",description:"制定并跟踪阶段目标",icon:pr},{to:"/workshop",label:"资源工坊",description:"生成六类多模态资源",icon:wr},{to:"/path",label:"学习路径",description:"探索个性化知识图谱",icon:Hr},{to:"/practice",label:"题库训练",description:"专项练习与社区共创",icon:Rr},{to:"/tutor",label:"智能辅导",description:"获得上下文感知答疑",icon:qr},{to:"/assessment",label:"学习评估",description:"诊断掌握度与薄弱点",icon:Dr},{to:"/library",label:"资源中心",description:"检索全部学习资源",icon:$r}],jn=Object.fromEntries(Le.map(e=>[e.to,e.label]));function it({mobile:e=!1,onNavigate:o}){const t=K(n=>n.learner),r=K(n=>n.setOnboarded);return s.jsxs("aside",{"trae-inspector-start-line":"20","trae-inspector-start-column":"4","trae-inspector-end-line":"133","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D","aria-label":"主导航",className:Z("w-[260px] shrink-0 flex-col border-r border-[var(--card-border)] bg-[var(--card)] backdrop-blur-xl",e?"flex h-full w-[min(86vw,320px)] shadow-2xl":"hidden lg:flex"),children:[s.jsxs("div",{"trae-inspector-start-line":"28","trae-inspector-start-column":"6","trae-inspector-end-line":"47","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center gap-3 border-b border-[var(--card-border)] px-5 py-4",children:[s.jsxs("div",{"trae-inspector-start-line":"29","trae-inspector-start-column":"8","trae-inspector-end-line":"32","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-vermilion-500 via-aurum-500 to-azure-500",children:[s.jsx(dt,{className:"h-5 w-5 text-white"}),s.jsx("div",{"trae-inspector-start-line":"31","trae-inspector-start-column":"10","trae-inspector-end-line":"31","trae-inspector-end-column":"142","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"absolute inset-0 animate-breathe rounded-xl bg-gradient-to-br from-vermilion-500 to-azure-500 opacity-40 blur-md"})]}),s.jsxs("div",{"trae-inspector-start-line":"33","trae-inspector-start-column":"8","trae-inspector-end-line":"36","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",children:[s.jsx("div",{"trae-inspector-start-line":"34","trae-inspector-start-column":"10","trae-inspector-end-line":"34","trae-inspector-end-column":"80","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%99%BA%E5%AD%A6%E7%81%B5%E5%A2%83%22%2C%22textStartLine%22%3A%2234%22%2C%22textStartColumn%22%3A%2270%22%2C%22textEndLine%22%3A%2234%22%2C%22textEndColumn%22%3A%2274%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"font-serif text-lg font-bold text-gradient",children:"智学灵境"}),s.jsx("div",{"trae-inspector-start-line":"35","trae-inspector-start-column":"10","trae-inspector-end-line":"35","trae-inspector-end-column":"92","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22EDUVERSE%22%2C%22textStartLine%22%3A%2235%22%2C%22textStartColumn%22%3A%2278%22%2C%22textEndLine%22%3A%2235%22%2C%22textEndColumn%22%3A%2286%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-[10px] tracking-widest text-[var(--fg-muted)]",children:"EDUVERSE"})]}),e&&s.jsx("button",{"trae-inspector-start-line":"38","trae-inspector-start-column":"10","trae-inspector-end-line":"45","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:o,className:"ml-auto rounded-full p-2 text-[var(--fg-muted)] hover:bg-[var(--card)] hover:text-[var(--fg)]","aria-label":"关闭菜单",children:s.jsx(_e,{className:"h-5 w-5"})})]}),s.jsx("nav",{"trae-inspector-start-line":"50","trae-inspector-start-column":"6","trae-inspector-end-line":"85","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex flex-col gap-1 px-3 py-4",children:Le.map(n=>{const i=n.icon;return s.jsx(Ot,{to:n.to,end:n.to==="/",onClick:o,className:({isActive:a})=>Z("group flex items-center gap-3 rounded-card px-3 py-2.5 text-sm transition-all",a?"bg-gradient-to-r from-vermilion-500/15 to-azure-500/10 text-[var(--fg)] shadow-glow":"text-[var(--fg-muted)] hover:bg-[var(--card)] hover:text-[var(--fg)]"),children:({isActive:a})=>s.jsxs(s.Fragment,{children:[s.jsx(i,{className:Z("h-4 w-4 transition-transform group-hover:scale-110",a&&"text-vermilion-500")}),s.jsx("span",{"trae-inspector-start-line":"76","trae-inspector-start-column":"18","trae-inspector-end-line":"76","trae-inspector-end-column":"67","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"font-medium",children:n.label}),a&&s.jsx("span",{"trae-inspector-start-line":"78","trae-inspector-start-column":"20","trae-inspector-end-line":"78","trae-inspector-end-column":"90","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"ml-auto h-1.5 w-1.5 rounded-full bg-vermilion-500"})]})},n.to)})}),s.jsxs("div",{"trae-inspector-start-line":"88","trae-inspector-start-column":"6","trae-inspector-end-line":"103","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-auto border-t border-[var(--card-border)] px-4 py-4",children:[s.jsxs("div",{"trae-inspector-start-line":"89","trae-inspector-start-column":"8","trae-inspector-end-line":"94","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mb-3 flex items-center justify-between",children:[s.jsx("span",{"trae-inspector-start-line":"90","trae-inspector-start-column":"10","trae-inspector-end-line":"90","trae-inspector-end-column":"83","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%99%BA%E8%83%BD%E4%BD%93%E7%BC%96%E9%98%9F%22%2C%22textStartLine%22%3A%2290%22%2C%22textStartColumn%22%3A%2271%22%2C%22textEndLine%22%3A%2290%22%2C%22textEndColumn%22%3A%2276%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-xs font-medium text-[var(--fg-muted)]",children:"智能体编队"}),s.jsx("span",{"trae-inspector-start-line":"91","trae-inspector-start-column":"10","trae-inspector-end-line":"93","trae-inspector-end-column":"17","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%227%20%E5%9C%A8%E7%BA%BF%22%2C%22textStartLine%22%3A%2291%22%2C%22textStartColumn%22%3A%2296%22%2C%22textEndLine%22%3A%2293%22%2C%22textEndColumn%22%3A%2210%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"rounded-chip bg-jade-500/15 px-1.5 py-0.5 text-[10px] text-jade-400",children:"7 在线"})]}),s.jsx("div",{"trae-inspector-start-line":"95","trae-inspector-start-column":"8","trae-inspector-end-line":"102","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"grid grid-cols-4 gap-2",children:Se.map(n=>s.jsxs("div",{"trae-inspector-start-line":"97","trae-inspector-start-column":"12","trae-inspector-end-line":"100","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex flex-col items-center gap-1",children:[s.jsx(Jo,{agent:n,size:"sm",pulse:n.id==="captain"}),s.jsx("span",{"trae-inspector-start-line":"99","trae-inspector-start-column":"14","trae-inspector-end-line":"99","trae-inspector-end-column":"82","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-[10px] text-[var(--fg-muted)]",children:n.name})]},n.id))})]}),s.jsx("div",{"trae-inspector-start-line":"106","trae-inspector-start-column":"6","trae-inspector-end-line":"132","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"border-t border-[var(--card-border)] px-4 py-3",children:s.jsxs("div",{"trae-inspector-start-line":"107","trae-inspector-start-column":"8","trae-inspector-end-line":"131","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center gap-3",children:[s.jsx("div",{"trae-inspector-start-line":"108","trae-inspector-start-column":"10","trae-inspector-end-line":"110","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-azure-500 to-amethyst-500 font-serif font-bold text-white",children:t.avatar}),s.jsxs("div",{"trae-inspector-start-line":"111","trae-inspector-start-column":"10","trae-inspector-end-line":"118","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"min-w-0 flex-1",children:[s.jsx("div",{"trae-inspector-start-line":"112","trae-inspector-start-column":"12","trae-inspector-end-line":"114","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"truncate text-sm font-medium text-[var(--fg)]",children:t.name}),s.jsx("div",{"trae-inspector-start-line":"115","trae-inspector-start-column":"12","trae-inspector-end-line":"117","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"truncate text-[10px] text-[var(--fg-muted)]",children:t.grade})]}),s.jsx("button",{"trae-inspector-start-line":"119","trae-inspector-start-column":"10","trae-inspector-end-line":"130","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/layout/Sidebar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>{r(!1),o==null||o()},title:"切换身份 / 重新构建画像","aria-label":"切换身份或重新构建画像",className:"flex h-7 w-7 items-center justify-center rounded-full text-[var(--fg-muted)] transition-colors hover:bg-ink-700/50 hover:text-[var(--fg)]",children:s.jsx(Wr,{className:"h-3.5 w-3.5"})})]})})]})}const Nn=[{title:"今日学习计划待完成",detail:"还有 3 个任务，预计 45 分钟",to:"/plan",color:"text-aurum-400"},{title:"画像已更新至最新版本",detail:"兴趣方向与目标导向有所提升",to:"/profile",color:"text-azure-400"},{title:"薄弱点诊断已生成",detail:"建议优先复习启发式搜索",to:"/assessment",color:"text-vermilion-400"}];function Tn({onMenuClick:e,menuOpen:o=!1}){const t=K(d=>d.theme),r=K(d=>d.toggleTheme),n=K(d=>d.resources),i=$e(),a=lt(),[c,l]=$.useState(!1),[p,u]=$.useState(!1),[m,w]=$.useState(""),A=$.useRef(null),x=jn[i.pathname]||"智学灵境";$.useEffect(()=>{const d=B=>{(B.metaKey||B.ctrlKey)&&B.key.toLowerCase()==="k"&&(B.preventDefault(),l(!0),u(!1)),B.key==="Escape"&&(l(!1),u(!1))};return window.addEventListener("keydown",d),()=>window.removeEventListener("keydown",d)},[]),$.useEffect(()=>{if(!c)return;const d=requestAnimationFrame(()=>{var B;return(B=A.current)==null?void 0:B.focus()});return()=>cancelAnimationFrame(d)},[c]);const f=$.useMemo(()=>[...Le.map(d=>({id:`page-${d.to}`,title:d.label,description:d.description,group:"页面",to:d.to})),...W.map(d=>({id:`knowledge-${d.id}`,title:d.title,description:`第 ${d.chapter} 章 · ${d.summary}`,group:"知识点",to:`/assessment?knowledge=${encodeURIComponent(d.id)}`})),...n.map(d=>({id:`resource-${d.id}`,title:d.title,description:d.excerpt,group:"资源",to:`/library?resource=${encodeURIComponent(d.id)}`})),...Se.map(d=>({id:`agent-${d.id}`,title:d.name,description:`${d.role} · ${d.desc}`,group:"智能体",to:"/workshop"}))],[n]),D=$.useMemo(()=>{const d=m.trim().toLocaleLowerCase("zh-CN");return(d?f.filter(C=>`${C.title} ${C.description} ${C.group}`.toLocaleLowerCase("zh-CN").includes(d)):f.filter(C=>C.group==="页面")).slice(0,d?10:6)},[m,f]),b=()=>{l(!0),u(!1)},v=d=>{a(d.to),l(!1),w("")},_=d=>d==="知识点"?ar:d==="资源"?Er:d==="智能体"?cr:me;return s.jsxs(s.Fragment,{children:[s.jsxs("header",{"trae-inspector-start-line":"135","trae-inspector-start-column":"6","trae-inspector-end-line":"226","trae-inspector-end-column":"15","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-[var(--card-border)] bg-[var(--card)] px-3 backdrop-blur-xl sm:px-4 lg:px-6",children:[s.jsx("button",{"trae-inspector-start-line":"136","trae-inspector-start-column":"8","trae-inspector-end-line":"145","trae-inspector-end-column":"17","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:e,className:"rounded-lg p-2 text-[var(--fg-muted)] hover:bg-[var(--card)] hover:text-[var(--fg)] lg:hidden","aria-label":o?"关闭菜单":"打开菜单","aria-expanded":o,"aria-controls":"mobile-navigation",children:s.jsx(Sr,{className:"h-5 w-5"})}),s.jsxs("nav",{"trae-inspector-start-line":"147","trae-inspector-start-column":"8","trae-inspector-end-line":"151","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex min-w-0 items-center gap-1.5 text-sm","aria-label":"面包屑",children:[s.jsx(Wt,{to:"/",className:"hidden text-[var(--fg-muted)] hover:text-[var(--fg)] sm:inline",children:"智学灵境"}),s.jsx(me,{className:"hidden h-3.5 w-3.5 text-[var(--fg-muted)]/50 sm:block"}),s.jsx("span",{"trae-inspector-start-line":"150","trae-inspector-start-column":"10","trae-inspector-end-line":"150","trae-inspector-end-column":"96","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"truncate font-serif font-semibold text-[var(--fg)]",children:x})]}),s.jsxs("div",{"trae-inspector-start-line":"153","trae-inspector-start-column":"8","trae-inspector-end-line":"225","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"ml-auto flex items-center gap-1 sm:gap-2",children:[s.jsxs("button",{"trae-inspector-start-line":"154","trae-inspector-start-column":"10","trae-inspector-end-line":"163","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:b,className:"group hidden h-9 w-64 items-center rounded-full border border-[var(--card-border)] bg-[var(--surface-input)] px-3 text-left text-sm text-[var(--fg-muted)] transition-colors hover:border-azure-500/60 md:flex","aria-label":"打开全局搜索",children:[s.jsx(ce,{className:"mr-2 h-4 w-4"}),s.jsx("span",{"trae-inspector-start-line":"161","trae-inspector-start-column":"12","trae-inspector-end-line":"161","trae-inspector-end-column":"63","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E6%90%9C%E7%B4%A2%E7%9F%A5%E8%AF%86%E7%82%B9%20%2F%20%E8%B5%84%E6%BA%90%20%2F%20%E6%99%BA%E8%83%BD%E4%BD%93%E2%80%A6%22%2C%22textStartLine%22%3A%22161%22%2C%22textStartColumn%22%3A%2239%22%2C%22textEndLine%22%3A%22161%22%2C%22textEndColumn%22%3A%2256%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"truncate",children:"搜索知识点 / 资源 / 智能体…"}),s.jsx("kbd",{"trae-inspector-start-line":"162","trae-inspector-start-column":"12","trae-inspector-end-line":"162","trae-inspector-end-column":"96","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E2%8C%98K%22%2C%22textStartLine%22%3A%22162%22%2C%22textStartColumn%22%3A%2288%22%2C%22textEndLine%22%3A%22162%22%2C%22textEndColumn%22%3A%2290%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"ml-auto rounded bg-[var(--card)] px-1.5 py-0.5 text-[10px]",children:"⌘K"})]}),s.jsx("button",{"trae-inspector-start-line":"164","trae-inspector-start-column":"10","trae-inspector-end-line":"166","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:b,className:"rounded-full p-2 hover:bg-[var(--card)] md:hidden","aria-label":"搜索",children:s.jsx(ce,{className:"h-5 w-5"})}),s.jsx("button",{"trae-inspector-start-line":"168","trae-inspector-start-column":"10","trae-inspector-end-line":"170","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:r,className:"rounded-full p-2 hover:bg-[var(--card)]","aria-label":`切换为${t==="dark"?"浅色":"深色"}主题`,children:t==="dark"?s.jsx(Zr,{className:"h-5 w-5 text-aurum-400"}):s.jsx(Nr,{className:"h-5 w-5 text-amethyst-500"})}),s.jsxs("div",{"trae-inspector-start-line":"172","trae-inspector-start-column":"10","trae-inspector-end-line":"220","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"relative",children:[s.jsxs("button",{"trae-inspector-start-line":"173","trae-inspector-start-column":"12","trae-inspector-end-line":"185","trae-inspector-end-column":"21","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>{u(d=>!d),l(!1)},className:"relative rounded-full p-2 hover:bg-[var(--card)]","aria-label":"查看通知","aria-expanded":p,children:[s.jsx(sr,{className:"h-5 w-5"}),s.jsx("span",{"trae-inspector-start-line":"184","trae-inspector-start-column":"14","trae-inspector-end-line":"184","trae-inspector-end-column":"123","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-vermilion-500 ring-2 ring-[var(--bg)]"})]}),p&&s.jsxs("div",{"trae-inspector-start-line":"187","trae-inspector-start-column":"14","trae-inspector-end-line":"218","trae-inspector-end-column":"20","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"absolute right-0 top-12 z-50 w-[min(22rem,calc(100vw-1rem))] overflow-hidden rounded-card border border-[var(--card-border)] bg-[var(--surface-popover)] shadow-float backdrop-blur-2xl",children:[s.jsxs("div",{"trae-inspector-start-line":"188","trae-inspector-start-column":"16","trae-inspector-end-line":"196","trae-inspector-end-column":"22","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center justify-between border-b border-[var(--card-border)] px-4 py-3",children:[s.jsxs("div",{"trae-inspector-start-line":"189","trae-inspector-start-column":"18","trae-inspector-end-line":"192","trae-inspector-end-column":"24","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",children:[s.jsx("div",{"trae-inspector-start-line":"190","trae-inspector-start-column":"20","trae-inspector-end-line":"190","trae-inspector-end-column":"80","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E5%AD%A6%E4%B9%A0%E5%8A%A8%E6%80%81%22%2C%22textStartLine%22%3A%22190%22%2C%22textStartColumn%22%3A%2270%22%2C%22textEndLine%22%3A%22190%22%2C%22textEndColumn%22%3A%2274%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"font-serif text-sm font-semibold",children:"学习动态"}),s.jsx("div",{"trae-inspector-start-line":"191","trae-inspector-start-column":"20","trae-inspector-end-line":"191","trae-inspector-end-column":"86","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%223%20%E6%9D%A1%E5%BE%85%E5%A4%84%E7%90%86%E6%8F%90%E9%86%92%22%2C%22textStartLine%22%3A%22191%22%2C%22textStartColumn%22%3A%2272%22%2C%22textEndLine%22%3A%22191%22%2C%22textEndColumn%22%3A%2280%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-[10px] text-[var(--fg-muted)]",children:"3 条待处理提醒"})]}),s.jsx("button",{"trae-inspector-start-line":"193","trae-inspector-start-column":"18","trae-inspector-end-line":"195","trae-inspector-end-column":"27","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>u(!1),className:"rounded-full p-1 text-[var(--fg-muted)] hover:bg-[var(--card)]","aria-label":"关闭通知",children:s.jsx(_e,{className:"h-4 w-4"})})]}),s.jsx("div",{"trae-inspector-start-line":"197","trae-inspector-start-column":"16","trae-inspector-end-line":"217","trae-inspector-end-column":"22","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"p-2",children:Nn.map((d,B)=>s.jsxs("button",{"trae-inspector-start-line":"199","trae-inspector-start-column":"20","trae-inspector-end-line":"215","trae-inspector-end-column":"29","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>{a(d.to),u(!1)},className:"flex w-full gap-3 rounded-xl p-3 text-left hover:bg-[var(--card)]",children:[s.jsx("span",{"trae-inspector-start-line":"208","trae-inspector-start-column":"22","trae-inspector-end-line":"210","trae-inspector-end-column":"29","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:Z("mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--card)]",d.color),children:B===0?s.jsx(gr,{className:"h-4 w-4"}):s.jsx(fr,{className:"h-4 w-4"})}),s.jsxs("span",{"trae-inspector-start-line":"211","trae-inspector-start-column":"22","trae-inspector-end-line":"214","trae-inspector-end-column":"29","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"min-w-0",children:[s.jsx("span",{"trae-inspector-start-line":"212","trae-inspector-start-column":"24","trae-inspector-end-line":"212","trae-inspector-end-column":"104","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"block text-xs font-medium text-[var(--fg)]",children:d.title}),s.jsx("span",{"trae-inspector-start-line":"213","trae-inspector-start-column":"24","trae-inspector-end-line":"213","trae-inspector-end-column":"126","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-0.5 block text-[10px] leading-relaxed text-[var(--fg-muted)]",children:d.detail})]})]},d.title))})]})]}),s.jsxs("div",{"trae-inspector-start-line":"222","trae-inspector-start-column":"10","trae-inspector-end-line":"224","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"hidden items-center gap-1.5 rounded-full border border-jade-500/30 bg-jade-500/10 px-2.5 py-1 text-xs text-jade-400 sm:flex",children:[s.jsx("span",{"trae-inspector-start-line":"223","trae-inspector-start-column":"12","trae-inspector-end-line":"223","trae-inspector-end-column":"83","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"h-1.5 w-1.5 animate-pulse rounded-full bg-jade-400"}),"编队在线"]})]})]}),c&&s.jsx("div",{"trae-inspector-start-line":"229","trae-inspector-start-column":"8","trae-inspector-end-line":"268","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"fixed inset-0 z-[70] flex items-start justify-center bg-ink-950/75 px-3 pt-[10vh] backdrop-blur-md",role:"dialog","aria-modal":"true","aria-label":"全局搜索",onMouseDown:d=>d.target===d.currentTarget&&l(!1),children:s.jsxs("div",{"trae-inspector-start-line":"230","trae-inspector-start-column":"10","trae-inspector-end-line":"267","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"w-full max-w-2xl overflow-hidden rounded-2xl border border-[var(--card-border)] bg-[var(--surface-popover)] shadow-2xl",children:[s.jsxs("div",{"trae-inspector-start-line":"231","trae-inspector-start-column":"12","trae-inspector-end-line":"245","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center gap-3 border-b border-[var(--card-border)] px-4",children:[s.jsx(ce,{className:"h-5 w-5 shrink-0 text-azure-400"}),s.jsx("input",{"trae-inspector-start-line":"233","trae-inspector-start-column":"14","trae-inspector-end-line":"243","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",ref:A,value:m,onChange:d=>w(d.target.value),onKeyDown:d=>{d.key==="Enter"&&D[0]&&v(D[0])},placeholder:"搜索页面、知识点、资源或智能体…",className:"h-14 flex-1 bg-transparent text-sm text-[var(--fg)] outline-none placeholder:text-[var(--fg-muted)]","aria-label":"搜索内容"}),s.jsx("button",{"trae-inspector-start-line":"244","trae-inspector-start-column":"14","trae-inspector-end-line":"244","trae-inspector-end-column":"229","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22ESC%22%2C%22textStartLine%22%3A%22244%22%2C%22textStartColumn%22%3A%22217%22%2C%22textEndLine%22%3A%22244%22%2C%22textEndColumn%22%3A%22220%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>l(!1),className:"rounded-lg border border-[var(--card-border)] px-2 py-1 text-[10px] text-[var(--fg-muted)] hover:text-[var(--fg)]","aria-label":"关闭搜索",children:"ESC"})]}),s.jsxs("div",{"trae-inspector-start-line":"246","trae-inspector-start-column":"12","trae-inspector-end-line":"265","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"max-h-[60vh] overflow-y-auto p-2",children:[s.jsx("div",{"trae-inspector-start-line":"247","trae-inspector-start-column":"14","trae-inspector-end-line":"249","trae-inspector-end-column":"20","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"px-3 pb-2 pt-1 text-[10px] font-medium tracking-[0.18em] text-[var(--fg-muted)]",children:m.trim()?`${D.length} 条匹配结果`:"快速导航"}),D.length>0?D.map(d=>{const B=_(d.group);return s.jsxs("button",{"trae-inspector-start-line":"253","trae-inspector-start-column":"18","trae-inspector-end-line":"260","trae-inspector-end-column":"27","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>v(d),className:"group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[var(--card)]",children:[s.jsx("span",{"trae-inspector-start-line":"254","trae-inspector-start-column":"20","trae-inspector-end-line":"254","trae-inspector-end-column":"207","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[var(--card-border)] bg-[var(--card)] text-azure-400",children:s.jsx(B,{className:"h-4 w-4"})}),s.jsxs("span",{"trae-inspector-start-line":"255","trae-inspector-start-column":"20","trae-inspector-end-line":"258","trae-inspector-end-column":"27","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"min-w-0 flex-1",children:[s.jsxs("span",{"trae-inspector-start-line":"256","trae-inspector-start-column":"22","trae-inspector-end-line":"256","trae-inspector-end-column":"271","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center gap-2",children:[s.jsx("span",{"trae-inspector-start-line":"256","trae-inspector-start-column":"64","trae-inspector-end-line":"256","trae-inspector-end-column":"149","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"truncate text-sm font-medium text-[var(--fg)]",children:d.title}),s.jsx("span",{"trae-inspector-start-line":"256","trae-inspector-start-column":"149","trae-inspector-end-line":"256","trae-inspector-end-column":"264","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"rounded-full bg-[var(--card)] px-2 py-0.5 text-[9px] text-[var(--fg-muted)]",children:d.group})]}),s.jsx("span",{"trae-inspector-start-line":"257","trae-inspector-start-column":"22","trae-inspector-end-line":"257","trae-inspector-end-column":"120","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-0.5 block truncate text-xs text-[var(--fg-muted)]",children:d.description})]}),s.jsx(me,{className:"h-4 w-4 text-[var(--fg-muted)] transition-transform group-hover:translate-x-0.5"})]},d.id)}):s.jsxs("div",{"trae-inspector-start-line":"263","trae-inspector-start-column":"16","trae-inspector-end-line":"263","trae-inspector-end-column":"270","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"px-4 py-12 text-center",children:[s.jsx(ce,{className:"mx-auto h-8 w-8 text-[var(--fg-muted)]/40"}),s.jsxs("p",{"trae-inspector-start-line":"263","trae-inspector-start-column":"120","trae-inspector-end-line":"263","trae-inspector-end-column":"188","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-3 text-sm text-[var(--fg-muted)]",children:["没有找到“",m,"”"]}),s.jsx("p",{"trae-inspector-start-line":"263","trae-inspector-start-column":"188","trae-inspector-end-line":"263","trae-inspector-end-column":"264","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E8%AF%95%E8%AF%95%E7%9F%A5%E8%AF%86%E7%82%B9%E5%90%8D%E7%A7%B0%E3%80%81%E8%B5%84%E6%BA%90%E7%B1%BB%E5%9E%8B%E6%88%96%E6%99%BA%E8%83%BD%E4%BD%93%E8%A7%92%E8%89%B2%22%2C%22textStartLine%22%3A%22263%22%2C%22textStartColumn%22%3A%22242%22%2C%22textEndLine%22%3A%22263%22%2C%22textEndColumn%22%3A%22260%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-1 text-xs text-[var(--fg-muted)]/70",children:"试试知识点名称、资源类型或智能体角色"})]})]}),s.jsxs("div",{"trae-inspector-start-line":"266","trae-inspector-start-column":"12","trae-inspector-end-line":"266","trae-inspector-end-column":"268","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-center gap-4 border-t border-[var(--card-border)] px-4 py-2 text-[10px] text-[var(--fg-muted)]",children:[s.jsx("span",{"trae-inspector-start-line":"266","trae-inspector-start-column":"135","trae-inspector-end-line":"266","trae-inspector-end-column":"154","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E2%86%B5%20%E6%89%93%E5%BC%80%E9%A6%96%E9%A1%B9%22%2C%22textStartLine%22%3A%22266%22%2C%22textStartColumn%22%3A%22141%22%2C%22textEndLine%22%3A%22266%22%2C%22textEndColumn%22%3A%22147%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",children:"↵ 打开首项"}),s.jsx("span",{"trae-inspector-start-line":"266","trae-inspector-start-column":"154","trae-inspector-end-line":"266","trae-inspector-end-column":"173","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22ESC%20%E5%85%B3%E9%97%AD%22%2C%22textStartLine%22%3A%22266%22%2C%22textStartColumn%22%3A%22160%22%2C%22textEndLine%22%3A%22266%22%2C%22textEndColumn%22%3A%22166%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",children:"ESC 关闭"}),s.jsxs("span",{"trae-inspector-start-line":"266","trae-inspector-start-column":"173","trae-inspector-end-line":"266","trae-inspector-end-column":"262","trae-inspector-file-path":"src/components/layout/Topbar.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"ml-auto",children:["覆盖 ",W.length," 个知识点 · ",n.length," 份资源"]})]})]})})]})}const Y=[{to:"/profile",label:"画像证据",time:"35 秒",action:"查看六维画像、版本与抽取依据"},{to:"/workshop",label:"编队生成",time:"55 秒",action:"选一个主题，现场观看多智能体协作"},{to:"/path",label:"路径解释",time:"30 秒",action:"点击 Transformer，查看个性化推荐理由"},{to:"/practice",label:"专项练习",time:"40 秒",action:"完成一道练习，查看解析与记录回流"},{to:"/assessment",label:"效果闭环",time:"20 秒",action:"查看掌握度、薄弱点和自适应建议"}];function Rn(){const e=$e(),o=lt(),[t,r]=$.useState(!1),n=new URLSearchParams(e.search).get("demo")==="1",i=Y.findIndex(l=>l.to===e.pathname);if(!n||i<0)return null;const a=Y[i],c=Y[i+1];return t?s.jsxs("button",{"trae-inspector-start-line":"27","trae-inspector-start-column":"6","trae-inspector-end-line":"36","trae-inspector-end-column":"15","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>r(!1),className:"fixed bottom-4 right-4 z-50 inline-flex items-center gap-2 rounded-full border border-aurum-500/35 bg-[var(--surface-popover)] px-4 py-2.5 text-xs font-semibold text-[var(--fg)] shadow-2xl backdrop-blur-xl","aria-label":"展开决赛演示向导",children:[s.jsx(He,{className:"h-4 w-4 text-aurum-400"}),"决赛演示 ",i+1,"/",Y.length,s.jsx(zr,{className:"h-3.5 w-3.5 text-[var(--fg-muted)]"})]}):s.jsxs("aside",{"trae-inspector-start-line":"41","trae-inspector-start-column":"4","trae-inspector-end-line":"84","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"fixed bottom-3 left-3 right-3 z-50 overflow-hidden rounded-2xl border border-aurum-500/35 bg-[var(--surface-popover)] shadow-2xl backdrop-blur-2xl sm:bottom-5 sm:left-auto sm:right-5 sm:w-[25rem]","aria-label":"决赛演示向导","aria-live":"polite",children:[s.jsx("div",{"trae-inspector-start-line":"46","trae-inspector-start-column":"6","trae-inspector-end-line":"51","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"h-1 bg-[var(--surface-input)]",children:s.jsx("div",{"trae-inspector-start-line":"47","trae-inspector-start-column":"8","trae-inspector-end-line":"50","trae-inspector-end-column":"10","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"h-full bg-gradient-to-r from-vermilion-500 via-aurum-500 to-azure-500 transition-[width] duration-500",style:{width:`${(i+1)/Y.length*100}%`}})}),s.jsxs("div",{"trae-inspector-start-line":"52","trae-inspector-start-column":"6","trae-inspector-end-line":"83","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"p-4",children:[s.jsxs("div",{"trae-inspector-start-line":"53","trae-inspector-start-column":"8","trae-inspector-end-line":"66","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex items-start gap-3",children:[s.jsx("span",{"trae-inspector-start-line":"54","trae-inspector-start-column":"10","trae-inspector-end-line":"56","trae-inspector-end-column":"17","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-aurum-500/10 text-aurum-400",children:s.jsx(He,{className:"h-[18px] w-[18px]"})}),s.jsxs("div",{"trae-inspector-start-line":"57","trae-inspector-start-column":"10","trae-inspector-end-line":"63","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"min-w-0 flex-1",children:[s.jsxs("div",{"trae-inspector-start-line":"58","trae-inspector-start-column":"12","trae-inspector-end-line":"61","trae-inspector-end-column":"18","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex flex-wrap items-center gap-x-2 gap-y-1",children:[s.jsxs("span",{"trae-inspector-start-line":"59","trae-inspector-start-column":"14","trae-inspector-end-line":"59","trae-inspector-end-column":"146","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-[10px] font-semibold tracking-[0.16em] text-aurum-400",children:["FINAL DEMO ",i+1,"/",Y.length]}),s.jsx("span",{"trae-inspector-start-line":"60","trae-inspector-start-column":"14","trae-inspector-end-line":"60","trae-inspector-end-column":"88","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"text-[10px] text-[var(--fg-muted)]",children:a.time})]}),s.jsx("h2",{"trae-inspector-start-line":"62","trae-inspector-start-column":"12","trae-inspector-end-line":"62","trae-inspector-end-column":"101","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-1 font-serif text-base font-bold text-[var(--fg)]",children:a.label})]}),s.jsx("button",{"trae-inspector-start-line":"64","trae-inspector-start-column":"10","trae-inspector-end-line":"64","trae-inspector-end-column":"231","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>r(!0),className:"rounded-lg p-1.5 text-[var(--fg-muted)] hover:bg-[var(--card)] hover:text-[var(--fg)]","aria-label":"收起演示向导",children:s.jsx(Lr,{className:"h-3.5 w-3.5"})}),s.jsx("button",{"trae-inspector-start-line":"65","trae-inspector-start-column":"10","trae-inspector-end-line":"65","trae-inspector-end-column":"226","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>o("/showcase"),className:"rounded-lg p-1.5 text-[var(--fg-muted)] hover:bg-[var(--card)] hover:text-[var(--fg)]","aria-label":"退出演示向导",children:s.jsx(_e,{className:"h-3.5 w-3.5"})})]}),s.jsx("p",{"trae-inspector-start-line":"67","trae-inspector-start-column":"8","trae-inspector-end-line":"67","trae-inspector-end-column":"89","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-3 text-xs leading-5 text-[var(--fg-muted)]",children:a.action}),s.jsxs("div",{"trae-inspector-start-line":"68","trae-inspector-start-column":"8","trae-inspector-end-line":"82","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"mt-4 flex items-center gap-3",children:[s.jsx("div",{"trae-inspector-start-line":"69","trae-inspector-start-column":"10","trae-inspector-end-line":"73","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex flex-1 items-center gap-1.5","aria-hidden":"true",children:Y.map((l,p)=>s.jsx("span",{"trae-inspector-start-line":"71","trae-inspector-start-column":"14","trae-inspector-end-line":"71","trae-inspector-end-column":"146","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:`h-1.5 flex-1 rounded-full ${p<=i?"bg-aurum-400":"bg-[var(--card-border)]"}`},l.to))}),s.jsxs("button",{"trae-inspector-start-line":"74","trae-inspector-start-column":"10","trae-inspector-end-line":"81","trae-inspector-end-column":"19","trae-inspector-file-path":"src/components/DemoGuide.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",onClick:()=>o(c?`${c.to}?demo=1`:"/showcase"),className:"inline-flex shrink-0 items-center gap-1 rounded-full bg-aurum-500 px-3.5 py-2 text-[11px] font-semibold text-ink-950 transition-colors hover:bg-aurum-400",children:[c?`下一步·${c.label}`:"完成演示",s.jsx(me,{className:"h-3.5 w-3.5"})]})]})]})]})}function Pn(){const e=K(i=>i.theme),[o,t]=$.useState(!1),r=$e(),n=$.useRef(null);return $.useEffect(()=>{document.documentElement.classList.remove("dark","light"),document.documentElement.classList.add(e)},[e]),$.useEffect(()=>{var i;(i=n.current)==null||i.scrollTo({top:0,behavior:"smooth"})},[r.pathname]),$.useEffect(()=>{if(!o)return;const i=a=>{a.key==="Escape"&&t(!1)};return window.addEventListener("keydown",i),()=>window.removeEventListener("keydown",i)},[o]),s.jsxs("div",{"trae-inspector-start-line":"34","trae-inspector-start-column":"4","trae-inspector-end-line":"60","trae-inspector-end-column":"10","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"app-shell-bg flex h-screen overflow-hidden",children:[s.jsx("a",{"trae-inspector-start-line":"35","trae-inspector-start-column":"6","trae-inspector-end-line":"35","trae-inspector-end-column":"62","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22text%22%3A%22%E8%B7%B3%E5%88%B0%E4%B8%BB%E8%A6%81%E5%86%85%E5%AE%B9%22%2C%22textStartLine%22%3A%2235%22%2C%22textStartColumn%22%3A%2252%22%2C%22textEndLine%22%3A%2235%22%2C%22textEndColumn%22%3A%2258%22%2C%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",href:"#main-content",className:"skip-link",children:"跳到主要内容"}),s.jsx(it,{}),s.jsxs("div",{"trae-inspector-start-line":"37","trae-inspector-start-column":"6","trae-inspector-end-line":"45","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"flex min-w-0 flex-1 flex-col",children:[s.jsx(Tn,{menuOpen:o,onMenuClick:()=>t(i=>!i)}),s.jsx("main",{"trae-inspector-start-line":"42","trae-inspector-start-column":"8","trae-inspector-end-line":"44","trae-inspector-end-column":"15","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",id:"main-content",ref:n,tabIndex:-1,className:"flex-1 overflow-y-auto",children:s.jsx(Kt,{})})]}),o&&s.jsxs("div",{"trae-inspector-start-line":"47","trae-inspector-start-column":"8","trae-inspector-end-line":"57","trae-inspector-end-column":"14","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",className:"fixed inset-0 z-50 lg:hidden",role:"dialog","aria-modal":"true","aria-label":"移动端导航",children:[s.jsx("button",{"trae-inspector-start-line":"48","trae-inspector-start-column":"10","trae-inspector-end-line":"53","trae-inspector-end-column":"12","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",type:"button",className:"absolute inset-0 bg-ink-950/75 backdrop-blur-sm",onClick:()=>t(!1),"aria-label":"关闭菜单"}),s.jsx("div",{"trae-inspector-start-line":"54","trae-inspector-start-column":"10","trae-inspector-end-line":"56","trae-inspector-end-column":"16","trae-inspector-file-path":"src/components/layout/AppShell.tsx","trae-inspector-static-props":"%7B%22cwd%22%3A%22%2FUsers%2Fyuchenxu%2FDesktop%2F%E8%BD%AF%E4%BB%B6%E6%9D%AF%E7%81%B5%E5%AD%A6%2Fstudy%22%7D",id:"mobile-navigation",className:"relative h-full w-fit animate-slide-in-left",children:s.jsx(it,{mobile:!0,onNavigate:()=>t(!1)})})]}),s.jsx(Rn,{})]})}const Un=$.lazy(()=>R(()=>import("./Home-BKe_GmN0.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]),import.meta.url)),Gn=$.lazy(()=>R(()=>import("./Profile-B-b5ZaHi.js"),__vite__mapDeps([20,1,3,21,22,23,24,25,26,27,14,28,29,30,31,11]),import.meta.url)),Vn=$.lazy(()=>R(()=>import("./Workshop-vvs7BA0t.js"),__vite__mapDeps([32,1,33,30,14,18,34,21,22,23,24,25,4,5,6,7,8,9,10,11,35,36,37,38,39,26,40,41]),import.meta.url)),On=$.lazy(()=>R(()=>import("./LearningPath-CBNhA7NT.js"),__vite__mapDeps([42,1,4,5,6,7,8,9,10,11,33,30,14,43,29,34,44]),import.meta.url)),Wn=$.lazy(()=>R(()=>import("./Tutor-BFTtv0v6.js"),__vite__mapDeps([45,1,21,22,23,24,25,39,26,43,30,14,31,34,28,6,5,11]),import.meta.url)),Kn=$.lazy(()=>R(()=>import("./Assessment-CaY2XjL6.js"),__vite__mapDeps([46,1,3,35,8,30,14,11,13,9,34,27,5,31,47]),import.meta.url)),Hn=$.lazy(()=>R(()=>import("./Library-w6HW78s3.js"),__vite__mapDeps([48,1,4,5,6,7,8,9,10,11,21,22,23,24,25,35,30,14,36,37,38]),import.meta.url)),Qn=$.lazy(()=>R(()=>import("./Practice-BbyZw0c4.js"),__vite__mapDeps([49,1,50,30,14,5,13,40,34,7,8,15,51,31,43,10,11]),import.meta.url)),Xn=$.lazy(()=>R(()=>import("./StudyPlan-GXf7h1TZ.js"),__vite__mapDeps([52,1,11,50,30,14,29,44,12,8,41,13,47,9]),import.meta.url)),Yn=$.lazy(()=>R(()=>import("./Showcase-CfgZYtfI.js"),__vite__mapDeps([53,1,14,11,8,16,17,7,18]),import.meta.url)),Zn=$.lazy(()=>R(()=>import("./Onboarding-6M5Z0snb.js"),__vite__mapDeps([54,1,2,26,11,14,16,50,30,31]),import.meta.url)),Jn=$.lazy(()=>R(()=>import("./NotFound-vhoahIfs.js"),__vite__mapDeps([55,1,19,11,51]),import.meta.url)),es=typeof window<"u"&&window.location.protocol==="file:"?Ht:Qt;function ts(){const e=K(t=>t.onboarded),o=K(t=>t.setOnboarded);return $.useEffect(()=>{const t=new URL(window.location.href);t.searchParams.get("reset")==="true"&&(o(!1),t.searchParams.delete("reset"),window.history.replaceState({},"",`${t.pathname}${t.search}${t.hash}`))},[o]),s.jsx(oo,{children:s.jsx(es,{children:s.jsxs($.Suspense,{fallback:s.jsx(no,{}),children:[s.jsx(Xt,{children:s.jsxs(T,{element:s.jsx(Pn,{}),children:[s.jsx(T,{path:"/",element:s.jsx(Un,{})}),s.jsx(T,{path:"/profile",element:s.jsx(Gn,{})}),s.jsx(T,{path:"/workshop",element:s.jsx(Vn,{})}),s.jsx(T,{path:"/path",element:s.jsx(On,{})}),s.jsx(T,{path:"/tutor",element:s.jsx(Wn,{})}),s.jsx(T,{path:"/assessment",element:s.jsx(Kn,{})}),s.jsx(T,{path:"/library",element:s.jsx(Hn,{})}),s.jsx(T,{path:"/practice",element:s.jsx(Qn,{})}),s.jsx(T,{path:"/plan",element:s.jsx(Xn,{})}),s.jsx(T,{path:"/showcase",element:s.jsx(Yn,{})}),s.jsx(T,{path:"*",element:s.jsx(Jn,{})})]})}),!e&&s.jsx(Zn,{})]})})})}Vt.createRoot(document.getElementById("root")).render(s.jsx($.StrictMode,{children:s.jsx(ts,{})}));export{Jo as A,ar as B,me as C,wr as F,Dr as G,$r as L,Ur as P,Hr as R,dt as S,He as T,_e as X,Se as a,fr as b,z as c,Z as d,Wr as e,ms as f,ss as g,Er as h,is as i,as as j,W as k,fs as l,ps as m,us as n,ls as o,Lt as p,ds as q,zt as r,eo as s,ce as t,K as u,xs as v,pr as w,cr as x,cs as y};
