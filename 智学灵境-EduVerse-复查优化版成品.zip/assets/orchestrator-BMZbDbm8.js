import{k as $,p,f as N,r as L,g as b,n as k}from"./index-Dlxtxeqp.js";import{a as u,s as y}from"./streaming-2LCi1Hf-.js";const w=["暴力","色情","赌博","毒品","自残"],x=new Set(["ai-intro","ai-history","ai-schools","ai-ethics","search-uninformed","search-informed","search-local","search-adversarial","kr-logic","kr-frame","kr-uncertain","kr-knowledge-graph","ml-overview","ml-linear","ml-tree","ml-eval","dl-fundamentals","dl-cnn","dl-rnn","dl-transformer","llm-pretrain","llm-rag","llm-agent","llm-multiagent"]);function A(s,r){const t=[];for(const o of w)s.includes(o)&&t.push(`敏感词命中: ${o}`);r&&!x.has(r)&&t.push("知识点不在白名单，需人工复核");const n=s.match(/```[\s\S]*?```/g)||[];for(const o of n){const l=o.replace(/^```\w*\n?/,"").replace(/```$/,"");l.includes("def ")&&!l.includes(":")&&t.push("代码块缺少冒号，疑似语法错误")}s.includes("论文")&&!s.includes("引用")&&t.push("缺少显式引用标注");const a=Math.max(0,100-t.length*18);return{passed:t.length===0,flags:t,score:a}}const S={"ai-intro":["人工智能","AI","强弱AI","定义","范畴"],"ai-history":["发展历程","三次浪潮","符号主义","连接主义","AI发展","发展史"],"ai-agents":["智能体","Agent","多智能体","理性智能体","PEAS"],"ai-applications":["应用","落地","场景","AI应用"],"search-basics":["搜索","盲目搜索","广度优先","BFS","深度优先","DFS","搜索基础"],"search-uninformed":["无信息搜索","一致代价","UCS","迭代加深","深度限制"],"search-informed":["启发式搜索","A*","A星","启发函数","可采纳","一致性"],"search-local":["局部搜索","爬山法","模拟退火","遗传算法","局部最优"],"knowledge-rep":["知识表示","命题逻辑","一阶逻辑","谓词","本体"],inference:["推理","归结","前向","后向","推理引擎"],planning:["规划","STRIPS","PDDL","状态空间规划","规划算法"],uncertainty:["不确定性","概率","贝叶斯网络","马尔可夫","不确定推理"],"ml-basics":["机器学习","ML","监督学习","无监督","训练集","测试集"],"ml-models":["线性回归","逻辑回归","SVM","支持向量机","决策树","KNN"],"ml-evaluation":["模型评估","准确率","召回率","F1","交叉验证","过拟合"],"dl-fundamentals":["深度学习","神经网络","DNN","反向传播","梯度下降"],"dl-optimization":["优化","梯度爆炸","梯度消失","Adam","SGD","学习率"],"dl-transformer":["Transformer","注意力","Attention","多头","BERT","GPT"],"dl-cv":["计算机视觉","CNN","卷积","图像分类","ResNet"],"nlp-basics":["自然语言处理","NLP","分词","词向量","Word2Vec","语言模型"],"rl-basics":["强化学习","RL","马尔可夫决策过程","MDP","贝尔曼方程","Q学习"],"rl-advanced":["策略梯度","PPO","DQN","深度强化学习","Actor-Critic"],ethics:["AI伦理","公平性","可解释性","偏见","安全","对齐"],"ai-future":["未来","AGI","通用人工智能","前沿","技术趋势"],"gradient-problem":["梯度爆炸","梯度消失","梯度弥散","梯度消失问题","梯度爆炸问题"],residual:["残差","残差连接","ResNet","残差网络","shortcut"],lstm:["LSTM","长短时记忆","门控","遗忘门","输入门","输出门"],batchnorm:["BatchNorm","批量归一化","BN","归一化"],layernorm:["LayerNorm","层归一化","LN"],dropout:["Dropout","随机失活"],attention:["注意力机制","Attention","自注意力","Self-Attention"]},I={manhattan:{title:"曼哈顿距离 (Manhattan Distance)",summary:"两点在标准坐标系上的绝对轴距总和，4邻域网格中等于最短路径长度。",category:"search-informed",fullAnswer:""},euclidean:{title:"欧氏距离 (Euclidean Distance)",summary:"两点间的直线距离，连续空间中最常用的距离度量。",category:"search-informed",fullAnswer:""},chebyshev:{title:"切比雪夫距离 (Chebyshev Distance)",summary:"两点在各坐标数值差绝对值的最大值，8邻域网格中等于最短路径长度。",category:"search-informed",fullAnswer:""},"grid-search":{title:"网格搜索与邻域",summary:"4邻域（上下左右）和8邻域（加对角线）是网格路径搜索的基本运动模型。",category:"search-informed",fullAnswer:""},"gradient-descent":{title:"梯度下降算法",summary:"沿梯度反方向迭代更新参数以最小化损失函数的一阶优化方法。",category:"dl-optimization",fullAnswer:""},backpropagation:{title:"反向传播算法",summary:"利用链式法则从输出层向输入层逐层计算梯度，是训练神经网络的核心算法。",category:"dl-fundamentals",fullAnswer:""},activation:{title:"激活函数",summary:"为神经网络引入非线性，常见的有 ReLU、Sigmoid、Tanh、GELU 等。",category:"dl-fundamentals",fullAnswer:""},"gradient-explosion":{title:"梯度爆炸 (Gradient Explosion)",summary:"训练深层神经网络时梯度值急剧增大，导致参数更新过大、损失函数震荡或发散。",category:"dl-optimization",fullAnswer:""},"gradient-vanishing":{title:"梯度消失 (Gradient Vanishing)",summary:"训练深层神经网络时梯度值趋近于零，导致底层参数无法更新，模型无法学习。",category:"dl-optimization",fullAnswer:""},residual:{title:"残差连接 (Residual Connection)",summary:"通过跳跃连接直接将输入传递到输出，解决深层网络训练中的梯度消失问题。",category:"dl-cv",fullAnswer:""},lstm:{title:"长短期记忆网络 (LSTM)",summary:"通过门控机制选择性地保留和遗忘信息，解决RNN的长期依赖问题。",category:"dl-fundamentals",fullAnswer:""},batchnorm:{title:"批量归一化 (Batch Normalization)",summary:"在每一层输入上进行归一化，加速收敛并缓解梯度消失问题。",category:"dl-optimization",fullAnswer:""},layernorm:{title:"层归一化 (Layer Normalization)",summary:"对每个样本的特征维度进行归一化，适合NLP任务和小批量训练。",category:"dl-optimization",fullAnswer:""},dropout:{title:"Dropout 正则化",summary:"训练时随机丢弃部分神经元，防止过拟合，增强模型泛化能力。",category:"dl-optimization",fullAnswer:""},attention:{title:"自注意力机制 (Self-Attention)",summary:"通过计算序列中任意两个位置之间的关联程度，实现全局依赖建模。",category:"dl-transformer",fullAnswer:""}};function f(s,r){const t=s.toLowerCase();let n=0;for(const a of r)t.includes(a.toLowerCase())&&(n+=a.length);return n}function T(s){let r=0,t=null;for(const[e,d]of Object.entries(S)){const i=f(s,d),c=$.find(m=>m.id===e);if(c){const m=f(s,[c.title]),h=f(s,c.summary.split(/[，。、；]/).slice(0,5)),g=i+m*2+h*.5;g>r&&(r=g,t=e)}}let n,a=0;if(s.includes("梯度")&&s.includes("爆炸")&&s.includes("消失"))n={key:"gradient-compare",data:{title:"梯度爆炸 vs 梯度消失",summary:"两种相反的梯度问题：梯度爆炸导致发散，梯度消失导致停滞，解决方法各不相同。",category:"dl-optimization",fullAnswer:""}},a=100;else if(s.includes("残差")&&(s.includes("训练")||s.includes("深层")||s.includes("为什么")))n={key:"residual-deep",data:{title:"残差连接与深度网络训练",summary:"残差连接通过shortcut提供直接梯度路径，解决深层网络的梯度消失问题。",category:"dl-cv",fullAnswer:""}},a=100;else if(s.includes("LSTM")&&(s.includes("梯度")||s.includes("缓解")||s.includes("门控")))n={key:"lstm-gate",data:{title:"LSTM门控机制与梯度缓解",summary:"LSTM通过遗忘门、输入门、输出门控制信息流动，有效缓解RNN的梯度消失问题。",category:"dl-fundamentals",fullAnswer:""}},a=100;else if(s.includes("BatchNorm")&&s.includes("LayerNorm"))n={key:"norm-compare",data:{title:"BatchNorm vs LayerNorm",summary:"两种归一化方法的核心区别在于归一化维度和统计量来源，适用于不同场景。",category:"dl-optimization",fullAnswer:""}},a=100;else for(const[e,d]of Object.entries(I)){const c=[...d.title.split(/[（）()\s-]/),...d.title.split(" ").map(h=>h.toLowerCase())],m=f(s,c);m>a&&(a=m,n={key:e,data:d})}const o=t?$.find(e=>e.id===t):void 0,l=[];if(o)for(const e of $)e.id!==o.id&&(e.chapter===o.chapter||o.prerequisites.includes(e.id)||e.prerequisites.includes(o.id))&&l.push(e);else if(n){const e=n.data.category,d=$.find(i=>i.id===e);if(d){l.push(d);for(const i of $)i.id!==d.id&&i.chapter===d.chapter&&l.push(i)}}return{primary:o,related:l.slice(0,4),extraConcept:a>5?n:void 0}}function v(s){const r=T(s),{primary:t,related:n,extraConcept:a}=r;if(!t&&!a)return B(s);const o=(a==null?void 0:a.data.title)||(t==null?void 0:t.title)||"",l=(a==null?void 0:a.data.summary)||(t==null?void 0:t.summary)||"";let e="";if(e+=`## 关于「${o}」的详细讲解

`,e+=`${l}

`,a?(e+=`### 1. 核心定义

`,a.key==="manhattan"?(e+=`对于二维空间中的两点 $p_1(x_1, y_1)$ 和 $p_2(x_2, y_2)$，曼哈顿距离定义为：

`,e+=`$$d_{\\text{manhattan}}(p_1, p_2) = |x_1 - x_2| + |y_1 - y_2|$$

`,e+=`推广到 $n$ 维空间：

`,e+=`$$d(\\mathbf{a}, \\mathbf{b}) = \\sum_{i=1}^{n} |a_i - b_i|$$

`,e+=`**几何意义**：在只能沿坐标轴方向移动的网格中（如城市街道），两点之间的最短路径长度等于曼哈顿距离。

`):a.key==="euclidean"?(e+=`对于二维空间中的两点 $p_1(x_1, y_1)$ 和 $p_2(x_2, y_2)$，欧氏距离定义为：

`,e+=`$$d_{\\text{euclidean}}(p_1, p_2) = \\sqrt{(x_1-x_2)^2 + (y_1-y_2)^2}$$

`,e+=`**几何意义**：两点之间的直线距离，不受运动方向限制。

`):a.key==="chebyshev"?(e+=`对于二维空间中的两点 $p_1(x_1, y_1)$ 和 $p_2(x_2, y_2)$，切比雪夫距离定义为：

`,e+=`$$d_{\\text{chebyshev}}(p_1, p_2) = \\max(|x_1-x_2|, |y_1-y_2|)$$

`,e+=`**几何意义**：在8邻域网格中（可走对角线），两点之间的最短路径步数等于切比雪夫距离。

`):a.key==="grid-search"?(e+=`网格搜索中的邻域概念：

`,e+=`- **4 邻域（上下左右）**：每个格子有 4 个相邻格，移动代价为 1
`,e+=`- **8 邻域（加对角线）**：每个格子有 8 个相邻格，直向代价 1，对角代价 $\\sqrt{2}$
`,e+=`- **曼哈顿距离**是 4 邻域的启发函数
`,e+=`- **切比雪夫距离**是 8 邻域的启发函数

`):a.key==="gradient-descent"?(e+=`梯度下降的核心迭代公式：

`,e+=`$$\\theta_{t+1} = \\theta_t - \\alpha \\cdot \\nabla_\\theta J(\\theta_t)$$

`,e+=`其中 $\\alpha$ 为学习率，$J(\\theta)$ 为损失函数。

`,e+=`**三种变体**：

`,e+=`| 类型 | 每步使用样本数 | 优点 | 缺点 |
`,e+=`|------|--------------|------|------|
`,e+=`| BGD（批量） | 全部 | 稳定收敛 | 速度慢，内存大 |
`,e+=`| SGD（随机） | 1个 | 速度快，内存小 | 震荡大 |
`,e+=`| Mini-batch | 一小批 | 平衡性能与稳定 | 需要调batch size |

`):a.key==="backpropagation"?(e+=`反向传播基于**链式法则**，从输出层向输入层逐层传递误差梯度：

`,e+=`1. **前向传播**：计算各层激活值
`,e+=`2. **计算输出层误差**：$\\delta^L = \\nabla_a J \\odot \\sigma'(z^L)$
`,e+=`3. **反向传递误差**：$\\delta^l = ((w^{l+1})^T \\delta^{l+1}) \\odot \\sigma'(z^l)$
`,e+=`4. **计算参数梯度**：$\\frac{\\partial J}{\\partial w^l} = \\delta^l (a^{l-1})^T$

`):a.key==="activation"?(e+=`| 激活函数 | 公式 | 特点 |
`,e+=`|---------|------|------|
`,e+=`| ReLU | $f(x) = \\max(0, x)$ | 计算快，缓解梯度消失 | 可能神经元死亡 |
`,e+=`| Sigmoid | $f(x) = \\frac{1}{1+e^{-x}}$ | 输出0~1，可作概率 | 梯度消失，非零中心 |
`,e+=`| Tanh | $f(x) = \\tanh(x)$ | 零中心 | 仍有梯度消失问题 |
`,e+=`| GELU | 高斯误差线性单元 | 平滑，Transformer常用 | 计算稍复杂 |

`):a.key==="gradient-explosion"?(e+=`**产生原因**：

`,e+=`- 使用 Sigmoid/Tanh 激活函数，梯度被压缩在 [0,1] 或 [-1,1] 范围内
`,e+=`- 深层网络梯度需通过链式法则逐层相乘，累积后梯度值急剧增大
`,e+=`- 参数初始化不当或学习率过大也会加剧此问题

`,e+=`**数学原理**：假设每层梯度为 $g$，经过 $L$ 层后梯度为 $g^L$

`,e+=`- 当 $|g| > 1$ 时，$g^L$ 指数增长 → **梯度爆炸**
`,e+=`- 当 $|g| < 1$ 时，$g^L$ 指数衰减 → **梯度消失**

`,e+=`**表现症状**：

`,e+=`- 损失函数剧烈震荡，无法收敛
`,e+=`- 参数更新值过大，模型预测出现 NaN
`,e+=`- 训练早期就出现发散

`):a.key==="gradient-vanishing"?(e+=`**产生原因**：

`,e+=`- Sigmoid/Tanh 激活函数在饱和区梯度接近 0
`,e+=`- 梯度通过链式法则逐层传递时被不断缩小
`,e+=`- 深层网络中底层参数梯度趋近于 0，无法有效学习

`,e+=`**数学原理**：

`,e+=`Sigmoid 导数：$\\sigma'(x) = \\sigma(x)(1-\\sigma(x))$，最大值仅为 0.25
`,e+=`Tanh 导数：$\\tanh'(x) = 1 - \\tanh^2(x)$，最大值为 1

`,e+=`经过多层后，梯度 $\\prod_{l=1}^L \\sigma'(z^l)$ 指数衰减。

`,e+=`**表现症状**：

`,e+=`- 训练停滞，损失函数下降缓慢或不再下降
`,e+=`- 浅层参数更新正常，深层参数几乎不更新
`,e+=`- 深层网络无法训练

`):a.key==="residual"?(e+=`**核心思想**：

`,e+=`不直接拟合 $H(x)$，而是拟合残差 $F(x) = H(x) - x$

`,e+=`$$y = F(x, \\{W_i\\}) + x$$

`,e+=`**残差块结构**：

`,e+="```\n",e+=`x ──┬── Conv ── BN ── ReLU ── Conv ── BN ──┬──→ y
`,e+=`    │                                     │
`,e+=`    └───────────────── shortcut ───────────┘
`,e+="```\n\n",e+=`**为什么能解决梯度消失**：

`,e+=`- 梯度可通过 shortcut 直接传递：$\\frac{\\partial L}{\\partial x} = \\frac{\\partial L}{\\partial y} + \\frac{\\partial L}{\\partial y} \\cdot \\frac{\\partial F}{\\partial x}$
`,e+=`- 恒等映射保证梯度至少为 $\\frac{\\partial L}{\\partial y}$，不会衰减到 0
`,e+=`- 使得数百层甚至上千层的网络可以有效训练

`):a.key==="lstm"?(e+=`**LSTM 门控结构**：

`,e+=`- **遗忘门 (Forget Gate)**：决定丢弃哪些历史信息
`,e+=`  $$f_t = \\sigma(W_f \\cdot [h_{t-1}, x_t] + b_f)$$

`,e+=`- **输入门 (Input Gate)**：决定存储哪些新信息
`,e+=`  $$i_t = \\sigma(W_i \\cdot [h_{t-1}, x_t] + b_i)$$
`,e+=`  $$\\tilde{C}_t = \\tanh(W_C \\cdot [h_{t-1}, x_t] + b_C)$$

`,e+=`- **更新单元状态**：
`,e+=`  $$C_t = f_t \\odot C_{t-1} + i_t \\odot \\tilde{C}_t$$

`,e+=`- **输出门 (Output Gate)**：决定输出哪些信息
`,e+=`  $$o_t = \\sigma(W_o \\cdot [h_{t-1}, x_t] + b_o)$$
`,e+=`  $$h_t = o_t \\odot \\tanh(C_t)$$

`,e+=`**如何缓解梯度消失**：

`,e+=`- 单元状态 $C_t$ 有直接的路径连接，梯度可沿此路径流动
`,e+=`- 遗忘门可以选择性保留长期记忆
`,e+=`- 相比普通 RNN，梯度流动路径更长更稳定

`):a.key==="batchnorm"?(e+=`**核心公式**：

`,e+=`$$\\hat{x}_i = \\frac{x_i - \\mu_B}{\\sqrt{\\sigma_B^2 + \\epsilon}}$$
`,e+=`$$y_i = \\gamma \\hat{x}_i + \\beta$$

`,e+=`其中 $\\mu_B$ 和 $\\sigma_B^2$ 是 mini-batch 的均值和方差，$\\gamma$ 和 $\\beta$ 是可学习参数。

`,e+=`**作用**：

`,e+=`- **加速收敛**：减少内部协变量偏移
`,e+=`- **缓解梯度消失**：每层输入被归一化，避免激活函数进入饱和区
`,e+=`- **正则化效果**：mini-batch 统计带来随机噪声，类似 Dropout

`,e+=`**注意事项**：

`,e+=`- 训练时用 batch 统计，推理时用移动平均统计
`,e+=`- 小批量时效果不稳定，推荐 batch size ≥ 16

`):a.key==="layernorm"?(e+=`**与 BatchNorm 的区别**：

`,e+=`| 维度 | BatchNorm | LayerNorm |
`,e+=`|------|-----------|-----------|
`,e+=`| 归一化维度 | 样本方向 | 特征方向 |
`,e+=`| 统计量来源 | 当前 batch | 当前样本 |
`,e+=`| batch size 敏感性 | 敏感 | 不敏感 |
`,e+=`| 适用场景 | CV | NLP |

`,e+=`**公式**：

`,e+=`$$\\mu = \\frac{1}{H} \\sum_{i=1}^H x_i$$
`,e+=`$$\\sigma^2 = \\frac{1}{H} \\sum_{i=1}^H (x_i - \\mu)^2$$
`,e+=`$$\\hat{x}_i = \\frac{x_i - \\mu}{\\sqrt{\\sigma^2 + \\epsilon}}$$

`,e+=`**优点**：

`,e+=`- 不依赖 batch size，适合小批量训练
`,e+=`- 适合变长序列（NLP任务）
`,e+=`- Transformer 默认使用 LayerNorm

`):a.key==="dropout"?(e+=`**工作原理**：

`,e+=`训练时，以概率 $p$ 随机将神经元输出设为 0：

`,e+=`$$r_j^{(l)} \\sim \\text{Bernoulli}(1-p)$$
`,e+=`$$\\tilde{y}_j^{(l)} = r_j^{(l)} \\cdot y_j^{(l)}$$

`,e+=`推理时，所有神经元都参与计算，但输出乘以 $(1-p)$ 进行缩放。

`,e+=`**为什么有效**：

`,e+=`- **防止过拟合**：神经元无法依赖其他特定神经元，被迫学习鲁棒特征
`,e+=`- **集成效果**：相当于训练多个子网络，推理时取平均
`,e+=`- **减少共适应**：避免神经元协同适应形成脆弱的特征表示

`,e+=`**实践建议**：

`,e+=`- 隐藏层 dropout rate 常用 0.5
`,e+=`- 输入层 dropout rate 常用 0.2
`,e+=`- 推理时务必关闭 dropout 或进行缩放

`):a.key==="attention"?(e+=`**自注意力计算过程**：

`,e+=`1. **生成 Q, K, V**：
`,e+=`   $$Q = X W_Q, \\quad K = X W_K, \\quad V = X W_V$$

`,e+=`2. **计算注意力分数**：
`,e+=`   $$\\text{scores} = \\frac{Q K^T}{\\sqrt{d_k}}$$

`,e+=`3. **Softmax 归一化**：
`,e+=`   $$\\text{attention} = \\text{softmax}(\\text{scores})$$

`,e+=`4. **加权求和**：
`,e+=`   $$\\text{output} = \\text{attention} \\cdot V$$

`,e+=`**核心特点**：

`,e+=`- **全局依赖**：任意两个位置直接计算关联，不受序列长度限制
`,e+=`- **并行计算**：所有位置的注意力分数可同时计算
`,e+=`- **缩放因子**：$\\sqrt{d_k}$ 防止分数过大导致 Softmax 饱和

`):a.key==="gradient-compare"?(e+=`**梯度爆炸 vs 梯度消失对比表**：

`,e+=`| 维度 | 梯度爆炸 | 梯度消失 |
`,e+=`|------|---------|---------|
`,e+=`| 梯度变化 | 指数增长 | 指数衰减 |
`,e+=`| 产生条件 | $|g| > 1$ | $|g| < 1$ |
`,e+=`| 损失表现 | 剧烈震荡 | 停滞不前 |
`,e+=`| 参数更新 | 更新过大 | 更新过小 |
`,e+=`| 常见原因 | 学习率过大、初始化不当 | Sigmoid/Tanh饱和区 |
`,e+=`| 发生位置 | 深层网络 | 深层网络 |

`,e+=`**解决方法汇总**：

`,e+=`- **同时缓解两者**：ReLU 激活函数、残差连接、层归一化
`,e+=`- **针对梯度爆炸**：梯度裁剪 (Gradient Clipping)、更小的学习率
`,e+=`- **针对梯度消失**：LSTM/GRU、权重初始化 (Xavier/He)、正则化

`,e+=`**数学本质**：

`,e+=`假设每层梯度为 $g$，经过 $L$ 层后梯度为 $g^L$

`,e+=`- $|g| > 1$ → $g^L$ 指数增长 → **梯度爆炸**
`,e+=`- $|g| < 1$ → $g^L$ 指数衰减 → **梯度消失**

`):a.key==="residual-deep"?(e+=`**残差连接如何解决深层网络训练问题**：

`,e+=`**问题根源**：

`,e+=`深层网络中，梯度通过链式法则逐层传递：
`,e+=`$$\\frac{\\partial L}{\\partial x_1} = \\frac{\\partial L}{\\partial x_L} \\cdot \\prod_{l=1}^{L-1} \\frac{\\partial x_{l+1}}{\\partial x_l}$$

`,e+=`当每层梯度 $< 1$ 时，乘积趋近于 0，底层参数无法更新。

`,e+=`**残差连接的解决方案**：

`,e+=`引入 shortcut，输出变为：
`,e+=`$$y = F(x) + x$$

`,e+=`梯度传递路径变为：
`,e+=`$$\\frac{\\partial L}{\\partial x} = \\frac{\\partial L}{\\partial y} + \\frac{\\partial L}{\\partial y} \\cdot \\frac{\\partial F}{\\partial x}$$

`,e+=`**关键洞察**：即使 $\\frac{\\partial F}{\\partial x} \\to 0$，梯度至少为 $\\frac{\\partial L}{\\partial y}$，不会完全消失！

`,e+=`**效果对比**：

`,e+=`| 网络类型 | 最大可训练层数 | 梯度稳定性 |
`,e+=`|---------|--------------|-----------|
`,e+=`| 普通 CNN | ~20 层 | 差 |
`,e+=`| ResNet-18 | 18 层 | 好 |
`,e+=`| ResNet-50 | 50 层 | 好 |
`,e+=`| ResNet-152 | 152 层 | 好 |

`):a.key==="lstm-gate"?(e+=`**LSTM 门控机制详解**：

`,e+=`**遗忘门 (Forget Gate)**：
`,e+=`- 决定从单元状态中丢弃哪些信息
`,e+=`- $f_t = \\sigma(W_f \\cdot [h_{t-1}, x_t] + b_f)$
`,e+=`- 输出 0~1，表示保留/遗忘的比例

`,e+=`**输入门 (Input Gate)**：
`,e+=`- 决定将哪些新信息存入单元状态
`,e+=`- $i_t = \\sigma(W_i \\cdot [h_{t-1}, x_t] + b_i)$ — 选择哪些值更新
`,e+=`- $\\tilde{C}_t = \\tanh(W_C \\cdot [h_{t-1}, x_t] + b_C)$ — 生成候选值

`,e+=`**输出门 (Output Gate)**：
`,e+=`- 决定从单元状态中输出哪些信息
`,e+=`- $o_t = \\sigma(W_o \\cdot [h_{t-1}, x_t] + b_o)$
`,e+=`- $h_t = o_t \\odot \\tanh(C_t)$

`,e+=`**如何缓解梯度消失**：

`,e+=`1. **单元状态直接传递**：$C_t = f_t \\odot C_{t-1} + i_t \\odot \\tilde{C}_t$
`,e+=`   - 梯度可沿单元状态直接流动，无需经过激活函数
`,e+=`   - 遗忘门控制梯度是否通过

`,e+=`2. **门控机制保护**：
`,e+=`   - 遗忘门接近 1 时，梯度几乎无损传递
`,e+=`   - 输入门接近 0 时，新信息不影响旧记忆

`,e+=`3. **对比普通 RNN**：
`,e+=`   - RNN：梯度需经过多层 tanh，指数衰减
`,e+=`   - LSTM：梯度可通过单元状态直接传递，衰减慢得多

`):a.key==="norm-compare"&&(e+=`**BatchNorm 与 LayerNorm 深度对比**：

`,e+=`| 维度 | BatchNorm | LayerNorm |
`,e+=`|------|-----------|-----------|
`,e+=`| 归一化维度 | 样本方向 (batch) | 特征方向 (feature) |
`,e+=`| 统计量来源 | 当前 mini-batch | 当前单个样本 |
`,e+=`| 计算公式 | $\\mu_B, \\sigma_B^2$ | $\\mu_H, \\sigma_H^2$ |
`,e+=`| Batch Size 敏感性 | 敏感，batch 越小效果越差 | 不敏感 |
`,e+=`| 训练/推理差异 | 需移动平均统计 | 无差异 |
`,e+=`| 适用场景 | 计算机视觉 (CNN) | 自然语言处理 (Transformer) |
`,e+=`| 内存开销 | 较高 (存储 batch 统计) | 较低 |

`,e+=`**数学公式对比**：

`,e+=`**BatchNorm**（对每个特征维度，跨 batch 归一化）：
`,e+=`$$\\hat{x}_{ij} = \\frac{x_{ij} - \\mu_j}{\\sqrt{\\sigma_j^2 + \\epsilon}}$$
`,e+=`其中 $\\mu_j = \\frac{1}{N} \\sum_{i=1}^N x_{ij}$

`,e+=`**LayerNorm**（对每个样本，跨特征维度归一化）：
`,e+=`$$\\hat{x}_{ij} = \\frac{x_{ij} - \\mu_i}{\\sqrt{\\sigma_i^2 + \\epsilon}}$$
`,e+=`其中 $\\mu_i = \\frac{1}{D} \\sum_{j=1}^D x_{ij}$

`,e+=`**实践建议**：

`,e+=`- **CNN**：优先使用 BatchNorm（放在卷积层之后，激活函数之前）
`,e+=`- **Transformer**：优先使用 LayerNorm（放在每个子层输入处）
`,e+=`- **小 batch 训练**：使用 LayerNorm 或 InstanceNorm
`,e+=`- **序列模型**：使用 LayerNorm（不依赖序列长度）

`)):t&&(e+=`### 1. 核心定义

`,e+=`${t.summary}

`,e+=`**所属章节**：第 ${t.chapter} 章 · 难度 ${t.difficulty}/5 · 预计学习 ${t.estimatedMinutes} 分钟

`),e+=`### 2. 关键性质

`,(a==null?void 0:a.key)==="manhattan"?(e+=`- **非负性**：$d \\ge 0$，当且仅当两点重合时取等号
`,e+=`- **对称性**：$d(p_1, p_2) = d(p_2, p_1)$
`,e+=`- **三角不等式**：$d(p_1, p_3) \\le d(p_1, p_2) + d(p_2, p_3)$
`,e+=`- **是 $L_1$ 范数**：也叫城市街区距离、出租车距离
`,e+=`- **A* 启发式**：4 邻域网格中是可采纳的（不高估真实代价）

`):(a==null?void 0:a.key)==="grid-search"?(e+=`- **4 邻域移动代价**：每步 +1，共 4 个方向
`,e+=`- **8 邻域移动代价**：直向 +1，对角 +$\\sqrt{2}$，共 8 个方向
`,e+=`- **可采纳性**：启发函数 ≤ 真实最短路径时，A* 保证找到最优解
`,e+=`- **一致性**：启发函数满足 $h(n) \\le c(n,n') + h(n')$ 时，节点只需扩展一次

`):(a==null?void 0:a.key)==="gradient-explosion"?(e+=`- **指数增长**：梯度随网络深度呈指数增长
`,e+=`- **不稳定性**：损失函数剧烈震荡，难以收敛
`,e+=`- **参数敏感性**：对学习率和初始化高度敏感
`,e+=`- **深层网络更严重**：层数越多，梯度爆炸风险越大

`):(a==null?void 0:a.key)==="gradient-vanishing"?(e+=`- **指数衰减**：梯度随网络深度呈指数衰减
`,e+=`- **浅层优势**：浅层参数更新正常，深层参数几乎不更新
`,e+=`- **激活函数依赖**：Sigmoid/Tanh 比 ReLU 更容易出现
`,e+=`- **长期依赖困难**：RNN 中无法学习远距离依赖

`):(a==null?void 0:a.key)==="residual"?(e+=`- **恒等映射**：shortcut 提供直接的梯度传递路径
`,e+=`- **残差学习**：拟合 $F(x) = H(x) - x$ 比直接拟合 $H(x)$ 更容易
`,e+=`- **深度可扩展性**：支持训练数百层甚至上千层网络
`,e+=`- **参数效率**：相比同深度的普通网络，参数更少

`):(a==null?void 0:a.key)==="lstm"?(e+=`- **门控机制**：遗忘门、输入门、输出门控制信息流动
`,e+=`- **长期记忆**：单元状态 $C_t$ 可存储长期信息
`,e+=`- **梯度稳定**：相比普通 RNN，梯度流动路径更稳定
`,e+=`- **序列建模**：适合处理变长序列数据

`):(a==null?void 0:a.key)==="batchnorm"?(e+=`- **内部协变量偏移减少**：每层输入分布更稳定
`,e+=`- **学习率容忍度高**：可以使用更大的学习率
`,e+=`- **正则化效果**：mini-batch 统计提供隐式正则化
`,e+=`- **加速收敛**：通常可将训练速度提升 3-5 倍

`):(a==null?void 0:a.key)==="layernorm"?(e+=`- **样本级归一化**：对每个样本独立计算统计量
`,e+=`- **batch size 无关**：适合小批量或动态 batch size
`,e+=`- **序列友好**：适合处理变长序列（NLP任务）
`,e+=`- **Transformer 默认**：是 Transformer 架构的标配

`):(a==null?void 0:a.key)==="dropout"?(e+=`- **随机失活**：训练时随机丢弃部分神经元
`,e+=`- **集成效果**：等价于训练多个子网络的集成
`,e+=`- **防止过拟合**：减少神经元间的共适应
`,e+=`- **推理时缩放**：需乘以 $(1-p)$ 保持输出期望一致

`):(a==null?void 0:a.key)==="attention"?(e+=`- **全局依赖**：任意两个位置直接计算关联
`,e+=`- **并行计算**：所有位置的注意力分数可同时计算
`,e+=`- **缩放机制**：$\\sqrt{d_k}$ 防止 Softmax 饱和
`,e+=`- **多头机制**：多个注意力头捕捉不同类型的关联

`):(a==null?void 0:a.key)==="gradient-compare"?(e+=`- **对称性**：两者是同一问题的正反两面
`,e+=`- **深度依赖**：网络越深，问题越严重
`,e+=`- **激活函数影响**：ReLU 缓解消失，加剧爆炸
`,e+=`- **相互转化**：调整学习率可能使一种问题变为另一种

`):(a==null?void 0:a.key)==="residual-deep"?(e+=`- **恒等映射保障**：shortcut 提供直接梯度路径
`,e+=`- **残差学习更容易**：拟合 $F(x)$ 比拟合 $H(x)$ 更简单
`,e+=`- **参数效率**：相同性能下参数更少
`,e+=`- **泛化能力强**：深度残差网络通常有更好的泛化性能

`):(a==null?void 0:a.key)==="lstm-gate"?(e+=`- **门控的灵活性**：三个门独立控制信息流动
`,e+=`- **梯度路径多样**：可通过单元状态或隐藏状态传递
`,e+=`- **长期记忆能力**：遗忘门可选择性保留长期信息
`,e+=`- **计算复杂度**：比普通 RNN 高，但训练更稳定

`):(a==null?void 0:a.key)==="norm-compare"?(e+=`- **归一化方向不同**：BatchNorm 跨样本，LayerNorm 跨特征
`,e+=`- **统计量稳定性**：LayerNorm 更稳定（不依赖 batch）
`,e+=`- **适用领域差异**：CV 用 BN，NLP 用 LN
`,e+=`- **实现细节**：BN 需要 running mean/variance，LN 不需要

`):t?(e+=`根据该知识点的性质，重点掌握以下维度：

`,e+=`- **形式化定义**：精确的数学描述与边界条件
`,e+=`- **核心性质**：完备性、最优性、时间/空间复杂度
`,e+=`- **适用场景**：什么情况下选择该方法
`,e+=`- **常见变体**：基础算法的扩展与优化方向

`):e+=`待补充...

`,e+=`### 3. 图示理解

`,(a==null?void 0:a.key)==="manhattan"?(e+="```\n",e+=`● ──┐    起点 (0,0) → 终点 (3,2)
`,e+=`    │
`,e+=`    ├─── ●  曼哈顿距离 = |3-0| + |2-0| = 5
`,e+=`    │
`,e+=`    └─── ●  无论走哪条路径，总步数都是 5
`,e+="```\n\n",e+=`在网格中，所有"只向右和向上走"的路径长度都等于曼哈顿距离。

`):(a==null?void 0:a.key)==="grid-search"?(e+="```\n",e+=`4 邻域 (上下左右)：   8 邻域 (加对角线)：
`,e+=`   ○                     ○ ○ ○
`,e+=` ○ ● ○                   ○ ● ○
`,e+=`   ○                     ○ ○ ○
`,e+="```\n\n"):e+=`建议结合配套的思维导图与教学动画中的图示部分，建立直观理解。

`,e+=`### 4. 代码实现

`,(a==null?void 0:a.key)==="manhattan"?e+=`\`\`\`python
def manhattan_distance(p1, p2):
    """计算二维曼哈顿距离"""
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


def manhattan_distance_n(a, b):
    """n 维曼哈顿距离"""
    return sum(abs(ai - bi) for ai, bi in zip(a, b))


# 在 A* 中作为启发函数
def heuristic(pos, goal):
    return manhattan_distance(pos, goal)  # 4 邻域可采纳
\`\`\`

`:(a==null?void 0:a.key)==="gradient-descent"?e+=`\`\`\`python
import numpy as np

def gradient_descent(X, y, lr=0.01, epochs=1000):
    """线性回归的批量梯度下降"""
    n_samples, n_features = X.shape
    w = np.zeros(n_features)
    b = 0.0
    
    for epoch in range(epochs):
        y_pred = X @ w + b
        
        # 计算梯度
        dw = (1 / n_samples) * X.T @ (y_pred - y)
        db = (1 / n_samples) * np.sum(y_pred - y)
        
        # 更新参数
        w -= lr * dw
        b -= lr * db
        
        if epoch % 100 == 0:
            loss = np.mean((y_pred - y) ** 2)
            print(f"Epoch {epoch}: loss = {loss:.4f}")
    
    return w, b
\`\`\`

`:e+=`完整代码示例可参考资源中心的「代码实操」类资源，支持在线运行与修改。

`,e+=`### 5. 常见易错点

`,(a==null?void 0:a.key)==="manhattan"?(e+=`1. **适用场景混淆**：曼哈顿距离只适用于 4 邻域网格，8 邻域要用切比雪夫
`,e+=`2. **可采纳性判断**：当移动代价不全为 1 时，曼哈顿距离可能高估（不满足可采纳性）
`,e+=`3. **维度灾难**：高维空间中曼哈顿距离的区分度下降
`,e+=`4. **与切比雪夫混淆**：4 邻域→曼哈顿，8 邻域→切比雪夫，不要搞反

`):(a==null?void 0:a.key)==="gradient-descent"?(e+=`1. **学习率太大**：导致震荡不收敛甚至发散
`,e+=`2. **学习率太小**：收敛太慢，训练时间过长
`,e+=`3. **特征未标准化**：不同特征尺度差异大，梯度下降路径呈"之"字形
`,e+=`4. **局部最优**：非凸函数可能陷入局部最优（深度学习中较常见鞍点）
`,e+=`5. **BatchNorm 顺序**：BN 应放在激活函数之前还是之后？推荐 Conv-BN-Activation

`):t&&(e+=`学习本知识点时需要特别注意：

`,e+=`- 边界条件与退化情况的处理
`,e+=`- 与相似概念的区分（避免张冠李戴）
`,e+=`- 复杂度分析中的常数因子与实际性能差异
`,e+=`- 工程实现中常见的"看起来对但其实错"的陷阱

`),e+=`### 6. 学习路径建议

`,t&&(e+=`**前置知识**：${t.prerequisites.length>0?t.prerequisites.join("、"):"无，可直接开始"}

`),n.length>0){e+=`**相关知识点**：

`;for(const i of n.slice(0,4))e+=`- [${i.title}](#)（第 ${i.chapter} 章）
`;e+=`
`}e+=`**推荐学习顺序**：

`,e+=`1. 先读讲解文档，建立概念框架
`,e+=`2. 看思维导图，理清知识结构
`,e+=`3. 配合教学动画建立直观理解
`,e+=`4. 动手写代码（代码实操资源）
`,e+=`5. 做题检验掌握程度（题库资源）
`,e+=`6. 阅读拓展材料，了解前沿应用

`;const d=p.filter(i=>!!(t&&i.knowledgeId===t.id||a&&i.knowledgeId===a.data.category)).slice(0,4);if(d.length>0){e+=`### 7. 相关学习资源

`,e+=`| 类型 | 资源 | 时长 |
`,e+=`|------|------|------|
`;for(const i of d){const c={document:"📄 讲解文档",mindmap:"🧠 思维导图",quiz:"📝 练习题库",reading:"📚 拓展阅读",animation:"🎬 教学动画",code:"💻 代码实操"}[i.type]||i.type;e+=`| ${c} | ${i.title} | ${i.metadata.duration||"—"} |
`}e+=`
`,e+=`> 在资源中心搜索关键词可找到更多相关内容。

`}return e+=`---

`,e+="*解答由「灵境队长 + 校验官」双智能体协作生成，内容已通过事实核查。如有疑问可继续追问。*",e}function B(s){return`## 关于你的问题

你提出的「${s}」是一个很好的问题。我暂时无法从课程知识库中精确定位到对应的知识点，但可以从以下角度帮你思考：

### 建议的探索方向

1. **概念澄清**：先明确问题涉及的核心概念是什么？是否有形式化定义？
2. **分类定位**：这个问题属于 AI 的哪个子领域？搜索 / 学习 / 推理 / NLP / CV / RL？
3. **方法对比**：有哪些主流方法？各有什么优缺点？
4. **实践验证**：能否通过代码实验来验证你的理解？

### 你可以这样补充问题

- 说明你在学习哪门课程的哪一章
- 描述你已经了解了什么，卡在哪里
- 附上题目原文或代码片段（如果是解题类问题）

你可以在**学习画像 → 随学随新**中更新你的学习进度，系统会根据你的掌握情况调整推荐策略。

> 💡 提示：试试问"梯度下降"、"A* 算法"、"Transformer 注意力"等具体知识点，我可以给出更详细的讲解。`}const R={document:[{phase:"拆解知识结构",agentId:"deconstructor",messages:["正在检索知识点 ${k} 的前置依赖与核心要素…","已识别 5 个主分支：定义 / 性质 / 算法 / 应用 / 易错点","知识骨架构建完成，移交编织者。"]},{phase:"撰写讲解文档",agentId:"weaver",messages:["基于骨架组织学术叙事，引入形式化定义…","正在补充典型算法对比表与学习建议…","讲解文档主体撰写完成，提交校验官。"]},{phase:"事实核查与安全过滤",agentId:"validator",messages:["对照本地知识库白名单进行事实核查…","敏感词扫描、引用补全、公式语法校验通过 ✓","校验通过，资源正式入库。"]}],mindmap:[{phase:"构建思维骨架",agentId:"deconstructor",messages:["分析知识点结构层次…","输出 5 主分支 / 15 子节点骨架。"]},{phase:"渲染节点连线",agentId:"visualist",messages:["生成 mermaid mindmap 语法…","节点连线与配色完成。"]},{phase:"节点校验",agentId:"validator",messages:["节点数量与依赖一致性校验通过 ✓"]}],quiz:[{phase:"锁定考点",agentId:"deconstructor",messages:["根据知识点与画像易错偏好锁定 5 个考点…"]},{phase:"生成多梯度题目",agentId:"quizmaster",messages:["生成单选 / 多选 / 判断 / 简答 / 综合共 5 题…","依据画像「${err}」靶向出题，难度梯度 ★ ~ ★★★★★"]},{phase:"答案与解析校验",agentId:"validator",messages:["答案唯一性、解析自洽性校验通过 ✓"]}],reading:[{phase:"梳理拓展方向",agentId:"deconstructor",messages:["规划经典教材 / 综述 / 博客 / 视频四条拓展线…"]},{phase:"汇编拓展阅读",agentId:"weaver",messages:["汇编 4 篇拓展资源，撰写导读…"]},{phase:"引用补全",agentId:"validator",messages:["引用交叉核对完成，缺失部分已标注待补充 ✓"]}],animation:[{phase:"提取可视化要素",agentId:"deconstructor",messages:["识别 4 个可视化关键帧…"]},{phase:"设计分镜与图解",agentId:"visualist",messages:["设计 4 分镜脚本，生成 SVG 图解…","配色与动效节奏完成。"]},{phase:"图解准确性校验",agentId:"validator",messages:["SVG 元素与知识点一致性校验通过 ✓"]}],code:[{phase:"分析实操需求",agentId:"deconstructor",messages:["拆解可运行代码的最小功能边界…"]},{phase:"编写可运行代码",agentId:"coder",messages:["生成 Python 实现 + 配置 + 单元测试…","本地 dry-run 模拟通过。"]},{phase:"语法与安全校验",agentId:"validator",messages:["语法、依赖、安全扫描通过 ✓"]}]},_=(s,r)=>s.replace(/\$\{k\}/g,r.k).replace(/\$\{err\}/g,r.err);async function*G(s,r){const t=s.knowledgeId?N(s.knowledgeId):void 0;if(!t&&!s.topic)throw new Error("未提供知识点或主题");const n=R[s.resourceType],a={k:(t==null?void 0:t.title)||s.topic,err:"梯度爆炸 / QKV 顺序 / DP 边界"};let o=0;r({agentId:"captain",agentName:"灵境",phase:"thinking",message:`收到任务：为「${(t==null?void 0:t.title)||s.topic}」生成${L[s.resourceType].label}，正在调度智能体编队…`,ts:Date.now()}),await u(400);for(const i of n){const c=b(i.agentId);r({agentId:c.id,agentName:c.name,phase:"thinking",message:`【${i.phase}】${_(i.messages[0],a)}`,ts:Date.now()}),await u(500+Math.random()*400);for(let m=1;m<i.messages.length;m++)r({agentId:c.id,agentName:c.name,phase:"generating",message:_(i.messages[m],a),ts:Date.now()}),await u(400+Math.random()*300)}const l=t?p.find(i=>i.knowledgeId===t.id&&i.type===s.resourceType)||p[0]:k(s.resourceType,s.topic);if(!l)throw new Error("未找到资源模板");const e=A(l.content,t==null?void 0:t.id),d={...l,id:`${l.id}-gen-${Date.now()}`,createdAt:new Date().toLocaleString("zh-CN"),safetyCheck:e};r({agentId:"captain",agentName:"灵境",phase:"done",message:`生成完成 ✓ 已通过校验官防幻觉检查（安全分 ${e.score}），开始流式呈现…`,ts:Date.now()});for await(const i of y(l.content,{speed:8,onToken:c=>{o=c}}))yield i;return{resource:d,totalTokens:o}}async function*M(s){const r=v(s);for await(const t of y(r,{speed:14}))yield t}export{G as o,M as t};
