@echo off
chcp 65001 > nul
title 智学灵境 EduVerse · 一键启动
cd /d "%~dp0"

echo.
echo ============================================================
echo            智学灵境 EduVerse · 一键启动
echo ============================================================
echo.

REM ===== 1. 检查 Node.js =====
where node >nul 2>nul
if errorlevel 1 (
    echo [×] 未检测到 Node.js，请先安装 Node.js 18 以上版本
    echo.
    echo     下载地址：https://nodejs.org/zh-cn
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo [√] Node.js 版本：%NODE_VER%

REM ===== 2. 检查 npm =====
where npm >nul 2>nul
if errorlevel 1 (
    echo [×] 未检测到 npm，请重新安装 Node.js
    pause
    exit /b 1
)
echo [√] npm 已就绪

REM ===== 3. 检查依赖是否安装 =====
if not exist "node_modules" (
    echo.
    echo [*] 首次运行，正在安装依赖（约 1-3 分钟）...
    echo.
    call npm install --no-fund --no-audit
    if errorlevel 1 (
        echo.
        echo [×] 依赖安装失败，请检查网络后重试
        pause
        exit /b 1
    )
    echo.
    echo [√] 依赖安装完成
) else (
    echo [√] 依赖已安装，跳过
)

REM ===== 4. 启动开发服务器（后台）并打开浏览器 =====
echo.
echo ============================================================
echo  服务启动中... 浏览器将自动打开
echo  首次加载约需 3-5 秒，请稍候
echo ============================================================
echo.

REM 延迟 3 秒后打开浏览器
start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:5173/"

REM 启动 vite 开发服务器（前台运行，关闭窗口即停止服务）
call npm run dev

echo.
echo 服务已停止，按任意键关闭窗口
pause >nul
