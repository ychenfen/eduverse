@echo off
chcp 65001 > nul
title 智学灵境 EduVerse · 生产模式启动
cd /d "%~dp0"

echo.
echo ============================================================
echo         智学灵境 EduVerse · 生产模式启动
echo ============================================================
echo.

REM ===== 1. 检查 Node.js =====
where node >nul 2>nul
if errorlevel 1 (
    echo [×] 未检测到 Node.js，请先安装 Node.js 18 以上版本
    echo.
    echo     下载地址：https://nodejs.org/zh-cn
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo [√] Node.js 版本：%NODE_VER%

REM ===== 2. 检查依赖 =====
if not exist "node_modules" (
    echo [*] 首次运行，正在安装依赖...
    call npm install --no-fund --no-audit
    if errorlevel 1 (
        echo [×] 依赖安装失败
        pause
        exit /b 1
    )
)

REM ===== 3. 检查是否已构建 =====
if not exist "dist" (
    echo.
    echo [*] 首次运行，正在构建生产版本（约 30-60 秒）...
    echo.
    call npm run build
    if errorlevel 1 (
        echo [×] 构建失败，请检查代码
        pause
        exit /b 1
    )
    echo.
    echo [√] 构建完成
) else (
    echo [√] 已有构建产物，如需重新构建请删除 dist 目录
)

REM ===== 4. 启动预览服务器并打开浏览器 =====
echo.
echo ============================================================
echo  服务启动中... 浏览器将自动打开
echo ============================================================
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:4173/"

call npm run preview -- --port 4173 --host

echo.
echo 服务已停止，按任意键关闭窗口
pause >nul
